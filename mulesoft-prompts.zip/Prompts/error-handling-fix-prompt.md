# Comprehensive Error Handling Implementation Prompt
## For VR NMVTIS SOL AAMVA eAPI v1

### 🎯 **Objective**
Implement comprehensive error handling and custom logging for the VR NMVTIS SOL AAMVA eAPI v1 project by:
1. Adding try-catch scopes around all external system connections
2. Implementing standardized custom error logging with specific error identifiers
3. Integrating DMV Common Exception Handler for global error management
4. Following the format: `APP:IDENTIFIER` where APP=NMVTISSOL and IDENTIFIER is contextual

### 📋 **Prerequisites**
- Access to vr-nmvtis-sol-aamva-eapi-v1 repository (develop branch)
- **MUST** have DMV Common Exception Handler v3.0.1 available in Exchange
- **MUST** understand MuleSoft error handling patterns
- **MUST** have knowledge of DataWeave 2.0 transformations

---

## 🔧 **Phase 1: Update Dependencies**

### Task 1.1: Update pom.xml
**Action:** Add DMV Common Exception Handler dependency

```xml
<dependency>
    <groupId>304100f2-2a0c-4d2c-9236-c19787d55966</groupId>
    <artifactId>dmv-common-exception-handler</artifactId>
    <version>3.0.1</version>
    <classifier>mule-plugin</classifier>
</dependency>
```

**Location:** Replace the commented out ca-dmv-errorhandling-framework dependency in pom.xml

---

## 🛠 **Phase 2: Add Try-Catch Scopes to External Operations**

### Task 2.1: SQS Operations Error Handling

**File:** `src/main/mule/common/nmvtis-publish-sqs-implementation.xml`

**Action:** Wrap SQS send-message operation in try-catch scope

```xml
<try doc:name="Try - SQS Send Message" doc:id="sqs-send-try-scope">
    <sqs:send-message doc:name="publish-message-Nmvtis-SQS" doc:id="5ae92846-1288-4dbe-8c52-ffc9e4fe437c" config-ref="NMVTIS_SQS_queue_Configuration" queueUrl="${aws-sqs.queueURL}"/>
    <error-handler>
        <on-error-propagate enableNotifications="true" logException="true" doc:name="On Error Propagate - SQS Send" doc:id="sqs-send-error-handler">
            <ee:transform doc:name="Transform - SQS Send Error" doc:id="sqs-send-error-transform">
                <ee:message>
                    <ee:set-payload><![CDATA[%dw 2.0
                    output application/json
                    ---
                    {
                      "apiName": "vr-nmvtis-aamva-sol-papi",
                      "success": false,
                      "source": "NMVTIS",
                      "target": "SQS",
                      "correlationId": correlationId,
                      "identifier": "SQSPUT",
                      "timeStamp": now(),
                      "errorDetails": {
                        "errorCode": error.errorMessage.attributes.statusCode default 500,
                        "errorType": "NMVTISSOL:SQSPUT",
                        "errorMessage": error.errorMessage.attributes.reasonPhrase default error.description,
                        "errorDescription": error.description
                      }
                    }]]></ee:set-payload>
                </ee:message>
            </ee:transform>
            <logger level="ERROR" doc:name="Log SQS Send Error" doc:id="sqs-send-error-logger" message="#[payload]"/>
            <raise-error doc:name="Raise SQS Error" doc:id="sqs-send-raise-error" type="CUSTOM:SQS_ERROR"/>
        </on-error-propagate>
    </error-handler>
</try>
```

**Required:** Add EE namespace to the XML file:
```xml
xmlns:ee="http://www.mulesoft.org/schema/mule/ee/core"
```

### Task 2.2: Health Check SQS Operations

**File:** `src/main/mule/vr-nmvtis-sol-aamva-eapi-v1.xml`

**Action:** Update existing SQS health check try-catch scope with standardized error logging

```xml
<try doc:name="Try - SQS Health Check" doc:id="cc80fcf0-fef7-451e-8b6e-aa59de13d0d4">
    <sqs:get-queue-attributes doc:name="Get queue attributes" doc:id="35b324de-586e-496b-a438-9c579164611b" config-ref="NMVTIS_SQS_queue_Configuration" queueUrl="${aws-sqs.queueURL}" />
    <error-handler>
        <on-error-continue enableNotifications="true" logException="true" doc:name="On Error Continue - SQS Health" doc:id="c4ac18c9-d30b-4835-8c99-d315abeb0e78" when='#[error.errorType.identifier != "CONNECTIVITY" or error.errorType.identifier != "SERVICE_UNAVAILABLE"]'>
            <ee:transform doc:name="Transform - SQS Health Check Error" doc:id="6eb5634c-a42d-4ce5-918d-8aac12de59f6">
                <ee:message>
                    <ee:set-payload><![CDATA[%dw 2.0
                    output application/json
                    ---
                    {
                      "apiName": "vr-nmvtis-aamva-sol-papi",
                      "success": false,
                      "source": "HealthCheck",
                      "target": "SQS",
                      "correlationId": correlationId,
                      "identifier": "SQSGET",
                      "timeStamp": now(),
                      "errorDetails": {
                        "errorCode": error.errorMessage.attributes.statusCode default 500,
                        "errorType": "NMVTISSOL:SQSGET",
                        "errorMessage": error.errorMessage.attributes.reasonPhrase default error.description,
                        "errorDescription": error.description
                      }
                    }]]></ee:set-payload>
                </ee:message>
                <ee:variables>
                    <ee:set-variable variableName="exceptionMessage"><![CDATA[%dw 2.0 output application/java --- error.description]]></ee:set-variable>
                    <ee:set-variable variableName="exceptionCode"><![CDATA[%dw 2.0 output application/java --- error.cause.errorMessage.attributes.statusCode default 500]]></ee:set-variable>
                    <ee:set-variable variableName="exceptionType"><![CDATA[%dw 2.0 output application/java --- error.errorType]]></ee:set-variable>
                </ee:variables>
            </ee:transform>
            <logger level="ERROR" doc:name="Log SQS Health Check Error" doc:id="09e5eb13-7a48-4061-b281-2947f7c33cb6" message="#[payload]" />
        </on-error-continue>
    </error-handler>
</try>
```

### Task 2.3: AAMVA Token Verification

**File:** `src/main/mule/vr-nmvtis-sol-aamva-eapi-v1.xml`

**Action:** Update existing AAMVA token verification try-catch scope

```xml
<try doc:name="Try - AAMVA Token Verification" doc:id="fea24488-298d-47f7-8d8e-7c5561c5a739">
    <flow-ref doc:name="nmvtis-common-framework-aamva-token-verify-imp_sub_flow_reference" doc:id="4e9b1d32-f5e8-42e2-a71c-97291acb8433" name="nmvtis-common-framework-aamva-token-verify-imp_sub_flow" target="verifyAuthResponse"/>
    <error-handler>
        <on-error-propagate enableNotifications="true" logException="true" doc:name="On Error Propagate - AAMVA Auth" doc:id="fef990c2-f8e5-4197-be1d-b7cee1983c0c">
            <ee:transform doc:name="Transform - AAMVA Auth Error" doc:id="9662d844-d288-45c0-8434-6828212b6e93">
                <ee:message>
                    <ee:set-payload><![CDATA[%dw 2.0
                    output application/json
                    ---
                    {
                      "apiName": "vr-nmvtis-aamva-sol-papi",
                      "success": false,
                      "source": "NMVTIS",
                      "target": "AAMVA",
                      "correlationId": correlationId,
                      "identifier": "AAMVAAUTH",
                      "timeStamp": now(),
                      "errorDetails": {
                        "errorCode": vars.validateAuthtokenres.errordetails.errorCode default 401,
                        "errorType": "NMVTISSOL:AAMVAAUTH",
                        "errorMessage": vars.validateAuthtokenres.errordetails.errorMessage default "AAMVA Authentication Failed",
                        "errorDescription": vars.validateAuthtokenres.errordetails.errorType default error.description
                      }
                    }]]></ee:set-payload>
                </ee:message>
                <ee:variables>
                    <ee:set-variable variableName="exceptionCode"><![CDATA[%dw 2.0 output application/json --- vars.validateAuthtokenres.errordetails.errorCode]]></ee:set-variable>
                    <ee:set-variable variableName="exceptionType"><![CDATA[%dw 2.0 output application/json --- vars.validateAuthtokenres.errordetails.errorType]]></ee:set-variable>
                    <ee:set-variable variableName="exceptionMessage"><![CDATA[%dw 2.0 output application/json --- vars.validateAuthtokenres.errordetails.errorMessage]]></ee:set-variable>
                </ee:variables>
            </ee:transform>
            <logger level="ERROR" doc:name="Log AAMVA Auth Error" doc:id="23359c91-0a0d-4da0-87cc-754e661384cc" message="#[payload]" />
            <raise-error doc:name="Raise_ammva_validate_token_unauthorized_error" doc:id="bfdbc973-33b0-4168-bcaa-2947188cd7d1" type="VALIDBUSINESS:FAILURE" description='"NMVTIS aamva auth token expired "'/>
        </on-error-propagate>
    </error-handler>
</try>
```

### Task 2.4: HTTP Request Operations

**Files:** Add try-catch scopes around HTTP request operations in implementation flows

**Action:** For each HTTP request operation, wrap in try-catch scope with standardized error logging

```xml
<try doc:name="Try - HTTP Request" doc:id="http-request-try-scope">
    <http:request method="POST" doc:name="HTTP Request" config-ref="http_request_config"/>
    <error-handler>
        <on-error-propagate enableNotifications="true" logException="true" doc:name="On Error Propagate - HTTP" doc:id="http-error-handler">
            <ee:transform doc:name="Transform - HTTP Error" doc:id="http-error-transform">
                <ee:message>
                    <ee:set-payload><![CDATA[%dw 2.0
                    output application/json
                    ---
                    {
                      "apiName": "vr-nmvtis-aamva-sol-papi",
                      "success": false,
                      "source": "NMVTIS",
                      "target": "HTTP_API",
                      "correlationId": correlationId,
                      "identifier": "HTTPPOST",
                      "timeStamp": now(),
                      "errorDetails": {
                        "errorCode": error.errorMessage.attributes.statusCode default 500,
                        "errorType": "NMVTISSOL:HTTPPOST",
                        "errorMessage": error.errorMessage.attributes.reasonPhrase default error.description,
                        "errorDescription": error.description
                      }
                    }]]></ee:set-payload>
                </ee:message>
            </ee:transform>
            <logger level="ERROR" doc:name="Log HTTP Error" doc:id="http-error-logger" message="#[payload]"/>
            <raise-error doc:name="Raise HTTP Error" doc:id="http-raise-error" type="CUSTOM:HTTP_ERROR"/>
        </on-error-propagate>
    </error-handler>
</try>
```

---

## 🔧 **Phase 3: Update Global Exception Handler**

### Task 3.1: Update Global Configuration

**File:** `src/main/mule/common/global-config.xml`

**Action:** Add DMV Exception Handler configuration and update global error handler

```xml
<!-- Add DMV Exception Handler Configuration -->
<dmv-exception-handler:config name="DMV_Exception_Handler_Config" doc:name="DMV Exception Handler Config"/>

<!-- Update Global Exception Handler -->
<global-error-handler name="globalErrorHandler" doc:id="globalErrorHandler">
    <on-error-propagate type="APIKIT:BAD_REQUEST">
        <dmv-exception-handler:handle-error doc:name="Handle DMV Error" config-ref="DMV_Exception_Handler_Config">
            <dmv-exception-handler:error-payload><![CDATA[%dw 2.0
            output application/json
            ---
            {
              "apiName": "vr-nmvtis-aamva-sol-papi",
              "success": false,
              "source": "API",
              "target": "Client",
              "correlationId": correlationId,
              "identifier": "APIBADREQUEST",
              "timeStamp": now(),
              "errorDetails": {
                "errorCode": 400,
                "errorType": "NMVTISSOL:APIBADREQUEST",
                "errorMessage": "Bad Request",
                "errorDescription": error.description
              }
            }]]></dmv-exception-handler:error-payload>
        </dmv-exception-handler:handle-error>
        <set-payload value='#[output application/json --- {"message": "Bad request"}]' doc:name="Set Payload"/>
        <set-variable value="400" doc:name="httpStatus" variableName="httpStatus"/>
    </on-error-propagate>
    
    <on-error-propagate type="APIKIT:NOT_FOUND">
        <dmv-exception-handler:handle-error doc:name="Handle DMV Error" config-ref="DMV_Exception_Handler_Config">
            <dmv-exception-handler:error-payload><![CDATA[%dw 2.0
            output application/json
            ---
            {
              "apiName": "vr-nmvtis-aamva-sol-papi",
              "success": false,
              "source": "API", 
              "target": "Client",
              "correlationId": correlationId,
              "identifier": "APINOTFOUND",
              "timeStamp": now(),
              "errorDetails": {
                "errorCode": 404,
                "errorType": "NMVTISSOL:APINOTFOUND",
                "errorMessage": "Resource not found",
                "errorDescription": error.description
              }
            }]]></dmv-exception-handler:error-payload>
        </dmv-exception-handler:handle-error>
        <set-payload value='#[output application/json --- {"message": "Resource not found"}]' doc:name="Set Payload"/>
        <set-variable value="404" doc:name="httpStatus" variableName="httpStatus"/>
    </on-error-propagate>
    
    <on-error-propagate type="ANY">
        <dmv-exception-handler:handle-error doc:name="Handle DMV Error" config-ref="DMV_Exception_Handler_Config">
            <dmv-exception-handler:error-payload><![CDATA[%dw 2.0
            output application/json
            ---
            {
              "apiName": "vr-nmvtis-aamva-sol-papi",
              "success": false,
              "source": "API",
              "target": "System",
              "correlationId": correlationId,
              "identifier": "SYSTEMERROR",
              "timeStamp": now(),
              "errorDetails": {
                "errorCode": 500,
                "errorType": "NMVTISSOL:SYSTEMERROR", 
                "errorMessage": error.errorMessage.attributes.reasonPhrase default "Internal server error",
                "errorDescription": error.description
              }
            }]]></dmv-exception-handler:error-payload>
        </dmv-exception-handler:handle-error>
        <set-payload value='#[output application/json --- {"message": "Internal server error"}]' doc:name="Set Payload"/>
        <set-variable value="500" doc:name="httpStatus" variableName="httpStatus"/>
    </on-error-propagate>
</global-error-handler>
```

**Required:** Add DMV Exception Handler namespace:
```xml
xmlns:dmv-exception-handler="http://www.mulesoft.org/schema/mule/module-dmv-extension-handler"
```

---

## 📊 **Phase 4: Error Identifier Mapping Strategy**

### Error Type Format: `NMVTISSOL:{IDENTIFIER}`

| System | Operation | Identifier | Example |
|--------|-----------|------------|---------|
| **SQS** | Send Message | SQSPUT | NMVTISSOL:SQSPUT |
| **SQS** | Get Attributes | SQSGET | NMVTISSOL:SQSGET |
| **SQS** | Receive Message | SQSGET | NMVTISSOL:SQSGET |
| **HTTP** | GET Request | HTTPGET | NMVTISSOL:HTTPGET |
| **HTTP** | POST Request | HTTPPOST | NMVTISSOL:HTTPPOST |
| **HTTP** | PUT Request | HTTPPUT | NMVTISSOL:HTTPPUT |
| **AAMVA** | Authentication | AAMVAAUTH | NMVTISSOL:AAMVAAUTH |
| **Salesforce** | Query | SFQUERY | NMVTISSOL:SFQUERY |
| **Salesforce** | Update | SFUPDATE | NMVTISSOL:SFUPDATE |
| **Salesforce** | Create | SFCREATE | NMVTISSOL:SFCREATE |
| **Database** | Query | DBQUERY | NMVTISSOL:DBQUERY |
| **Database** | Update | DBUPDATE | NMVTISSOL:DBUPDATE |
| **API** | Bad Request | APIBADREQUEST | NMVTISSOL:APIBADREQUEST |
| **API** | Not Found | APINOTFOUND | NMVTISSOL:APINOTFOUND |
| **API** | System Error | SYSTEMERROR | NMVTISSOL:SYSTEMERROR |

---

## 🔍 **Phase 5: DataWeave Utility Files**

### Task 5.1: Create Error Mapping Utilities

**File:** `src/main/resources/dwl/error-mapping.dwl`

**Content:** Standardized error transformation functions for consistent error handling

### Task 5.2: Create Error Logger Utilities  

**File:** `src/main/resources/dwl/error-logger.dwl`

**Content:** Pre-built logging functions for different system operations

---

## ✅ **Phase 6: Implementation Locations**

### Primary Files to Modify:

1. **pom.xml** - Add DMV Common Exception Handler dependency
2. **src/main/mule/common/global-config.xml** - Update global exception handler
3. **src/main/mule/common/nmvtis-publish-sqs-implementation.xml** - Add SQS try-catch scopes
4. **src/main/mule/vr-nmvtis-sol-aamva-eapi-v1.xml** - Update AAMVA and health check error handling
5. **src/main/mule/implementation/realTime/nmvtis-sol-real-time-inquiry-response-imp.xml** - Add HTTP operation error handling
6. **src/main/mule/implementation/pseudoBatch/nmvtis-sol-pseudo-batch-implementation.xml** - Add HTTP operation error handling

### New Files to Create:

1. **src/main/resources/dwl/error-mapping.dwl** - Error transformation utilities
2. **src/main/resources/dwl/error-logger.dwl** - Standardized logging functions

---

## 🎯 **Phase 7: Validation & Testing**

### Task 7.1: Compilation Check (**MUST** Pass)
```bash
mvn clean compile
```
**MUST** achieve BUILD SUCCESS - compilation failures are not acceptable

### Task 7.2: MUnit Test Updates
- Update existing MUnit tests to handle new error structures
- Create new MUnit tests for error scenarios
- Validate error logging output format

### Task 7.3: Integration Testing
- Test error propagation through complete flows
- Validate DMV Exception Handler integration
- Verify standardized error logging

---

## 📈 **Success Criteria**

✅ **All external system calls wrapped in try-catch scopes**  
✅ **Standardized error logging implemented across all flows**  
✅ **DMV Common Exception Handler properly integrated**  
✅ **Consistent error response format (NMVTISSOL:IDENTIFIER)**  
✅ **Error identifier mapping follows contextual naming**  
✅ **No performance degradation on normal operations**  
✅ **Project compiles successfully**  
✅ **MUnit tests pass**  

---

## 🚨 **Important Notes**

1. **Error Format Consistency:** All errors must follow the `NMVTISSOL:IDENTIFIER` format
2. **Source/Target Mapping:** Clearly identify where error originated and where operation was heading
3. **Correlation ID:** Always include correlation ID for error tracking
4. **Existing Functionality:** Do not break existing error handling - enhance it
5. **Performance:** Ensure error handling doesn't impact normal flow performance
6. **Testing:** Validate all error scenarios thoroughly before deployment

---

## 📚 **Reference Documentation**

- [MuleSoft Error Handling](https://docs.mulesoft.com/mule-runtime/4.4/error-handling)
- [DMV Common Exception Handler Usage](https://github.com/ca-dmv/dmv-common-exception-handler/blob/feature/vr/README.md)
- [DataWeave 2.0 Functions](https://docs.mulesoft.com/dataweave/2.4/dw-functions)
- [APIKit Error Handling](https://docs.mulesoft.com/apikit/4.x/apikit-error-handling)

---

## 📋 **Phase 8: Detailed Analysis & Documentation Requirements**

### Task 8.1: Comprehensive Change Analysis

**When analyzing or reporting on changes made to any repository, ALWAYS provide this level of detailed analysis:**

#### **🔍 Analysis Structure Required:**

**1. Repository Context Identification:**
- Identify the specific repository and its purpose
- Note the project structure and key components
- Identify any implementation plans or documentation files

**2. Comprehensive File Analysis:**
- Read and analyze ALL relevant files that show recent changes
- Include implementation files, configuration files, and documentation
- Check for DataWeave utilities, error handling implementations, and dependency changes

**3. Detailed Change Documentation:**
- **What was implemented:** Specific technical changes with code examples
- **Where it was implemented:** Exact file paths and locations
- **How it works:** Technical explanation of the implementation approach
- **What it achieves:** Business and technical benefits

**4. Implementation Impact Analysis:**
- **Dependencies Added/Modified:** List all pom.xml changes with versions
- **New Files Created:** Document all new files and their purposes
- **Existing Files Modified:** Specific changes made to existing files
- **Configuration Updates:** Changes to global configurations, properties, etc.

**5. Technical Benefits Summary:**
- Operational improvements achieved
- Technical architecture enhancements
- Maintainability and monitoring improvements
- Integration benefits with existing frameworks

#### **📊 Required Detail Level Examples:**

**For Error Handling Changes:**
```markdown
**New DataWeave Error Handling Utilities:**
- **`error-mapping.dwl`** - Custom error mapping functions including:
  - `createErrorPayload()` - Standardized error payload structure
  - `mapErrorType()` - Maps identifiers to NMVTISSOL error types
  - `mapOperationToIdentifier()` - Maps operations to specific identifiers
  - `extractErrorInfo()` - Extracts error information from Mule error objects
```

**For Flow Implementation Changes:**
```markdown
**Implemented Error Handling in Flows:**
- **SQS Implementation** - Added comprehensive try-catch scope in `nmvtis-publish-sqs-implementation.xml`:
  - Wrapped SQS send-message operations with error handling
  - Standardized error payload format with correlation ID tracking
  - Added proper error logging and custom error propagation
```

**For Dependency Changes:**
```markdown
**Updated Dependencies:**
- Added `dmv-common-exception-handler` version 3.0.1 to pom.xml
- Maintained existing logging frameworks and custom modules
```

#### **🎯 Analysis Output Standards:**

1. **Structure:** Use clear headings and sub-sections for easy navigation
2. **Detail Level:** Include specific file names, function names, and implementation details
3. **Code Examples:** Show actual code snippets when relevant
4. **Impact Assessment:** Explain both technical and business benefits
5. **Completeness:** Cover ALL aspects of the changes found
6. **Context:** Explain how changes fit into the overall system architecture

#### **📝 Documentation Format Requirements:**

**Use this markdown structure:**
```markdown
## **Recent Changes Made to [Repository Name]**

### **1. [Primary Change Category]**
**[Detailed description with specifics]**

**[Sub-category]:**
- **`filename.ext`** - [Purpose and changes]
  - [Specific implementation details]
  - [Key functions or configurations]
  - [Integration points]

### **2. [Secondary Change Category]**
**[Implementation details with examples]**

### **3. [Impact Analysis Category]**
**[Technical and operational benefits]**

The changes represent [summary of overall impact and alignment with standards].
```

### Task 8.2: Quality Standards for Analysis

**Every analysis MUST include:**
- ✅ File-by-file breakdown of changes
- ✅ Technical implementation details with examples
- ✅ Business and operational impact explanation
- ✅ Integration points with existing frameworks
- ✅ Benefits and improvements achieved
- ✅ Clear categorization of change types
- ✅ Specific code snippets or configuration examples where relevant

---

This comprehensive prompt provides step-by-step instructions for implementing robust error handling across the VR NMVTIS SOL AAMVA eAPI v1 project, ensuring consistent error logging, proper external system connection monitoring, and integration with the DMV Common Exception Handler framework.

**ALWAYS OUTPUT COMPREHENSIVE DETAILED ANALYSIS when reviewing or documenting changes - follow the Phase 8 requirements above for the level of detail expected.**
