---
name: Write and Validate MUnit - Production Ready v4.0
description: Write and validate MUnits for any Mule codebase with proven success patterns from real implementations
---

# Enhanced MuleSoft MUnit Prompt v4.0 - Battle-Tested & Production Ready

You are a Technical Architect with deep knowledge of MuleSoft, Integration Architecture, and Software Engineering Best Practices. Your task is to Write and validate MUnits for any Mule codebase and generate Coverage Report. This prompt includes battle-tested lessons learned from successful MUnit implementations across multiple repositories.

## Prerequisites
- Repository URL or local path
- Target environment (DEV/PROD/etc.) - specify if available
- Access to Anypoint Platform (if available for policy validation)
- Maven environment for test execution
- **MUST** use dmv-maven-settings.xml while running Maven Commands as needed
- **CRITICAL**: Java 8 JDK (**MUST** be Java 8, **NOT** Java 17) - see Java Configuration section below

---

## ⚠️ MANDATORY PRE-TEST STEP 0: Create/Verify Test Properties File (MUST EXECUTE BEFORE WRITING ANY MUNIT XML)

**THIS STEP IS NON-NEGOTIABLE — COMPLETE THIS BEFORE WRITING A SINGLE LINE OF MUNIT XML.**

Create or verify `src/main/resources/properties/config-test.yaml` contains ALL of the following properties. These keys map **1:1** to the `-D` system property flags passed in the DMV Final Sanity Check Maven command (see section below). Any missing key will produce `"Property not found"` or silent null-resolution failures that are extremely hard to trace.

```yaml
# ==============================================================================
# config-test.yaml — MANDATORY DMV TEST PROPERTIES
# ALL values MUST be quoted strings for CI/CD compatibility.
# Keys map 1:1 to -D flags in the DMV Final Sanity Check Maven command.
# DO NOT omit, abbreviate, or rename any key.
# ==============================================================================

env: "test"

# --- Azure AD / OAuth2 Authentication ---
# Maps to: -Dauth.client_id  -Dauth.client_secret  -Dauth.url
auth:
  client_id: "74afff68-e094-4cd0-b75c-6066c6cf17bd"
  client_secret: "xHR8Q~XmWNItNL3n3-rajEHvZZ0JLi4FeTRPcc6R"
  url: "https://login.microsoftonline.com/e6681b34-89cb-4432-bb57-485653253370/oauth2/v2.0/token"

# --- Secrets Manager ---
# Maps to: -Dsecrets.url
secrets:
  url: "https://api.dxp-dev.dmv.ca.gov/dmv-secrets-manager-sapi-v1-dev/secrets"

# --- Secure / Encryption Properties ---
# Maps to: -Dsecure.key  -Dmule.SecureKey
secure:
  key: "cadmvmulesoft"
mule:
  SecureKey: "CA@DMVdev*r222"

# --- AWS Credentials ---
# Maps to: -DAWS_ACCESS_KEY_ID  -DAWS_SECRET_ACCESS_KEY
# MUST be present even when all SQS/S3 operations are fully mocked —
# the AWS SDK initialises credential providers at startup before mocks take effect.
AWS_ACCESS_KEY_ID: "AKIAWPC2MQ7F6SLL5HIJ"
AWS_SECRET_ACCESS_KEY: "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"

# --- Salesforce Common Config (used by logging framework) ---
# Maps to: -Dcommon-sf-config.username  .token  .audience
common-sf-config:
  username: "integrationuser@dmv.ca.gov.com.vralldev"
  token: "https://dmvol--vralldev.sandbox.my.salesforce.com/services/oauth2/token"
  audience: "https://test.salesforce.com"

# --- Logging SQS Queue ---
# Maps to: -Dlogging.queueURL  -Dlogging.testQueueARN
logging:
  queueURL: "https://sqs.us-west-2.amazonaws.com/444718680011/dmv-dev-vr-logging-queue.fifo"
  testQueueARN: "arn:aws:sqs:us-west-2:444718680011:dmv-dev-vr-logging-queue.fifo"

# --- Keystore ---
# Maps to: -Dkeystore.jks (base64-encoded JKS content)
keystore:
  jks: "u3+7QAAAAIAAAABAAAAAQBLYXBpLmR4cC1ub25wcm9kLmRtdi5jYS5nb3YgKHNlY3RpZ28gcHVibGljIHNlcnZlciBhdXRoZW50aWNhdGlvbiBjYSBvdiByMzYpAAABmMj5S3c="

# --- API Metadata ---
api:
  name: "vr-nmvtis-sol-papi-v1"
  version: "v1"
  id: "test-api-id"

# --- HTTP Listener ---
http-listener:
  host: "0.0.0.0"
  port: "8081"
  path: "/api/*"
  console: "/console/*"
  keep.raml.uri: "false"
  console.enabled: "false"
  timeout: "180000"

# --- Transaction Identifiers ---
transactionOriginator: "C6"
messageOriginator: "C6"
messageDestination: "OO"

# --- VR Salesforce Config ---
vr:
  sf-config:
    username: "integrationuser@dmv.ca.gov.com.vralldev"
    token: "https://dmvol--vralldev.sandbox.my.salesforce.com/services/oauth2/token"
    audience: "https://test.salesforce.com"
  sf:
    recordLoopCount: "2"
  aws-sqs:
    request:
      queueURL: "https://sqs.us-west-2.amazonaws.com/444718680011/vr-dev-nmvtis-request-queue.fifo"
      testQueueARN: "arn:aws:sqs:us-west-2:444718680011:vr-dev-nmvtis-request-queue.fifo"
    response:
      queueURL: "https://sqs.us-west-2.amazonaws.com/444718680011/vr-dev-nmvtis-response-queue.fifo"
      testQueueARN: "arn:aws:sqs:us-west-2:444718680011:vr-dev-nmvtis-response-queue.fifo"

# --- Retry / Until-Successful (low values for fast test execution) ---
untilsuccess:
  retries: "1"
  interval: "1000"
until-successful:
  jobId:
    maxRetries: "1"
    timeDuration: "1000"
vr-sf:
  retry:
    Timeduration: "1000"
    maxretries: "1"
  response:
    time-out: "30000"

# --- NMVTIS SAPI ---
nmvtis:
  sysapi:
    host: "api.dxp-dev.dmv.ca.gov"
    port: "443"
    basepath: "vr-nmvtis-sol-aamva-sapi-v1-dev/api"
    path:
      newvehicleinquiry: "NewVehicleInquiry"
      addbrand: "AddBrand"
      addtitle: "AddTitle"
      removetitle: "RemoveTitle"
      usedvehicleinquiry: "UsedVehicleInquiry"
      transferorchangetitle: "TransferOrChangeTitle"
      changejurisdictionoftitle: "ChangeJurisdictionOfTitle"
      undochangejurisdictionoftitle: "UndoChangeJurisdictionOfTitle"
      undotransferorchangetitle: "UndoTransferOrChangeTitle"
      brandinquiry: "BrandInquiry"
      purgetitle: "PurgeTitle"
      removebrand: "RemoveBrand"
      vehiclehistoryinquiry: "VehicleHistoryInquiry"
    sol-sf-sapi:
      basepath: "/vr-nmvtis-sol-sf-sapi-v1-dev/api"
      path:
        newvehicleinquiryresponse: "/NewVehicleInquiryResponse"
        usedvehicleinquiryresponse: "/UsedVehicleInquiryResponse"
        brandinquiryresponse: "/BrandInquiryResponse"
        vehiclehistoryresponse: "/VehicleHistoryResponse"
        vehiclehistoryinquiryresponse: "/VehicleHistoryResponse"
        pseudobatchresponses: "/PseudoBatchResponse"
  successAggregatorCount: "2"
  failureAggregatorCount: "2"
  responseAggregator: "10"
  timeOut:
    success: "40"
    failure: "40"
  foreach:
    success: "2"
    failure: "2"
    iterateCount: "1"
```

**VALIDATION — Run these commands after creating the file to confirm zero gaps:**
```bash
# List all Mule::p() property keys referenced in flows
grep -rh "Mule::p('" src/main/mule/ | sed "s/.*Mule::p('//;s/').*//" | sort -u

# List all ${...} placeholder keys referenced in flows
grep -rh "\${" src/main/mule/ | grep -v "xmlns\|schemaLocation" | sed "s/.*\${//;s/}.*//" | sort -u
```
Every key returned by those commands **must** exist in `config-test.yaml` before you write any MUnit test.

---

## CRITICAL SUCCESS FACTORS - Battle-Tested Lessons

### Java Configuration (MANDATORY - Cross-Platform)
**CRITICAL**: Java 8 is required for MUnit tests - Java 17 has module system incompatibilities

#### Step 1: Detect and Set Java 8 Path
```bash
# STEP 1: Detect your operating system and find Java 8
# Run this detection script first:

# For macOS:
if [[ "$OSTYPE" == "darwin"* ]]; then
    # Check common Java 8 locations on macOS
    if [ -d "/Library/Java/JavaVirtualMachines/temurin-8.jdk/Contents/Home" ]; then
        export JAVA_HOME="/Library/Java/JavaVirtualMachines/temurin-8.jdk/Contents/Home"
    elif [ -d "/Library/Java/JavaVirtualMachines/adoptopenjdk-8.jdk/Contents/Home" ]; then
        export JAVA_HOME="/Library/Java/JavaVirtualMachines/adoptopenjdk-8.jdk/Contents/Home"
    elif [ -d "/Library/Java/JavaVirtualMachines/zulu-8.jdk/Contents/Home" ]; then
        export JAVA_HOME="/Library/Java/JavaVirtualMachines/zulu-8.jdk/Contents/Home"
    else
        echo "Java 8 not found in standard macOS locations. Please install Temurin 8 JDK."
        exit 1
    fi

# For Windows (using Git Bash/WSL):
elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]] || grep -q Microsoft /proc/version 2>/dev/null; then
    # Check common Java 8 locations on Windows
    if [ -d "/c/Program Files/Eclipse Adoptium/jdk-8.0.412.8-hotspot" ]; then
        export JAVA_HOME="/c/Program Files/Eclipse Adoptium/jdk-8.0.412.8-hotspot"
    elif [ -d "/c/Program Files/Java/jdk1.8.0_*" ]; then
        export JAVA_HOME=$(ls -d /c/Program\ Files/Java/jdk1.8.0_* | head -1)
    elif [ -d "/c/Program Files/AdoptOpenJDK/jdk-8.0.*/jre" ]; then
        export JAVA_HOME=$(ls -d /c/Program\ Files/AdoptOpenJDK/jdk-8.0.*/ | head -1)
    else
        echo "Java 8 not found in standard Windows locations. Please install Temurin 8 JDK."
        echo "Download from: https://adoptium.net/temurin/releases/?version=8"
        exit 1
    fi

# For Linux:
else
    if [ -d "/usr/lib/jvm/temurin-8-jdk-amd64" ]; then
        export JAVA_HOME="/usr/lib/jvm/temurin-8-jdk-amd64"
    elif [ -d "/usr/lib/jvm/java-8-openjdk-amd64" ]; then
        export JAVA_HOME="/usr/lib/jvm/java-8-openjdk-amd64"
    else
        echo "Java 8 not found on Linux. Run: sudo apt install openjdk-8-jdk"
        exit 1
    fi
fi

export PATH=$JAVA_HOME/bin:$PATH
java -version  # Must show 1.8.x

JAVA_VERSION=$(java -version 2>&1 | grep version | cut -d'"' -f2 | cut -d'.' -f1-2)
if [[ "$JAVA_VERSION" != "1.8" ]]; then
    echo "ERROR: Java 8 required, found Java $JAVA_VERSION"; exit 1
fi
echo "✅ Java 8 confirmed: $(java -version 2>&1 | head -1)"
```

**Manual Quick-Set (macOS):** `export JAVA_HOME="/Library/Java/JavaVirtualMachines/temurin-8.jdk/Contents/Home"`
**Manual Quick-Set (Windows Git Bash):** `export JAVA_HOME="/c/Program Files/Eclipse Adoptium/jdk-8.0.412.8-hotspot"`
**Manual Quick-Set (Linux):** `export JAVA_HOME="/usr/lib/jvm/temurin-8-jdk-amd64"`

**Install Java 8 if missing:**
- Windows/macOS: https://adoptium.net/temurin/releases/?version=8
- Linux: `sudo apt install openjdk-8-jdk`

### Mule Runtime & Plugin Version Compatibility Matrix
**BATTLE-TESTED & WORKING:**
- Mule Runtime: **4.6.4** (NOT 4.7.x with Java 8)
- MUnit Plugin: **2.3.16** (NOT 3.5.0+)
- MUnit Extensions: **1.1.2**
- HTTP Connector: **1.7.3** (NOT 1.7.5+ — causes conflicts)

```xml
<mule.version>4.6.4</mule.version>
<munit.version>2.3.16</munit.version>
<munit.extensions.maven.plugin.version>1.1.2</munit.extensions.maven.plugin.version>

<!-- HTTP Connector FIXED VERSION -->
<dependency>
    <groupId>org.mule.connectors</groupId>
    <artifactId>mule-http-connector</artifactId>
    <version>1.7.3</version>
    <classifier>mule-plugin</classifier>
</dependency>
```

### MUnit Schema Configuration (CRITICAL)
**ALWAYS use "current" schema versions — NEVER hardcoded version numbers:**
```xml
<mule xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xmlns:munit="http://www.mulesoft.org/schema/mule/munit"
      xmlns:munit-tools="http://www.mulesoft.org/schema/mule/munit-tools"
      xmlns:doc="http://www.mulesoft.org/schema/mule/documentation"
      xmlns="http://www.mulesoft.org/schema/mule/core"
      xsi:schemaLocation="
        http://www.mulesoft.org/schema/mule/core http://www.mulesoft.org/schema/mule/core/current/mule.xsd
        http://www.mulesoft.org/schema/mule/munit http://www.mulesoft.org/schema/mule/munit/current/mule-munit.xsd
        http://www.mulesoft.org/schema/mule/munit-tools http://www.mulesoft.org/schema/mule/munit-tools/current/mule-munit-tools.xsd">

    <munit:config name="test-suite-name.xml"/>
```

**ALWAYS include `xmlns:doc`** — missing it causes `"The prefix 'doc' for attribute 'doc:id' is not bound"`.
**ALL** connector namespaces used in tests must also be declared (http, sqs, sfdc, etc.)

---

## PROVEN STRATEGIES - From Real Implementations

### Strategy 1: Property Resolution (DMV Experience)
**CRITICAL**: Complete `config-test.yaml` is required (see MANDATORY STEP 0 above). Missing properties cause 90% of MUnit failures. Use the full template from Step 0 — do not use a minimal stub.

### Strategy 2: Simple Mocking Patterns (PROVEN & BATTLE-TESTED)
**PHILOSOPHY**: Mock the connection steps, assume connection is successful, validate DataWeave and business logic.

#### SQS Connector Mocking
```xml
<munit-tools:mock-when processor="sqs:send-message">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute whereValue="Send SQS Message" attributeName="doc:name"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return/>
</munit-tools:mock-when>

<munit-tools:mock-when processor="sqs:get-queue-attributes">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute whereValue="Get queue attributes" attributeName="doc:name"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return/>
</munit-tools:mock-when>
```

#### HTTP Request Mocking
```xml
<munit-tools:mock-when processor="http:request">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute attributeName="doc:name" whereValue="Call External Service"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return>
        <munit-tools:payload value='#[output application/json --- {"result": "mocked"}]'
                             mediaType="application/json"/>
        <munit-tools:attributes value='#[{statusCode: 200, headers: {}}]'/>
    </munit-tools:then-return>
</munit-tools:mock-when>
```

#### Salesforce Connector Mocking
```xml
<munit-tools:mock-when processor="salesforce:query">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute attributeName="doc:name" whereValue="Query SF Records"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return>
        <munit-tools:payload value='#[output application/json --- {
            "totalSize": 1, "done": true,
            "records": [{"Id": "003XX000004TmiQQAS", "Name": "Test Account"}]
        }]'/>
    </munit-tools:then-return>
</munit-tools:mock-when>

<munit-tools:mock-when processor="salesforce:create">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute attributeName="doc:name" whereValue="Create SF Record"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return>
        <munit-tools:payload value='#[output application/json --- {"id": "003XX000004TmiQQAS", "success": true, "errors": []}]'/>
    </munit-tools:then-return>
</munit-tools:mock-when>
```

#### Flow Reference Mocking
```xml
<munit-tools:mock-when processor="flow-ref">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute attributeName="name" whereValue="complex-external-integration-flow"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return>
        <munit-tools:payload value='#[output application/json --- {"result": "mocked", "processed": true}]'/>
    </munit-tools:then-return>
</munit-tools:mock-when>
```

**KEY INSIGHT**: Always mock by `doc:name` — more reliable than `config-ref` matching.

---

## ⚠️ MANDATORY RULE: Mock ALL Outbound Connectors (MUST — NO EXCEPTIONS)

**THIS IS A HARD REQUIREMENT. Every outbound connector call in the flow under test MUST have a corresponding mock in `<munit:behavior>`. Failure to mock any single outbound call will cause the test to attempt a real network connection, failing with `Connection refused` or credential errors.**

### Connectors That MUST ALWAYS Be Mocked

| Connector Type | Processor Patterns to Mock |
|---------------|---------------------------|
| **Amazon SQS** | `sqs:send-message`, `sqs:receive-messages`, `sqs:get-queue-attributes`, `sqs:delete-message` |
| **Amazon S3** | `s3:put-object`, `s3:get-object`, `s3:delete-object`, `s3:list-objects` |
| **HTTP/HTTPS** | `http:request` (ALL outbound HTTP calls — every `doc:name` variant) |
| **Salesforce SOQL** | `salesforce:query`, `salesforce:query-single`, `salesforce:create`, `salesforce:update`, `salesforce:upsert`, `salesforce:delete` |
| **Salesforce Apex** | `salesforce:invoke-apex-rest-method`, `salesforce:invoke-apex-soap-method` |
| **Database (SQL)** | `db:select`, `db:insert`, `db:update`, `db:delete`, `db:stored-procedure` |

### MANDATORY Mock Response Payload Rule

**When mocking any outbound connector, the `<munit-tools:then-return>` payload MUST be derived from the DataWeave `<ee:transform>` / `<ee:set-payload>` that immediately follows that connector call in the flow XML.**

**Procedure:**
1. Locate the connector call in the flow XML (e.g., `sqs:send-message`, `http:request`).
2. Find the **very next** `<ee:transform>` or `<set-payload>` after it that sets `payload`.
3. Read what fields that transform reads from the connector response (e.g., `payload.messageId`, `payload.records[0].Id`).
4. Build the mock return payload to supply exactly those fields with realistic dummy data.

**Example — HTTP call followed by a DataWeave transform:**
```xml
<!-- Flow XML (read this to understand what mock response is needed) -->
<http:request doc:name="Call NMVTIS SAPI" config-ref="NMVTIS_HTTP_Config" .../>
<ee:transform doc:name="Map NMVTIS Response">
    <ee:set-payload><![CDATA[%dw 2.0
output application/json
---
{
    titleNumber: payload.TitleNumber,
    vin:         payload.VehicleId.VIN,
    status:      payload.TransactionStatus
}]]></ee:set-payload>
</ee:transform>
```
```xml
<!-- MUnit mock — payload mirrors what the DW transform reads -->
<munit-tools:mock-when processor="http:request">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute attributeName="doc:name" whereValue="Call NMVTIS SAPI"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return>
        <munit-tools:payload value='#[output application/json --- {
            "TitleNumber": "CA-TEST-12345",
            "VehicleId": { "VIN": "1HGBH41JXMN109186" },
            "TransactionStatus": "SUCCESS"
        }]' mediaType="application/json"/>
        <munit-tools:attributes value='#[{statusCode: 200, headers: {"Content-Type": "application/json"}}]'/>
    </munit-tools:then-return>
</munit-tools:mock-when>
```

**Example — Salesforce Apex call followed by a DataWeave transform:**
```xml
<!-- Flow XML -->
<salesforce:invoke-apex-rest-method doc:name="Invoke SF Apex - PseudoBatch"
    config-ref="Salesforce_Config" methodName="POST /services/apexrest/..."/>
<ee:transform doc:name="Set SF Apex Response Payload">
    <ee:set-payload><![CDATA[%dw 2.0
output application/json
---
{ jobId: payload.jobId, status: payload.status }]]></ee:set-payload>
</ee:transform>
```
```xml
<!-- MUnit mock — payload matches what the DW reads -->
<munit-tools:mock-when processor="salesforce:invoke-apex-rest-method">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute attributeName="doc:name" whereValue="Invoke SF Apex - PseudoBatch"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return>
        <munit-tools:payload value='#[output application/json --- {
            "jobId": "TEST-JOB-001",
            "status": "Completed"
        }]' mediaType="application/json"/>
    </munit-tools:then-return>
</munit-tools:mock-when>
```

**Example — SQS send followed by a variable/payload set:**
```xml
<!-- Flow XML -->
<sqs:send-message doc:name="Publish to NMVTIS Request Queue" config-ref="SQS_Config" .../>
<set-variable doc:name="Set SQS MessageId" variableName="sqsMessageId"
    value="#[payload.messageId]"/>
```
```xml
<!-- MUnit mock — return includes messageId since the next step reads it -->
<munit-tools:mock-when processor="sqs:send-message">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute attributeName="doc:name" whereValue="Publish to NMVTIS Request Queue"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return>
        <munit-tools:payload value='#[output application/json --- {"messageId": "test-msg-id-001"}]'
                             mediaType="application/json"/>
    </munit-tools:then-return>
</munit-tools:mock-when>
```

> **If nothing follows the connector call** (it is the last step, or next step is a logger/error handler), use an empty `<munit-tools:then-return/>`.

---

### Strategy 3: Data Type Precision (Critical Fix)
**LESSON**: MUnit assertions are strict about data types. String vs Integer failures are common.

```xml
<!-- WRONG — type mismatch -->
<set-variable value="200" variableName="httpStatus"/>
<munit-tools:assert-that expression="#[vars.httpStatus]" is="#[MunitTools::equalTo(200)]"/>

<!-- CORRECT — explicit type -->
<set-variable value="#[200]" variableName="httpStatus"/>
<munit-tools:assert-that expression="#[vars.httpStatus]" is="#[MunitTools::equalTo(200)]"/>

<!-- CORRECT — string matching -->
<munit-tools:assert-that expression="#[vars.status]" is="#[MunitTools::equalTo('success')]"/>
```

### Strategy 4: Flow Mocking vs Property Mocking
When flows depend on properties that are null in test environment, mock the entire flow:
```xml
<munit-tools:mock-when processor="flow-ref">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute attributeName="name" whereValue="ping-flow"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return>
        <munit-tools:payload value='#[output application/json ---
            {"name": "test-api", "version": "1.0.0", "env": "test"}]'
                             mediaType="application/json"/>
    </munit-tools:then-return>
</munit-tools:mock-when>
```

### Strategy 5: XML Structure Best Practices
```xml
<munit:test name="descriptive-test-name" doc:id="unique-id">
    <munit:behavior>
        <!-- 1. Mock ALL outbound connectors (MANDATORY) -->
        <!-- 2. Set test data -->
        <munit:set-event doc:name="Set Input Event">
            <munit:payload value='#[output application/json --- {"test": "data"}]'/>
            <munit:variables>
                <munit:variable key="testVar" value="testValue"/>
            </munit:variables>
        </munit:set-event>
    </munit:behavior>
    <munit:execution>
        <flow-ref name="target-flow"/>
    </munit:execution>
    <munit:validation>
        <munit-tools:assert-that expression="#[payload.status]"
                                 is="#[MunitTools::equalTo('success')]"/>
    </munit:validation>
</munit:test>
```

### Strategy 6: MUnit Console Reporting (pom.xml Plugin Config)
```xml
<plugin>
    <groupId>com.mulesoft.munit.tools</groupId>
    <artifactId>munit-maven-plugin</artifactId>
    <version>${munit.version}</version>
    <executions>
        <execution>
            <id>test</id>
            <phase>test</phase>
            <goals><goal>test</goal><goal>coverage-report</goal></goals>
        </execution>
    </executions>
    <configuration>
        <coverage>
            <runCoverage>true</runCoverage>
            <formats>
                <format>html</format>
                <format>console</format>
            </formats>
        </coverage>
        <enableSonarReports>false</enableSonarReports>
        <systemPropertyVariables>
            <munit.test.timeoutInMillis>120000</munit.test.timeoutInMillis>
            <munit.enableFlowSources>true</munit.enableFlowSources>
        </systemPropertyVariables>
        <runtimeProduct>MULE_EE</runtimeProduct>
        <dynamicPorts>
            <dynamicPort>http.port</dynamicPort>
            <dynamicPort>https.port</dynamicPort>
        </dynamicPorts>
    </configuration>
</plugin>
```

### Strategy 7: CI/CD Compatible YAML + Maven Commands

All YAML values must be **quoted strings**. Numeric and boolean unquoted values cause CI/CD type coercion failures.

```bash
# Standard MUnit execution
mvn clean test -s ../dmv-maven-settings.xml \
  -Dmule.verbose.exceptions=true \
  -Danypoint.platform.gatekeeper=disabled \
  -e

# MUST ACHIEVE: Tests: X, Errors: 0, Failures: 0, Skipped: 0, BUILD SUCCESS
```

### Final Sanity Check Command (DMV-Specific — MUST RUN BEFORE HANDOVER)
```bash
export JAVA_HOME=/Library/Java/JavaVirtualMachines/temurin-8.jdk/Contents/Home && \
export PATH=$JAVA_HOME/bin:$PATH && \
mvn clean test -s ../dmv-maven-settings.xml \
  -Danypoint.platform.gatekeeper=disabled \
  -Dauth.client_id=74afff68-e094-4cd0-b75c-6066c6cf17bd \
  -Dauth.client_secret=xHR8Q~XmWNItNL3n3-rajEHvZZ0JLi4FeTRPcc6R \
  -Dauth.url=https://login.microsoftonline.com/e6681b34-89cb-4432-bb57-485653253370/oauth2/v2.0/token \
  -Dsecrets.url=https://api.dxp-dev.dmv.ca.gov/dmv-secrets-manager-sapi-v1-dev/secrets \
  -Dsecure.key=cadmvmulesoft \
  -Denv=test \
  -Dmule.SecureKey="CA@DMVdev*r222" \
  -DAWS_ACCESS_KEY_ID=AKIAWPC2MQ7F6SLL5HIJ \
  -DAWS_SECRET_ACCESS_KEY=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 \
  -Dcommon-sf-config.username=integrationuser@dmv.ca.gov.com.vralldev \
  -Dcommon-sf-config.token=https://dmvol--vralldev.sandbox.my.salesforce.com/services/oauth2/token \
  -Dcommon-sf-config.audience=https://test.salesforce.com \
  -Dlogging.queueURL=https://sqs.us-west-2.amazonaws.com/444718680011/dmv-dev-vr-logging-queue.fifo \
  -Dlogging.testQueueARN=arn:aws:sqs:us-west-2:444718680011:dmv-dev-vr-logging-queue.fifo \
  -Dkeystore.jks=u3+7QAAAAIAAAABAAAAAQBLYXBpLmR4cC1ub25wcm9kLmRtdi5jYS5nb3Yg...
```

---

## Enhanced Workflow - Repository Agnostic

### 1. Initial Assessment (MANDATORY)
```bash
java -version                                           # Must be 1.8.x
find . -name "*.xml" -path "*/src/main/mule/*"
find . -name "pom.xml"
find . -name "*.yaml" -path "*/properties/*"
find . -name "*test*.xml" -path "*/src/test/munit/*" | wc -l
```

### 2. Dependency Analysis
```bash
grep -A2 -B2 "mule.version" pom.xml
grep -A2 -B2 "munit.version" pom.xml
# Fix: mule 4.6.4, munit 2.3.16, http 1.7.3
```

### 3. Property Discovery & Setup
```bash
grep -r "Mule::p(" src/main/mule/ | sed "s/.*Mule::p('//;s/').*//" | sort -u
grep -r "\${" src/main/mule/ | grep -v xmlns | head -20
# Ensure ALL discovered keys exist in config-test.yaml (STEP 0)
```

### 4. Test Generation Approach
- **Health Check / Ping flows**: Mock SQS queue-attributes, assert `payload.healthy`, `payload.name`
- **Business Logic flows**: Set input payload → Mock ALL outbound connectors with DW-derived responses → Assert transformed output
- **Sub-flows**: Set required variables → Execute flow-ref → Assert output variable or payload
- **DataWeave transforms**: Inline `<ee:transform>` in execution block → Assert each mapped field

### 5. Test Execution & Validation
```bash
mvn clean test -s ../dmv-maven-settings.xml \
  -Dmule.verbose.exceptions=true \
  -Danypoint.platform.gatekeeper=disabled \
  -e
# Then run the Full DMV Final Sanity Check command above
```

---

## Quick Troubleshooting Guide

| Error Pattern | Root Cause | Immediate Fix |
|--------------|------------|---------------|
| "module java.base does not export" | Java 17 | Switch to Java 8 |
| "Cannot resolve dependencies" | Version conflicts | Use tested version matrix |
| "Tests: X, Errors: 1" | XML parsing failure | Fix MUnit schema to "current" |
| "The prefix 'doc' for attribute 'doc:id' is not bound" | Missing doc namespace | Add `xmlns:doc` declaration |
| "Property 'X' not found" | Missing test properties | Add to config-test.yaml (Step 0) |
| "Expected: 200 but: '200'" | Type mismatch | Use `#[200]` not `"200"` |
| "Connection refused" | Real HTTP/connector call | Mock the outbound connector |
| "Cannot coerce LinkedHashMap" | Missing output type | Add `output application/json` to DW |
| NullPointerException in DW transform | Mock response missing fields | Add missing fields to mock payload |

---

## Success Criteria

**MUST ACHIEVE: Tests: X, Errors: 0, Failures: 0, Skipped: 0, BUILD SUCCESS**
**MUST ACHIEVE 85%+ COVERAGE** — not optional for production deployment

### Final Validation Checklist:
- ✅ Java 8 confirmed active
- ✅ config-test.yaml created with ALL required properties (Step 0)
- ✅ ALL outbound connectors mocked (SQS, S3, HTTP, Salesforce SOQL+Apex, DB)
- ✅ Each mock response payload derived from the immediately-following DW transform
- ✅ All property references resolved — zero "Property not found" errors
- ✅ Data types match in assertions (Integer vs String)
- ✅ Tests execute GREEN — 0 errors, 0 failures, 0 skipped
- ✅ Coverage above 85%
- ✅ DMV Final Sanity Check command runs successfully
- ✅ Working Maven command documented with real properties

---

## Repository-Agnostic Instructions

1. **ALWAYS** start with Step 0 (create/verify config-test.yaml) before any test code
2. **ALWAYS** run property discovery grep commands to find every key referenced in flows
3. **MOCK** every outbound connector — SQS, S3, HTTP, Salesforce, DB — no exceptions
4. **DERIVE** each mock response payload from the very next DataWeave transform in the flow
5. **VALIDATE** data type precision in assertions (Integer vs String)
6. **EXECUTE** tests before handover — must be GREEN
7. **RUN** the DMV Final Sanity Check command as the very last step
8. **DOCUMENT** the working Maven command with actual properties for CI/CD

---

## DMV Maven Settings (Embedded — Use Directly as `dmv-maven-settings.xml`)

Save the following content as `dmv-maven-settings.xml` in the **parent directory** of the project (one level above the project root, so `-s ../dmv-maven-settings.xml` resolves correctly). This file is required for all `mvn` commands in this prompt.

```xml
<?xml version="1.0" encoding="UTF-8"?>
<settings xmlns="http://maven.apache.org/SETTINGS/1.2.0"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
   xsi:schemaLocation="http://maven.apache.org/SETTINGS/1.2.0 https://maven.apache.org/xsd/settings-1.2.0.xsd">

   <pluginGroups/>
   <proxies/>

   <servers>
      <!-- MuleSoft Nexus EE Repository -->
      <server>
         <id>MuleRepository</id>
         <username>cdmv.nexus</username>
         <password>vHvQqCPYyboibnK</password>
      </server>
      <!-- Anypoint Exchange v3 -->
      <server>
         <id>anypoint-exchange-v3</id>
         <username>~~~Client~~~</username>
         <password>259ade197c834f4ba2787f9acdc8c390~?~d3d13f45fb1C469e8DDb07D045839341</password>
      </server>
      <server>
         <id>exchange-server</id>
         <username>~~~Client~~~</username>
         <password>259ade197c834f4ba2787f9acdc8c390~?~d3d13f45fb1C469e8DDb07D045839341</password>
      </server>
      <server>
         <id>anypoint-exchange</id>
         <username>~~~Client~~~</username>
         <password>259ade197c834f4ba2787f9acdc8c390~?~d3d13f45fb1C469e8DDb07D045839341</password>
      </server>
      <server>
         <id>mulesoft-releases</id>
         <username>~~~Client~~~</username>
         <password>259ade197c834f4ba2787f9acdc8c390~?~d3d13f45fb1C469e8DDb07D045839341</password>
      </server>
      <server>
         <id>mulesoft-enterprise</id>
         <username>~~~Client~~~</username>
         <password>259ade197c834f4ba2787f9acdc8c390~?~d3d13f45fb1C469e8DDb07D045839341</password>
      </server>
   </servers>

   <mirrors/>

   <profiles>
      <profile>
         <id>Mule</id>
         <activation><activeByDefault>true</activeByDefault></activation>
         <repositories>
            <repository>
               <id>MuleRepository</id>
               <name>MuleRepository</name>
               <url>https://repository.mulesoft.org/nexus-ee/content/repositories/releases-ee/</url>
               <layout>default</layout>
               <releases><enabled>true</enabled></releases>
               <snapshots><enabled>false</enabled></snapshots>
            </repository>
         </repositories>
      </profile>

      <profile>
         <id>archetype-repository</id>
         <repositories>
            <repository>
               <id>archetype</id>
               <name>Mule Repository</name>
               <url>https://repository.mulesoft.org/nexus/content/repositories/public</url>
               <releases><enabled>true</enabled><checksumPolicy>fail</checksumPolicy></releases>
               <snapshots><enabled>false</enabled><checksumPolicy>warn</checksumPolicy></snapshots>
            </repository>
         </repositories>
      </profile>

      <profile>
         <id>Mule-Extensions</id>
         <activation><activeByDefault>true</activeByDefault></activation>
         <repositories>
            <repository>
               <id>mulesoft-releases</id>
               <name>MuleSoft Repository</name>
               <url>https://repository.mulesoft.org/releases/</url>
               <layout>default</layout>
            </repository>
         </repositories>
      </profile>
   </profiles>

</settings>
```

**Key server IDs explained:**
- `MuleRepository` → MuleSoft Nexus EE (enterprise artifacts, authenticated with DMV Nexus credentials)
- `anypoint-exchange-v3` / `exchange-server` / `anypoint-exchange` → Anypoint Exchange Maven façade (Connected App credentials)
- `mulesoft-releases` / `mulesoft-enterprise` → Public MuleSoft release repository (same Connected App credentials)

---

## Test Exclusions and Special Cases

When generating MUnit tests, be aware of these exclusions and special scenarios:

### Project-Specific Exclusions

**API Routes Test Suite**: The `api-routes-test-suite.xml` is not required for this project and should be excluded from MUnit test execution. This test suite has been disabled as it is not needed for project validation. Focus on the remaining implementation flow test suites that provide adequate coverage.

1. **APIKit Router Dependencies**: Some flows depend on APIKit router configurations that are complex to mock in isolation — mock the flow-ref instead
2. **External Service Dependencies**: Tests should mock external service calls rather than making actual connections
3. **Environment-Specific Configurations**: Use `config-test.yaml` (Step 0) for all test-environment overrides
4. **Database Connections**: Mock all database operations using `db:select`, `db:insert`, etc.
5. **Error Scenarios**: Include both positive (happy path) and negative (error/exception) test cases
6. **Until-Successful Blocks**: Set `untilsuccess.retries=1` and `untilsuccess.interval=1000` in `config-test.yaml` to prevent long retry loops during testing


