# Add New Endpoints Guide - /ping and /health-check

This guide provides step-by-step instructions for adding /ping and /health-check endpoints to MuleSoft APIs.

## Prerequisites
- **MUST** ensure you have Java 8 configured: `export JAVA_HOME=/Library/Java/JavaVirtualMachines/temurin-8.jdk/Contents/Home`
- **MUST** have access to DMV Maven settings file

## Step 1: Review and Locate RAML Specification
Review and detect the RAML. It is either referenced in the POM or locally under `src/main/resources/api` folder. 
- **If local**: Make changes directly in the local RAML file
- **If from Exchange**: Download the RAML first to `src/main/resources/api` folder, then make changes locally

## Step 2: Update RAML Specification
Reference the standard DMV template: https://anypoint.mulesoft.com/designcenter/designer/#/project/e2811cca-6698-46b4-b200-3d74ae813f78 (vr-common-api-template in Vehicle Registration Org Design Center)

Add the `/ping` and `/health-check` endpoints exactly as specified in the template.

## Step 3: Update APIKit Configuration
Once local RAML changes are completed, ensure the APIKit router in the code references the updated local RAML file.

## Step 4: Implementation Patterns
Reference: https://github.com/ca-dmv/dmv-vr-git-repo-template-v2 develop branch

Implement exactly the pattern of ping and health-check this template project uses:

### Ping Endpoint Implementation
- Simple response with API metadata
- Set HTTP status to 200
- Return JSON with name, version, env, success fields
- Use Mule property placeholders for dynamic values

### Health-Check Endpoint Implementation
- **Use scatter-gather ONLY when multiple external dependencies need to be checked**
- **If only one external system**: Use simple try-catch without scatter-gather
- Each route in scatter-gather should have proper `<try>` blocks with `<error-handler>`
- Replace template dummy targets with actual API dependencies
- Common targets: Database connections, external API endpoints, message queues

### Critical Error Handling Rules
1. **ALWAYS wrap error-handlers in `<try>` blocks**: Never place `<error-handler>` directly in routes or flows
2. **Scatter-gather usage**: Only use when checking multiple independent systems
3. **Single dependency**: Use simple HTTP request with try-catch error handling

## Step 5: Build Validation (**MUST** Pass)
**CRITICAL**: **MUST** always run Maven build to ensure compilation success before proceeding.

### Quick Build Command (**MUST** Succeed):
```bash
cd project-directory && mvn clean compile
```
**MUST** achieve BUILD SUCCESS - compilation failures are not acceptable

### Full Build with DMV Settings:
```bash
export JAVA_HOME=/Library/Java/JavaVirtualMachines/temurin-8.jdk/Contents/Home && export PATH=$JAVA_HOME/bin:$PATH && mvn clean install -s ../dmv-maven-settings.xml -Danypoint.platform.gatekeeper=disabled -Dauth.client_id=74afff68-e094-4cd0-b75c-6066c6cf17bd -Dauth.client_secret=xHR8Q~XmWNItNL3n3-rajEHvZZ0JLi4FeTRPcc6R -Dauth.url=https://login.microsoftonline.com/e6681b34-89cb-4432-bb57-485653253370/oauth2/v2.0/token -Dsecrets.url=https://api.dxp-dev.dmv.ca.gov/dmv-secrets-manager-sapi-v1-dev/secrets -Dsecure.key=cadmvmulesoft -Denv=test -Dmule.SecureKey="CA@DMVdev*r222" -DAWS_ACCESS_KEY_ID=AKIAWPC2MQ7F6SLL5HIJ -DAWS_SECRET_ACCESS_KEY=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 -Dcommon-sf-config.username=integrationuser@dmv.ca.gov.com.vralldev -Dcommon-sf-config.token=https://dmvol--vralldev.sandbox.my.salesforce.com/services/oauth2/token -Dcommon-sf-config.audience=https://test.salesforce.com -Dlogging.queueURL=https://sqs.us-west-2.amazonaws.com/444718680011/dmv-dev-vr-logging-queue.fifo -Dlogging.testQueueARN=arn:aws:sqs:us-west-2:444718680011:dmv-dev-vr-logging-queue.fifo
```

## Step 6: Testing
Run the following tests to verify endpoints are working:
- `GET https://localhost:8081/ping`
- `GET https://localhost:8081/health-check`

## Common Issues and Solutions

### Build Failures
1. **XML Syntax Errors**: Most common issue is improper error-handler placement
   - **Fix**: Ensure all error-handlers are wrapped in `<try>` blocks
   - **Example**: `<route><try>...operations...<error-handler>...</error-handler></try></route>`

2. **Missing Flow References**: Ensure all referenced flows exist
   - Check for missing imports in global.xml
   - Verify flow names match exactly

### Error Handler Structure Examples

**Correct Structure for Scatter-Gather Routes:**
```xml
<route>
    <try doc:name="Connection Check" doc:id="connection-check-try">
        <http:request method="GET" doc:name="Test Connection" config-ref="config" path="/test"/>
        <set-payload value="Success response"/>
        <error-handler>
            <on-error-continue enableNotifications="true" logException="true" doc:name="On Error Continue" type="ANY">
                <set-payload value="Error response"/>
            </on-error-continue>
        </error-handler>
    </try>
</route>
```

**Incorrect Structure (Will Cause Build Failure):**
```xml
<route>
    <set-payload value="Success response"/>
    <error-handler> <!-- THIS IS WRONG - Not wrapped in try block -->
        <on-error-continue>
            <set-payload value="Error response"/>
        </on-error-continue>
    </error-handler>
</route>
```

### Health-Check Best Practices
- Use descriptive names for connection checks
- Include endpoint URLs in success responses for debugging
- Set appropriate timeout values (typically 5000ms)
- Use meaningful error messages
- Test both success and failure scenarios

### Validation Checklist
- [ ] RAML updated with ping and health-check endpoints
- [ ] APIKit router references correct RAML file
- [ ] Ping endpoint implemented with proper response format
- [ ] Health-check endpoint uses appropriate pattern (scatter-gather vs simple)
- [ ] All error-handlers properly wrapped in try blocks
- [ ] Maven build succeeds (`mvn clean compile`)
- [ ] Full build with DMV settings succeeds
- [ ] Endpoints respond correctly when tested
