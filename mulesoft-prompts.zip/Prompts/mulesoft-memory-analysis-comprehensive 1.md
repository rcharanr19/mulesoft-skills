# MuleSoft Memory Leak Analysis Comprehensive Rule

## Rule Name: `comprehensive-mulesoft-memory-analysis`

### When to Apply
- Any request to analyze MuleSoft applications for memory issues
- Performance problems investigation in Mule applications
- Resource optimization analysis for MuleSoft projects
- Memory leak detection and remediation requests

### One-Shot Analysis Framework

Use this comprehensive prompt for complete memory leak analysis of any MuleSoft application in a single execution:

**"Perform a comprehensive memory leak analysis of the MuleSoft project in the current directory. Follow this framework:**

#### 1. PROJECT INVESTIGATION
- Read pom.xml for memory configurations, dependencies, and deployment profiles
- Analyze all .xml files in src/main/mule/ for flows, components, and variable usage
- Review src/main/resources/ for property files and configurations
- Document the complete application architecture and flow structure

#### 2. MEMORY CONSUMPTION ANALYSIS
- **Variable Lifecycle**: Identify variables that are created but never explicitly removed with `<remove-variable>`
- **Large Object Processing**: Find operations creating large objects (HPKE, encryption, PDF417, Base64, images)
- **Parallel Processing**: Identify scatter-gather patterns that amplify memory usage
- **External Integrations**: Analyze ObjectStore, SQS, database, and HTTP connector memory overhead
- **DataWeave Transformations**: Calculate intermediate object memory consumption
- **Connection Pools**: Evaluate HTTP listener and connector pool memory usage

#### 3. QUANTITATIVE IMPACT CALCULATION
- Calculate memory consumption per request for each identified source
- Estimate concurrent request amplification effects
- Project total system memory usage under normal and peak loads
- Compare against allocated memory limits in pom.xml

#### 4. PRODUCTION VALIDATION
- Access Anypoint Platform monitoring data using organization and environment IDs
- Compare theoretical calculations against actual heap usage metrics
- Validate predictions against production performance data
- Identify discrepancies and adjust analysis accordingly

#### 5. ACTIONABLE RECOMMENDATIONS
- Provide specific XML code fixes with exact variable cleanup statements
- Recommend memory allocation adjustments
- Calculate expected memory reduction percentages
- Estimate infrastructure cost savings

#### 6. CONSOLIDATED REPORT
- Executive summary with key findings
- Technical details with code examples
- Production validation results
- Implementation roadmap with timelines
- Expected outcomes and benefits

**Required output format: Single comprehensive report covering all aspects above, validated against production data, with specific implementation guidance.**"

### Execution Pattern
1. **Complete Project Scan**: Analyze all files and configurations systematically
2. **Detailed Memory Calculations**: Quantify memory consumption for every component
3. **Production Validation**: Compare theoretical analysis with actual monitoring data
4. **Specific Remediation**: Provide actionable code fixes with quantified benefits
5. **Consolidated Delivery**: Single report with executive summary and technical details

### Success Criteria
- ✅ Analysis accuracy validated against production metrics (>95% alignment)
- ✅ Specific code fixes provided for each identified issue
- ✅ Quantified memory reduction and cost savings estimates
- ✅ Implementation timeline with expected outcomes
- ✅ No additional refinement rounds required

### Key Analysis Components

#### Memory Leak Indicators
- Variables created without corresponding `<remove-variable>` statements
- Large object operations (>10MB) without cleanup
- Scatter-gather patterns with memory amplification
- DataWeave transformations creating intermediate objects
- Connection pool configurations with high memory overhead

#### Quantification Methods
- Per-request memory consumption calculation
- Concurrent processing amplification factors
- Total system memory projection under load
- Comparison with allocated memory limits
- Infrastructure cost impact assessment

#### Production Validation Approach
- Use Anypoint Platform MCP tools for monitoring data access
- Compare theoretical calculations with actual heap metrics
- Validate memory spike patterns against processing cycles
- Confirm system stability under identified memory constraints

### Expected Deliverable Format

```markdown
## Executive Summary
- Key findings with quantified impact
- Critical memory leak sources identified
- Production validation results
- Recommended actions and timeline

## Technical Analysis
- Detailed memory consumption breakdown
- Specific code issues with examples
- Production metrics comparison
- Implementation guidance

## Remediation Plan
- Specific XML fixes for each issue
- Expected memory reduction percentages
- Infrastructure cost savings estimates
- Implementation timeline and priorities
```

This rule ensures comprehensive MuleSoft memory analysis completion in a single execution without requiring multiple refinement iterations.