# Developer Prompt: Generate Sample Fixed-Width Flat Files for MuleSoft Integration APIs

## Purpose

Use this prompt with an AI coding assistant (e.g., Agentforce / MuleSoft Developer Agent) to generate
accurate sample input and output fixed-width flat files for MuleSoft batch integration APIs.
The prompt captures every lesson learned across multiple iterations on two real DMV integration projects:
**vr-inquiry-papi-v1** and **vr-parking-citation-papi-v1**.

Copy this entire file into a new chat with the assistant, fill in the VARIABLES section, and the
assistant will produce: a PowerShell generator script, the actual flat files, and a README.

---

## VARIABLES — Fill these in before sending

```
PROJECT_NAME:       e.g. vr-parking-citation-papi-v1
INTERFACE_NAME:     e.g. Parking Citation Hold
INPUT_FFD_PATH:     e.g. src/main/resources/FixedWidth.ffd  OR  "none — manual slice parsing"
OUTPUT_FFD_PATH:    e.g. src/main/resources/FixedWidth.ffd
INPUT_TRANSFORM:    e.g. src/main/resources/dwl/p-input-request-transform.dwl
VALIDATION_DWL:     e.g. src/main/resources/dwl/p-input-data-validation-transform.dwl
IMPLEMENTATION_XML: e.g. src/main/mule/implementation/parking-citation-main-implementation.xml
OUTPUT_DIR:         e.g. src/test/resources/mock-data/
GENERATOR_SCRIPT:   e.g. gen_parking_citation.ps1
README_PATH:        e.g. src/test/resources/mock-data/README-mock-flat-files.md
LINE_ENDING:        CRLF or LF
```

---

## MASTER INSTRUCTIONS FOR THE AI ASSISTANT

You are generating **exact-byte-length** fixed-width flat file samples for a MuleSoft batch
integration. Follow every step below. These rules were discovered through repeated debugging of
byte-length errors and incorrect validation scenarios on real CA DMV integration projects.

---

### STEP 1 — Read source files BEFORE writing anything

Read ALL of the following before producing any code or sample data.

**1. FFD file(s)** — extract every field name, length, and order.
Sum all field lengths to get the authoritative record length. For projects with multiple FFDs
(e.g., one per card image type in vr-inquiry-papi-v1), read every FFD individually.
In vr-inquiry-papi-v1 there are: 9 R21/R22 card image FFDs, separate T21/T22 FFDs, and V11 FFDs.

**2. Input transform DWL** — this is the authoritative source of byte positions for input fields.
Do NOT assume the FFD describes the input. In many integrations the input is parsed with manual
character slicing: `payload splitBy "\n"`, then `record[0 to 2]`, `record[3]`, etc.
The FFD applies only to the output writer. Note exact zero-based start and end indices for every field.

Example from vr-parking-citation: `record[0 to 2]` = transactionCode (3 chars),
`record[3]` = typeActionCode (1 char), `record[4]` = fileCode (1 char), etc.

**3. Validation DWL** — extract every validation rule, valid value list, and error code mapping.
Never guess rules. Derive them from the actual DWL source.
Note operators: `~=` (case-insensitive), `==` (exact), `matches /regex/`, numeric comparison.

Date validation rules vary per project:
- vr-parking-citation: MMDDYY, within last 36 months, not future, noticeDate before today PST.
- V11 in vr-inquiry: MMDDYYYY, year must equal current year, day must be less than today's day-of-month.
- R21/R22 in vr-inquiry: MMDDYY as-of date (optional field, 6 chars, can be all spaces).

**4. Main implementation XML flow files** — understand end-to-end processing:
- Does the output contain ALL records or only error/rejected records?
  - vr-parking-citation: output contains ALL records (both success and error).
  - V11 in vr-inquiry: output contains ONLY rejected/error records. Valid records = no output line.
  - R21/R22 in vr-inquiry: output contains ALL records as card image groups (Cards 1-9 per record).
- What triggers output file creation vs being skipped?
- What is the output filename pattern and how are tokens (sftpUserId, requestorCode, date) derived?

**5. Existing sample files** — use as ground truth to confirm record length and line ending.

**6. Lookup JSON files** (e.g., `license-plate-combinations.json`) — choose license plate values
that actually match the fileCode you are using in each scenario.

**7. Properties files** (`config.yaml`, `config-dev.yaml`) — note any configurable parameters
that affect validation: date range limits, error code lists, court code range, batch sizes.

---

### STEP 2 — Derive and publish the exact field layouts

Before writing any code, produce a field layout table for both input and output.

**Input layout** (from DWL character slices, NOT the FFD):

| Pos(0-idx start) | Pos(0-idx end) | Length | Field | Valid Values / Rules |
|-----------------|----------------|--------|-------|----------------------|
| 0 | 2 | 3 | transactionCode | R80 only |
| 3 | 3 | 1 | typeActionCode | A, C, D, R, T |
| 4 | 4 | 1 | fileCode | A, C, H, I, L, M, S, U |
| 5 | 11 | 7 | licensePlate | pattern per fileCode JSON |
| 12 | 16 | 5 | RO_Name | first 5 chars of owner name |
| 17 | 31 | 15 | citationNumber | alphanumeric, no leading spaces |
| 32 | 32 | 1 | dispositionCode | 0, 1, 2, 3, 4, 8 |
| 33 | 38 | 6 | violationDate | MMDDYY, past, within 36 months |
| 39 | 50 | 12 | make | vehicle make, space-padded |
| 51 | 53 | 3 | bailFineAmount | numeric, not 000 for Add |
| 54 | 58 | 5 | courtCode | numeric, first 2 digits 01-58 |
| 59 | 64 | 6 | noticeDate | MMDDYY, before today PST |

Sum = 65 chars (vr-parking-citation input record length).

**Output layout** (from FFD field order):

| Length | Field | Values |
|--------|-------|--------|
| 1 | recordID | 1=validation error, 2=update/processed, space=none |
| 5 | courtCode | from input |
| 15 | citationNumber | from input |
| 1 | fileCode | from input |
| 7 | licensePlate | from input |
| 5 | RO_Name | from input |
| 12 | make | from input |
| 6 | violationDate | from input |
| 3 | bailFineAmount | from input |
| 1 | typeActionCode | from input |
| 10 | validationErrors | up to 5 two-char codes left-packed, space-padded |
| 1 | dispositionCode | result code |

Sum = 67 chars (vr-parking-citation output record length).

For multi-FFD projects (vr-inquiry-papi-v1), produce a separate table for each card image FFD.
Card images 1-9 for R21/R22 are all 289 chars but have different field layouts.
T21/T22 cards (1-4) are also 289 chars with different field positions than R21/R22.
V11 input = 44 chars; V11 output = 53 chars (completely separate schemas).

---

### STEP 3 — Design the scenario matrix

Design at least 8 input records covering all important validation paths.

Minimum required scenarios:

| N | Type | Purpose |
|---|------|---------|
| 1 | Happy path Add/Insert | all fields valid, notifCode=0 or typeAction=A |
| 2 | Happy path Delete/Remove | typeAction=D or notifCode=2 |
| 3 | Happy path Update/Change | typeAction=C or second valid insert |
| 4 | Happy path alternate | different fileCode, different court/county |
| 5 | Error: invalid primary code | bad transactionCode or blocked requesterCode |
| 6 | Error: invalid action/notif | typeAction=9 or notifCode not in allowed set |
| 7 | Error: date out of range | wrong year, future date, or more than N months ago |
| 8 | Error: multi-code | two or more rules fail simultaneously |

Rules for choosing field values:

- Always use the exact date format from the DWL (MMDDYY or MMDDYYYY, not the other).
- For "within last N months" rules: use a date that is N/2 months ago to stay safely in range.
- For "year must equal current year": use the actual current year.
- For "day must be LESS THAN today's day-of-month": use day 01 if today >= 02.
- For "day must be LESS THAN OR EQUAL": use today's day-of-month.
- For error records: violate exactly one rule per error code unless building a multi-error test.
- For parking citation courtCode: first 2 digits must be 01-58. Use 99 to deliberately trigger 0T.
- For V11 requesterCode: must be numeric, first 2 digits 01-58, last 3 digits "555". Use 99933 to trigger error 38.
- For R21/R22: choose license plate values that match fileCode per the JSON lookup file.

---

### STEP 4 — Write the PowerShell generator script

Name the script per the GENERATOR_SCRIPT variable. The script must follow this exact structure.

**Header comment block**: project name, interface, FFD paths, input length, output length, line ending and why.

**Pad helper function** — every single field must go through this, never concatenate a raw string:

```powershell
function Pad([string]$s, [int]$n) {
    if ($s.Length -ge $n) { return $s.Substring(0, $n) }
    return $s.PadRight($n)
}
```

**MakeInput function** — one named parameter per input field, Pad calls in field order, length assertion:

```powershell
function MakeInput(
    [string]$transCode,    [string]$typeAction,    [string]$fileCode,
    [string]$licensePlate, [string]$roName,        [string]$citationNumber,
    [string]$dispCode,     [string]$violationDate, [string]$make,
    [string]$bailAmount,   [string]$courtCode,     [string]$noticeDate
) {
    $line = (Pad $transCode      3)  + (Pad $typeAction    1)  + (Pad $fileCode       1) +
            (Pad $licensePlate   7)  + (Pad $roName        5)  + (Pad $citationNumber 15) +
            (Pad $dispCode       1)  + (Pad $violationDate 6)  + (Pad $make          12) +
            (Pad $bailAmount     3)  + (Pad $courtCode     5)  + (Pad $noticeDate     6)
    if ($line.Length -ne 65) { throw "INPUT length error: expected 65, got $($line.Length)" }
    return $line.ToUpper()
}
```

Adapt field order, names, and expected length for your specific project.

**MakeOutput function** — one named parameter per output field in FFD order, length assertion:

```powershell
function MakeOutput(
    [string]$recordID,      [string]$courtCode,    [string]$citationNumber,
    [string]$fileCode,      [string]$licensePlate, [string]$roName,
    [string]$make,          [string]$violationDate,[string]$bailAmount,
    [string]$typeAction,    [string]$valErrors,    [string]$dispCode
) {
    $line = (Pad $recordID      1)  + (Pad $courtCode      5)  + (Pad $citationNumber 15) +
            (Pad $fileCode      1)  + (Pad $licensePlate   7)  + (Pad $roName          5) +
            (Pad $make         12)  + (Pad $violationDate  6)  + (Pad $bailAmount       3) +
            (Pad $typeAction    1)  + (Pad $valErrors      10) + (Pad $dispCode         1)
    if ($line.Length -ne 67) { throw "OUTPUT length error: expected 67, got $($line.Length)" }
    return $line.ToUpper()
}
```

**Input and output arrays** — comment each record with its scenario:

```powershell
$inputLines = @(
    (MakeInput "R80" "A" "M" "7ABC123" "SMITH" "CV00123456789  " "0" "060524" "TOYOTA      " "058" "05001" "070126"),
    (MakeInput "R80" "D" "M" "8XYZ456" "JONES" "LA00234567890  " "1" "010125" "HONDA       " "100" "12001" "020125"),
    (MakeInput "R80" "C" "M" "3MNO678" "BROWN" "SD00345678901  " "2" "030224" "FORD        " "075" "23001" "040124"),
    (MakeInput "XXX" "A" "M" "4PQR789" "DAVIS" "OC00456789012  " "0" "091523" "CHEVROLET   " "050" "99001" "101523"),
    (MakeInput "R80" "A" "M" "5STU901" "WILSO" "SA00567890123  " "9" "990124" "NISSAN      " "125" "37001" "060126")
)

$outputLines = @(
    (MakeOutput "2" "05001" "CV00123456789  " "M" "7ABC123" "SMITH" "TOYOTA      " "060524" "058" "A" "          " "1"),
    (MakeOutput "2" "12001" "LA00234567890  " "M" "8XYZ456" "JONES" "HONDA       " "010125" "100" "D" "          " "3"),
    (MakeOutput "2" "23001" "SD00345678901  " "M" "3MNO678" "BROWN" "FORD        " "030224" "075" "C" "          " "2"),
    (MakeOutput "1" "99001" "OC00456789012  " "M" "4PQR789" "DAVIS" "CHEVROLET   " "091523" "050" "A" "0A0T      " "0"),
    (MakeOutput "1" "37001" "SA00567890123  " "M" "5STU901" "WILSO" "NISSAN      " "990124" "125" "A" "0Y0M0L0J0K" "0")
)
```

**File writing** — LF for inputs parsed with `splitBy("\n")`, CRLF for FFD-based outputs:

```powershell
# LF only (input parsed with splitBy("\n")):
$c = ($inputLines -join "`n") + "`n"
[System.IO.File]::WriteAllText($inputFile, $c, [System.Text.UTF8Encoding]::new($false))

# CRLF (output written with application/flatfile FFD):
[System.IO.File]::WriteAllLines($outputFile, $outputLines, [System.Text.UTF8Encoding]::new($false))
```

**Verification block** — after writing, parse and print each field by Substring position:

```powershell
foreach ($ln in $inputLines) {
    Write-Host "  TC=$($ln.Substring(0,3)) TA=$($ln.Substring(3,1)) LP=$($ln.Substring(5,7)) CN=$($ln.Substring(17,15)) [len=$($ln.Length)]"
}
foreach ($ln in $outputLines) {
    Write-Host "  RID=$($ln.Substring(0,1)) CC=$($ln.Substring(1,5)) CN=$($ln.Substring(6,15)) VE=[$($ln.Substring(56,10))] [len=$($ln.Length)]"
}
```

---

### STEP 5 — Run the generator and confirm output

```powershell
powershell -ExecutionPolicy Bypass -File path/to/GENERATOR_SCRIPT
```

Check: every input line = EXPECTED_INPUT_LENGTH chars. Every output line = EXPECTED_OUTPUT_LENGTH chars.
If wrong: fix the `Pad` length argument in the builder function. Never adjust the field value to fix length.

---

### STEP 6 — Write the README

Create a Markdown README at README_PATH with these sections:

1. **Overview** — what interface this represents, what Mule flow processes the file.
2. **File Naming Convention** — table with pattern, tokens, and a concrete example filename.
3. **Input File Layout** — full field table (0-based positions, lengths, field names, valid values).
   State clearly whether input is parsed by FFD or by manual character slice.
4. **Output File Layout** — full field table (lengths, field names, values). Cite the FFD path.
5. **Scenario Table** — one row per record: all key input values and expected output/error codes.
6. **Raw sample lines** — paste actual generated lines in a fenced code block.
7. **Validation Error Code Reference** — every code, the field it checks, the rule that triggers it.
8. **Key Processing Notes** — non-obvious behavior (e.g., output-only-on-error, DMVActionDate meaning,
   fields present in input but not output, recordID derivation logic).
9. **Input to Salesforce to Output field mapping** diagram.

---

## COMMON MISTAKES AND HOW TO AVOID THEM

### Byte-length errors

**1. Off-by-one Pad lengths.** If a field is 15 chars but you write `Pad $x 14`, every subsequent
field is shifted left by 1. Derive lengths directly from FFD or DWL — never guess.

**2. Missing Pad on any field.** Concatenating a raw string that is shorter than the field length
silently produces a short line. Every field — without exception — goes through Pad.

**3. Wrong total for multi-FFD projects.** In vr-inquiry-papi-v1:
- R21/R22 output cards 1-9 are all 289 chars each.
- T21/T22 output cards 1-4 are also 289 chars but have different field layouts than R21/R22.
- V11 input = 44 chars, V11 output = 53 chars.
- Confirm the expected length for each FFD independently by summing its field lengths.

**4. Trailing-space count errors between adjacent fields.** In R21/R22 output, T21/T22 Card 2
has 5 spaces after the ZIP code field (positions 75-78 = 4 bytes of space fields) whereas
R21/R22 Card 2 Card has only 1 space in that area. Always read the FFD for each card individually.

### Line-ending errors

**5. CRLF when the input parser expects LF.** If the DWL uses `splitBy("\n")`, a CRLF file
causes `\r` to appear at the end of the last field of every record, breaking validation silently.

**6. LF when the Mule connector expects CRLF.** Flat-file connectors using an FFD schema default
to CRLF. An LF-only file may cause all records to be read as one giant concatenated line.

How to decide: read the input transform DWL. `payload splitBy "\n"` → LF.
`output application/flatfile schemaPath="..."` → CRLF.

### Validation rule errors

**7. Guessing validation rules.** Rules differ significantly between projects.
Always read the actual validation DWL before assigning field values.

**8. Date format confusion.** vr-parking-citation uses MMDDYY (6 chars).
V11 in vr-inquiry uses MMDDYYYY (8 chars). Using the wrong format causes dates to always pass
or always fail validation depending on what the regex matches.

**9. validationDate direction.** In V11, the check is day < today (strictly less than).
If today is the 15th, day 15 will FAIL. Use day 14 or earlier for a valid record.

**10. Multi-error output field packing.** In vr-parking-citation, `validationErrors` (10 chars)
holds up to 5 two-character codes with no separator: `0A0T0Y     ` (left-packed, right-padded
with spaces to 10). Do not insert spaces between the codes.

### Output structure errors

**11. Including success lines in error-only output.** In V11, the output file contains ONLY
rejected records. Valid records have NO corresponding output line. Do not create success output
lines for V11 valid records.

**12. Missing Card 1 for error records in R21/R22.** Every R21/R22 input record always produces
a Card 1 output line — including error records. Error records produce Card 1 + Card 6 only,
never Cards 2-5 or 7-9.

**13. Wrong card image FFD for T21/T22.** T21/T22 uses entirely different FFDs from R21/R22
even though both produce 289-char output lines. The field positions inside those 289 chars are
different. In particular, T21/T22 Card 2 does not have a county code field at positions 76-77,
and T21/T22 Card 4 does not have the lien holder address lines that R21/R22 Card 4 has.

**14. Conflating V11 input with R21/R22 input.** V11 is a completely separate interface with
its own 44-char input record and 53-char output record. It shares nothing with the R21/R22
105-char input or 289-char card image output.

---

## PROJECT REFERENCE SUMMARY

### vr-parking-citation-papi-v1

| Item | Value |
|------|-------|
| Input record length | 65 chars |
| Output record length | 67 chars |
| Input line ending | LF only (parsed with `splitBy("\n")`) |
| Output line ending | LF only (written with `WriteAllText` + `joinBy("\n")`) |
| Input parsed by | Manual character slice in `p-input-request-transform.dwl` |
| Output written by | `FixedWidth.ffd` via `output application/flatfile` |
| Output scope | ALL records (success and error) |
| Input filename | `{sftpUserId}_PARKHOLD_{requestorCode}_{yyyyMMdd}_{seq}.txt` |
| Output filename | `{sftpUserId}_vrhold_OUT_{requestorCode}_{yyyyMMdd}_{hhmmss}.txt` |
| sftpUserId position | token[0] after split on `_` |
| requestorCode position | token[2] after split on `_` |
| Valid transactionCode | `R80` only |
| Valid typeActionCode | A, C, D, R, T |
| Valid fileCode | A, C, H, I, L, M, S, U |
| Valid dispositionCode | 0, 1, 2, 3, 4, 8 |
| violationDate format | MMDDYY (6 chars) |
| noticeDate format | MMDDYY (6 chars), must be before today PST |
| courtCode rule | Numeric, first 2 digits in range 01-58 |
| bailFineAmount rule | Numeric, not "000" for typeActionCode=A |
| validationErrors format | Up to 5 codes × 2 chars, left-packed, space-padded to 10 |
| recordID=1 means | Validation error (code in `validation.errorcode` config list) |
| recordID=2 means | Successfully updated/processed |

### vr-inquiry-papi-v1 — R21/R22 and VOL process

| Item | Value |
|------|-------|
| Input record length | 105 chars |
| Output record length | 289 chars per card image line |
| Input line ending | CRLF |
| Output line ending | CRLF |
| Input parsed by | `FixedWidth_input_R21_22.ffd` via `input application/flatfile` |
| Output written by | 9 card image FFDs: `card_image_1_R21_22.ffd` through `card_image_9_R21_22.ffd` |
| Output scope | ALL records (Card 1 always present; Cards 2-9 based on data; Card 6 for errors) |
| Input filename | `vrinquiry_{yyyyMMdd}_{HHmmss}.txt` (R21/R22) or `{userId}_VRINQ_{code}_{date}_{time}.txt` (VOL) |
| Output filename | `VRINQ_OUT{yyyyMMdd}.txt` (R21/R22) or `{userId}_VRINQ_OUT_{code}_{date}_{time}.txt` (VOL) |
| requesterCode position | positions 1-5 (1-based) of input record |
| fileCode values | A,B,C,E,F,H,I,K,L,M,P,S,T,U,V,X |
| fileCode K | Routes to T21/T22 (title inquiry) — uses separate T21/T22 FFDs |
| fileCode S + DPP pattern | Routes to DPP (Disabled Person Placard) API |
| DPP patterns | ANNNNNA, ANNNNNN, NNNNNNA |
| as-of date | Positions 7-12, MMDDYY, all spaces = use current date |
| VIN query | Leave licenseNumber all spaces, put VIN in positions 21-44 |
| Card 1 | Always produced — request echo/header |
| Cards 2-4 | Success records (vehicle summary, RO name/address, additional owner/lien holder) |
| Card 5 | One per active stop on the vehicle |
| Card 6 | Error response (only when record fails) |
| Cards 7+8 | One pair per NRL (Notice of Release of Liability) entry, no as-of date only |
| Card 9 | One per Fiserv payment record |

### vr-inquiry-papi-v1 — T21/T22 (Title Inquiry)

| Item | Value |
|------|-------|
| fileCode | K |
| Input format | Same 105-char R21/R22 input format |
| Output FFDs | `crd_img_1_T21_T22.ffd` through `crd_img_4_T21_T22.ffd` |
| Output record length | 289 chars (same as R21/R22 but different field layouts) |
| Cards produced | 1,2,3,4 for success; 1,6 for error |
| No as-of date | Always blank in input |
| No VIN | Always blank in input |
| Card 4 difference | Lien holder layout: city/state/ZIP instead of address lines 1-4 |
| Card 2 difference | No county code at positions 76-77; no typeBody, typeLicense, etc. |

### vr-inquiry-papi-v1 — DPP (Disabled Person Placard)

| Item | Value |
|------|-------|
| fileCode | S with license matching ANNNNNA, ANNNNNN, or NNNNNNA |
| Routed to | DPP inquiry API (not Salesforce) |
| Output FFDs | Same R21/R22 card image FFDs |
| Card 2 content | Only registeredOwnerCity, registeredOwnerZipCode, registeredOwnerCountyCode filled |
| Card 3 content | Only registeredOwnerAddress filled (no owner name, no paperIssuedDate) |
| No Card 4 | DPP does not produce Card 4 |
| Cards 5, 9 | Same format as R21/R22 |

### vr-inquiry-papi-v1 — V11 (Vessel Delinquent Tax Stop)

| Item | Value |
|------|-------|
| Input record length | 44 chars |
| Output record length | 53 chars |
| Input line ending | CRLF |
| Output line ending | CRLF |
| Input FFD | `FixedWidth_Input_V11.ffd` |
| Output FFD | `FixedWidth_Output_V11.ffd` |
| Output scope | ONLY rejected/error records — valid records produce NO output line |
| transactionCode | Always V11 (positions 1-3) |
| requesterCode | Numeric, first 2 digits 01-58, last 3 digits must equal 555 |
| requesterCode 99933 | Explicitly blocked (taxCollector validation, error code 38) |
| dispositionDate | MMDDYYYY (8 chars), year = current year, day < today's day-of-month |
| vesselLicenseNumber | 7 chars, alphanumeric (e.g., CF12345) |
| RO_Name | First 5 chars of (firstName+lastName) from vessel owner |
| notificationCode | 0=add stop, 2=remove stop |
| ID_Parcel | Assessor parcel number, exactly 15 chars |
| Output error codes | 38=taxCollector, B1=notifCode, A5=validationDate, A8=year, A7=day, A6=month, A3=reqCode, A9=ROName |
| rejectA3CountyCode | First 2 digits of requesterCode (echoed to output for tracking) |
| DMVActionDate | Date the V11 batch was processed (output only) |

---

## QUICK START CHECKLIST

Before the AI assistant writes the first line of code, confirm it has done all of these:

- [ ] Read all FFD files and computed the sum of field lengths for each
- [ ] Read the input transform DWL and noted all zero-based slice positions
- [ ] Read the validation DWL and listed every rule and error code
- [ ] Read the main implementation XML to understand output scope (all records vs error-only)
- [ ] Confirmed record length against any existing sample files in the project
- [ ] Determined line ending by checking for `splitBy("\n")` in the DWL
- [ ] Chosen license plate values from the JSON lookup file
- [ ] Produced a written field layout table before writing any PowerShell
- [ ] Designed a scenario matrix with at least 8 records
- [ ] The MakeInput function includes a length assertion
- [ ] The MakeOutput function includes a length assertion
- [ ] The script prints a verification table after writing the files
- [ ] The README includes raw sample lines in a code block

---

*For authoritative MuleSoft documentation see https://docs.mulesoft.com/general/*
