---
name: generate-dmv-mapping
description: Design, update, and regenerate CA DMV DXP Data Mapping Sheets (XLSX) for MuleSoft integrations. Use when user asks to create a mapping doc, update mapping sheet, add a new tab, update field mappings, add test cases to the mapping sheet, or regenerate the XLSX. The mapping sheet is generated from XLSX_TABS in icd_<interface>_data.py in D:\Users\mwaxs65\VIBES. Always regenerate using: uv run --with python-docx --with openpyxl python dmv_icd_generator.py icd_<name>_data via Start-Process (Python App Execution Aliases disabled on this machine).
license: Apache-2.0
metadata:
  author: mule-dx-tooling
  version: "1.0.0"
  theme: professional
allowed-tools: Read Write Edit AskUserQuestion Bash
---

# Skill: generate-dmv-mapping

## Purpose
Design, populate, and regenerate the CA DMV DXP Data Refinement / Mapping Sheet (XLSX) for any MuleSoft integration. The mapping sheet is generated from the `XLSX_TABS` variable in `icd_<interface>_data.py` using `dmv_icd_generator.py`.

## Trigger
Use this skill when the user asks to:
- "create a mapping doc / mapping sheet"
- "update the mapping sheet for INT..."
- "add a tab to the mapping sheet"
- "add test cases to the mapping sheet"
- "update field mappings"
- "regenerate the XLSX"
- "what tabs should the mapping sheet have?"

---

## File Locations

| File | Purpose |
|------|---------|
| `D:\Users\mwaxs65\VIBES\icd_<int>_data.py` | Source of truth — edit `XLSX_COVER_META` and `XLSX_TABS` here |
| `D:\Users\mwaxs65\VIBES\dmv_icd_generator.py` | Generator engine — do NOT edit |
| Output: `INT<N> - <Name> - V<ver> - Mapping Sheet.xlsx` | Generated in `D:\Users\mwaxs65\VIBES\` |

---

## Key Variables in the Data Module

### XLSX_COVER_META
Rows shown on the Cover sheet. Always include:
```python
XLSX_COVER_META = [
    ("Interface #",    INT_NUMBER),       # e.g. "INT5049"
    ("Interface Name", INT_NAME),         # e.g. "Workdate Authorization"
    ("MuleSoft API",   MULESOFT_API),     # e.g. "vr-workdate-papi"
    ("API Layer",      API_LAYER),        # e.g. "Process API (PAPI)"
    ("Version",        VERSION),          # e.g. "1.0"
    ("Status",         STATUS),           # e.g. "Draft -- Pending DMV Review"
    ("Mule Runtime",   "4.8.0"),
    ("Artifact",       "vr-<name>-papi v1.0.0"),
]
```

### XLSX_TABS
List of worksheet definitions. Each dict has: `name`, `headers`, `rows`, `widths`.
```python
XLSX_TABS = [
    {
        "name":    "Tab Name",           # max 31 chars
        "headers": ["Col1", "Col2"],     # column header labels (styled dark blue)
        "rows":    [["val1", "val2"]],   # data rows (alternating white/light-blue)
        "widths":  [20, 40],             # Excel column widths (units, ~7 pts each)
    },
]
```

---

## Standard Tab Set (use for all DMV CCIM integrations)

### Tab 1: Request Field Mapping
Maps PAPI inbound fields → EASE MQ / backend fields.
```python
{
    "name": "<endpoint> Mapping",   # e.g. "workdate-auths Mapping"
    "headers": ["PAPI Field", "Backend Field", "Type", "Required", "Format / Validation", "Notes"],
    "rows": [
        ["field_name", "backendFieldName", "String", "Yes", "validation rule", "notes"],
    ],
    "widths": [18, 20, 10, 10, 28, 24],
}
```

### Tab 2: Request Headers
Standard for all CCIM integrations:
```python
{
    "name": "Request Headers",
    "headers": ["Header", "Required", "Example Value", "Description"],
    "rows": [
        ["dmv_source",       "Yes", "dmv_dxp_vr",  "Originating system. Forwarded by EAPI to PAPI."],
        ["dmv_appid",        "Yes", "sfdc_ccim",   "Calling application. Forwarded by EAPI to PAPI."],
        ["x-correlation-id", "Yes", "<UUID>",      "End-to-end tracing. Stored as vars.correlationId."],
        ["client_id",        "Yes", "<id>",        "PAPI client ID. Injected by EAPI from Thycotic."],
        ["client_secret",    "Yes", "<secret>",    "PAPI client secret. Injected by EAPI from Thycotic."],
    ],
    "widths": [22, 12, 22, 40],
}
```

### Tab 3: Response Envelope
Standard DXP response fields:
```python
{
    "name": "Response Envelope",
    "headers": ["Field", "Type", "Source / Mapping", "Notes"],
    "rows": [
        ["status",        "String",   "Literal SUCCESS",              "ERROR on exception"],
        ["message",       "String",   "sizeOf(originalPayload) text", "Record count in message"],
        ["correlationId", "String",   "vars.correlationId",           "From x-correlation-id header"],
        ["timestamp",     "DateTime", "now() UTC",                    "ISO 8601 format"],
    ],
    "widths": [18, 12, 30, 30],
}
```

### Tab 4: Error Codes
```python
{
    "name": "Error Codes",
    "headers": ["HTTP Code", "Mule Error Type", "Description"],
    "rows": [
        ["200", "OK",                              "Request processed successfully."],
        ["400", "APP:VALIDATION",                  "Payload validation failed."],
        ["401", "N/A",                             "Missing or invalid client credentials."],
        ["404", "APIKIT:NOT_FOUND",               "Resource path not found."],
        ["405", "APIKIT:METHOD_NOT_ALLOWED",      "HTTP method not supported."],
        ["500", "ANY",                             "Unhandled exception."],
        ["503", "HTTP:CONNECTIVITY / HTTP:TIMEOUT","Backend unavailable or timed out."],
    ],
    "widths": [14, 32, 50],
}
```

### Tab 5: Test Cases (ALWAYS INCLUDE for QA)
```python
{
    "name": "Test Cases",
    "headers": ["TC #", "Endpoint", "Test Scenario", "Input / Condition", "Expected HTTP Code", "Expected Response / Behaviour"],
    "rows": [
        # Happy path
        ["TC-001", "POST /endpoint", "Happy path — valid single record",
         "Valid payload, all required fields present",
         "200", "status:SUCCESS, message:1 record(s) processed, correlationId, timestamp"],
        ["TC-002", "POST /endpoint", "Happy path — valid batch",
         "Valid array of N records",
         "200", "status:SUCCESS, message:N record(s) processed"],
        # Validation
        ["TC-003", "POST /endpoint", "Empty payload array",
         "Payload: []",
         "400", 'error:"Bad Request", message:"Request array must not be empty."'],
        ["TC-004", "POST /endpoint", "Missing required field",
         "Required field omitted from record",
         "400", 'error:"Bad Request", message contains "Missing required field"'],
        ["TC-005", "POST /endpoint", "Invalid field format",
         "Field value fails format validation",
         "400", 'error:"Bad Request", message describes the violation'],
        # Security
        ["TC-006", "POST /endpoint", "Missing client_id",
         "client_id header omitted",
         "401", 'error:"Unauthorized"'],
        ["TC-007", "POST /endpoint", "Invalid credentials",
         "Wrong client_id or client_secret",
         "401", 'error:"Unauthorized"'],
        ["TC-008", "POST /endpoint", "Missing x-correlation-id",
         "x-correlation-id omitted",
         "200", "EAPI generates UUID; processing continues; UUID echoed in correlationId"],
        # Routing
        ["TC-009", "POST /endpoint", "Correlation ID propagated end-to-end",
         'x-correlation-id: "test-corr-123"',
         "200", 'correlationId:"test-corr-123" echoed in response'],
        ["TC-010", "GET /endpoint", "Wrong HTTP method",
         "GET instead of POST",
         "405", 'error:"Method Not Allowed"'],
        ["TC-011", "POST /invalid", "Invalid resource path",
         "Typo in endpoint path",
         "404", 'error:"Not Found"'],
        # Infrastructure
        ["TC-012", "POST /endpoint", "Backend unavailable (timeout)",
         "Backend connection timed out",
         "503", 'error:"Service Unavailable"'],
        # Ping
        ["TC-013", "GET /ping", "Liveness check",
         "Valid headers, no body",
         "200", 'status:"OK", api, timestamp present'],
    ],
    "widths": [8, 22, 38, 50, 20, 50],
}
```

---

## DataWeave Field Mapping Tab (for EASE MQ integrations)

When the integration publishes to EASE MQ with a specific format (e.g. BAWD/BAUT/BSTN), add a dedicated DW mapping tab:
```python
{
    "name": "DW Field Mapping",
    "headers": ["Inbound (PAPI) Field", "Outbound (EASE MQ) Field", "EASE MQ Format / Notes"],
    "rows": [
        ["auth_string",    "authorizationCode", "Drives message format (BAWD or BAUT)"],
        ["office_id",      "officeId",           "Left-padded to 3 chars: leftPad(officeId,3,'0')"],
        ["tech_id",        "technicianId",        "BAUT format only"],
        ["workdate",       "workDate",            "Reformatted: MMddyyyy in final EASE message"],
    ],
    "widths": [22, 24, 46],
}
```

---

## Column Width Guidelines

| Content Type | Recommended Width |
|-------------|------------------|
| Short code / ID | 10–14 |
| Field name | 18–22 |
| Data type | 10–14 |
| Required (Yes/No) | 10–12 |
| Short description | 28–35 |
| Long description / notes | 40–60 |
| TC # | 8 |
| Endpoint | 20–22 |
| Test scenario | 35–40 |
| Input / condition | 45–55 |
| Expected HTTP code | 18–20 |
| Expected response | 45–55 |

---

## Adding a New Tab to an Existing Mapping Sheet

1. Open `icd_<int>_data.py`
2. Append a new dict to `XLSX_TABS`:
```python
XLSX_TABS.append({
    "name": "New Tab Name",
    "headers": [...],
    "rows":    [...],
    "widths":  [...],
})
```
3. Regenerate (see below).

---

## Regenerate Command (ALWAYS use uv run on this machine)

```powershell
powershell -Command "Start-Process -FilePath 'uv' -ArgumentList 'run --with python-docx --with openpyxl python dmv_icd_generator.py icd_int<N>_data' -WorkingDirectory 'D:\Users\mwaxs65\VIBES' -NoNewWindow -Wait -RedirectStandardOutput 'D:\Users\mwaxs65\VIBES\gen_out.txt' -RedirectStandardError 'D:\Users\mwaxs65\VIBES\gen_err.txt'"
```

Then confirm with:
```powershell
(read gen_out.txt to verify "Saved: INT<N> - ... - Mapping Sheet.xlsx")
```

> Note: The generator always produces BOTH the ICD.docx and the Mapping Sheet.xlsx in a single run. There is no option to generate just the XLSX.

---

## Quick Reference — Standard Tab Order

Always use this order for DMV CCIM mapping sheets:

| # | Tab Name | Contents |
|---|----------|----------|
| 1 | Cover | Auto-generated from XLSX_COVER_META |
| 2 | `<endpoint1> Mapping` | Request field mapping for first endpoint |
| 3 | `<endpoint2> Mapping` | Request field mapping for second endpoint (if applicable) |
| 4 | `DW Field Mapping` | PAPI JSON → EASE MQ / backend field rename table (EASE MQ integrations only) |
| 5 | `Request Headers` | All 5 standard headers |
| 6 | `Response Envelope` | 4 response fields |
| 7 | `Error Codes` | HTTP codes + Mule error types |
| 8 | `Test Cases` | QA test cases (TC-001 onward) |

---

## Yes — The `generate-dmv-icd` Skill Covers Both

The `generate-dmv-icd` skill generates **both** the ICD DOCX and the Mapping Sheet XLSX together. Use **this skill** (`generate-dmv-mapping`) when the focus is specifically on:
- Designing or reviewing the XLSX tab structure
- Adding / updating individual tabs
- Defining test cases for QA
- Understanding column widths and formatting conventions

Use `generate-dmv-icd` when generating a complete new ICD from scratch (it includes mapping sheet generation as part of the full workflow).
