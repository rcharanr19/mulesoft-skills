# implement-healthcheck

## Purpose
Implement or complete a standard healthcheck for any Mule project following the org-approved scatter-gather pattern. Covers all connection targets found in the project.

---

## Step 1 — Analyse the project

Before writing any code, read:
- `src/main/mule/common/global-config.xml` (or equivalent) → identify every `<*:config>` element (connector configs)
- `src/main/mule/vr-*-papi.xml` (or equivalent main XML) → confirm APIkit routes for `/health-check` and `/ping`
- `src/main/mule/common/common-ops-impl.xml` (or equivalent) → see what healthcheck already exists
- `src/main/resources/dwl/p-health-check-response-transform.dwl` → see the current DWL

**Connection targets to health-check** — cover ALL of them:
| Connector | Typical config name | Healthcheck query |
|---|---|---|
| Salesforce (`mule-salesforce-connector`) | `SFDC_*_Config` | `SELECT Name FROM Account LIMIT 1` |
| DB2 (`mule-db-connector` generic, IBM JCC) | `Database_Config` | `SELECT 1 FROM SYSIBM.SYSDUMMY1` |
| MySQL / generic DB | varies | `SELECT 1` |
| Any other connector | varies | Use the lightest read/ping operation available |

---

## Step 2 — Check the RAML

The RAML is referenced inside `<apikit:config api="...">`. Look at the APIkit routing flows in the main XML:
- If `get:\health-check:...-config` exists → RAML already has `/health-check` ✅
- If `get:\ping:...-config` exists → RAML already has `/ping` ✅
- If either is missing → notify the user; they must add it to the RAML and re-scaffold before proceeding.

---

## Step 3 — MANDATORY: Idempotent-only operations

**Every healthcheck operation MUST be read-only and produce zero side effects.** A healthcheck fires on every `/health-check` poll — potentially hundreds of times per day. Any write, insert, or mutating call will corrupt data or flood the target system.

### Decision ladder — pick the safest option available:

| Priority | Approach | When to use |
|---|---|---|
| 1 | **Native read / SELECT query** | Databases (DB2, MySQL, Oracle) — always use `SELECT` |
| 2 | **Lightest read operation on the connector** | Salesforce: `salesforce:query` · SFTP: `sftp:list` · S3: `s3:list-objects` · JMS/IBM MQ: use `peek` or non-destructive read |
| 3 | **HTTP GET to a child Mule API's `/health-check` endpoint** | When the target is a downstream Mule API that exposes its own `/health-check`. Both 200 and 500 confirm reachability — no exception is thrown by the HTTP connector. **200 = child is healthy → status "connected OK". 500 = child is reachable but unhealthy → status "ERROR" + pass through child's `systemInfo` and `description`.** See Step 4b for the exact flow pattern. |
| 4 | **HTTP GET to a known safe read endpoint** | REST APIs that do NOT expose `/health-check` — use `GET /health`, `GET /status`, `GET /ping`, or any lightweight read endpoint |
| 5 | **HTTP GET or POST with obviously invalid/gibberish data** | When no read endpoint exists — send `GET /resource/healthcheck-probe-xzq99` or `POST` with a clearly fake body. A 404/400/422 still proves the system is reachable. Catch the expected error in `on-error-continue` and return `"status": "connected OK"` if any HTTP response came back. |
| 6 | **TCP/socket connectivity only** | If the target has no safe read endpoint at all |

### What is NEVER acceptable in a healthcheck:
- `INSERT`, `UPDATE`, `DELETE`, or any DML that modifies data
- Creating, publishing, or sending real records/messages/events
- Calling a business operation endpoint that triggers downstream processing

---

## Step 4a — Generic flow pattern (all non-HTTP connector targets)

Each flow follows this exact template. There is **no trigger** — these are called only via `flow-ref` from the scatter-gather.

```xml
<flow name="healthcheck-<system>" doc:name="healthcheck-<system>" doc:id="<uuid>">
    <!-- Replace with the appropriate connector operation -->
    <salesforce:query doc:name="Perform health-check query" doc:id="<uuid>"
        config-ref="<ConfigName>">
        <salesforce:salesforce-query><![CDATA[SELECT Name FROM Account LIMIT 1]]></salesforce:salesforce-query>
    </salesforce:query>

    <!-- Success: return a JSON object with name + status -->
    <set-payload doc:name="Success Response" doc:id="<uuid>"
        value='#[%dw 2.0&#10;output application/json&#10;---&#10;{&#10;    "name": "<SYSTEM>",&#10;    "status": "connected OK"&#10;}]' />

    <error-handler>
        <on-error-continue enableNotifications="true" logException="true"
            doc:name="On Error Continue" doc:id="<uuid>">
            <set-variable value="error" doc:name="healthcheckStatus" doc:id="<uuid>"
                variableName="healthcheckStatus" />
            <set-variable value="#[error.description]" doc:name="healthcheckMessage" doc:id="<uuid>"
                variableName="healthcheckMessage" />
            <set-payload doc:name="Error Response" doc:id="<uuid>"
                value='#[%dw 2.0&#10;output application/json&#10;---&#10;{&#10;    "name": "<SYSTEM>",&#10;    "status": error.description&#10;}]' />
        </on-error-continue>
    </error-handler>
</flow>
```

**Salesforce-specific success payload** (include object name and result count):
```xml
<set-payload value='#[%dw 2.0&#10;output application/json&#10;---&#10;{&#10;    "name": "https://test.salesforce.com",&#10;    "status": "connected OK",&#10;    "sfdcObject": "Account",&#10;    "size": sizeOf(payload)&#10;}]' />
```

---

## Step 4b — HTTP child API healthcheck flow pattern

**Use this pattern whenever the target is a downstream Mule API that exposes its own `/health-check` endpoint.**

Key principle: configure the HTTP connector to accept both 200 and 500 as valid HTTP responses (no exception thrown). Then use an `ee:transform` **after** the request to inspect `attributes.statusCode` and produce the correct output:

- **200** → `"status": "connected OK"` — the child API is healthy
- **non-200 (typically 500)** → `"status": "ERROR"` + include the child's own `systemInfo` array and `description` so consumers know exactly what is broken downstream
- **connector throws (connection refused, DNS failure, timeout, etc.)** → caught by `on-error-continue`, returns `"status": error.description`

```xml
<flow name="healthcheck-<CHILD-API-NAME>" doc:name="healthcheck-<CHILD-API-NAME>" doc:id="<uuid>">

    <!-- Call the child API's /health-check endpoint.
         Accept both 200 and 500 so the HTTP connector never throws on a valid HTTP response.
         Only true connectivity failures (no response at all) reach on-error-continue. -->
    <http:request method="GET" doc:name="GET child /health-check" doc:id="<uuid>"
        config-ref="<HTTP_Config>" path="${<child>.healthcheck.path}">
        <http:response-validator>
            <http:success-status-code-validator values="200,500" />
        </http:response-validator>
    </http:request>

    <!-- Inspect the status code AFTER the call and produce the correct healthcheck shape.
         200  → "connected OK"
         500  → "ERROR" + pass through the child's systemInfo and description -->
    <ee:transform doc:name="Evaluate child health response" doc:id="<uuid>">
        <ee:message>
            <ee:set-payload><![CDATA[%dw 2.0
output application/json
var childStatusCode = attributes.statusCode as Number
var childBody       = payload
---
if (childStatusCode == 200)
{
    "systemName": "<CHILD-API-NAME>",
    "status": "connected OK"
}
else
{
    "systemName": "<CHILD-API-NAME>",
    "status": "ERROR",
    "systemInfo":   childBody.systemInfo   default null,
    "description":  childBody.description  default ("Downstream health check returned HTTP " ++ (childStatusCode as String))
}]]></ee:set-payload>
        </ee:message>
    </ee:transform>

    <error-handler>
        <!-- Catches true connectivity failures only (no HTTP response received at all).
             The 200/500 validator above means normal health-check responses never land here. -->
        <on-error-continue enableNotifications="true" logException="true"
            doc:name="On Error Continue" doc:id="<uuid>">
            <set-payload doc:name="Connectivity Error Response" doc:id="<uuid>"
                value='#[%dw 2.0&#10;output application/json&#10;---&#10;{&#10;    "systemName": "<CHILD-API-NAME>",&#10;    "status": error.description&#10;}]' />
        </on-error-continue>
    </error-handler>
</flow>
```

### Example output shapes for child API healthcheck flows

**Child returned 200 (healthy):**
```json
{
    "systemName": "vr-aws-sapi-v1-conv",
    "status": "connected OK"
}
```

**Child returned 500 (reachable but unhealthy):**
```json
{
    "systemName": "vr-sf-papi-v1-conv",
    "status": "ERROR",
    "systemInfo": [
        { "name": "https://test.salesforce.com", "status": "connected OK", "sfdcObject": "Account", "size": 1 },
        { "name": "sfdc", "status": "HTTP HEAD on resource 'https://mvssy2.teale.ca.gov:9453/driversafetyapi_dev/' failed: not found (404)." }
    ],
    "description": "api is not healthy"
}
```

**Connector threw (no HTTP response — connection refused, DNS failure, timeout):**
```json
{
    "systemName": "vr-sf-papi-v1-conv",
    "status": "Connection refused (Connection refused) trying to connect to https://api.dxp-conv.dmv.ca.gov/..."
}
```

> **Why `systemName` and not `name`?**
> Child API health-check entries use `systemName` (matching the outer `systemInfo` array schema). Only entries produced by direct connector calls (Salesforce, DB) use `name`. Be consistent within a project — check existing entries in the DWL/payload before choosing.

> **Why accept 500 in the validator?**
> The Mule HTTP connector throws `HTTP:BAD_RESPONSE` for any 4xx/5xx by default. Setting `values="200,500"` (or `values="200..599"`) prevents that exception so the flow can inspect the response body and produce a meaningful status instead of a raw exception message.

---

## Step 5 — Rewrite / create `health-check-impl-flow` sub-flow

The scatter-gather is wrapped in a `<try>` scope. This is mandatory — sub-flows cannot have their own error handlers, so without the `try` scope, any `MULE:COMPOSITE_ROUTING` error escapes to the global error handler and returns the wrong response body format.

```xml
<sub-flow name="health-check-impl-flow" doc:id="<uuid>">
    <logger level="INFO" doc:name="Log correlationId" doc:id="<uuid>"
        message='#["Correlation Id: " ++ (vars.correlationId as String default correlationId)]' />

    <try doc:name="Try" doc:id="<uuid>">
        <scatter-gather doc:name="Scatter-Gather" doc:id="<uuid>">
            <route>
                <flow-ref doc:name="healthcheck-salesforce" doc:id="<uuid>" name="healthcheck-salesforce" />
            </route>
            <route>
                <flow-ref doc:name="healthcheck-db2" doc:id="<uuid>" name="healthcheck-db2" />
            </route>
            <!-- Add one <route> per additional connection target -->
        </scatter-gather>

        <ee:transform doc:name="Set Payload for healthcheck" doc:id="<uuid>">
            <ee:message>
                <ee:set-payload resource="dwl/p-health-check-response-transform.dwl" />
            </ee:message>
            <ee:variables>
                <ee:set-variable variableName="httpStatus"><![CDATA[%dw 2.0
output application/java
import * from dw::core::Arrays
var systemInfo = valuesOf(payload) map $.payload
---
if (sizeOf(systemInfo filter ($.status != "connected OK")) > 0) 500 else 200]]></ee:set-variable>
            </ee:variables>
        </ee:transform>

        <error-handler>
            <!-- Catches MULE:COMPOSITE_ROUTING or any DWL error —
                 always returns proper healthcheck shape, never the global error format -->
            <on-error-continue enableNotifications="true" logException="true"
                doc:name="On Error Continue" doc:id="<uuid>">
                <set-variable value="#[500]" doc:name="httpStatus = 500" doc:id="<uuid>"
                    variableName="httpStatus" />
                <ee:transform doc:name="Set degraded healthcheck payload" doc:id="<uuid>">
                    <ee:message>
                        <ee:set-payload><![CDATA[%dw 2.0
output application/json
import * from dw::core::Arrays
// MULE:COMPOSITE_ROUTING carries per-route results in error.errorMessage.payload
// Extract each route's payload (set by on-error-continue in each healthcheck flow)
// Fall back to a single generic entry only if nothing is extractable
var routeResults = error.errorMessage.payload default {}
var systemInfo =
  if (!isEmpty(routeResults))
    valuesOf(routeResults) map ((v) ->
      v.payload default {"name": "UNKNOWN", "status": (v.error.description default error.description)}
    )
  else
    [{"name": "UNKNOWN", "status": error.description}]
---
{
  "healthy": false,
  "name": Mule::p('api.name'),
  "version": Mule::p('api.version'),
  "env": Mule::p('env'),
  "correlationId": vars.correlationId default uuid(),
  "systemInfo": systemInfo,
  "description": "api is not healthy"
}]]></ee:set-payload>
                    </ee:message>
                </ee:transform>
            </on-error-continue>
        </error-handler>
    </try>
</sub-flow>
```

> **Why `try` scope is mandatory:**
> Sub-flows have no error handler scope. Without `try`, a `MULE:COMPOSITE_ROUTING` error from scatter-gather propagates to the parent APIkit flow, then to the global error handler, which returns the wrong body format (`{"error": [...]}`). The `try` scope ensures the healthcheck always returns `{"healthy": ..., "systemInfo": [...]}`.

> **Why `valuesOf(payload) map $.payload` instead of `payload..*payload`:**
> Scatter-gather in Mule 4 produces a `Map<String, TypedValue>` where each key is the route index. `payload..*payload` is unreliable when DataWeave encounters Java TypedValue wrappers and may return empty results. `valuesOf(payload) map $.payload` explicitly extracts each route's result payload and is guaranteed to work.

---

## Step 6 — Update the Ping sub-flow

```xml
<sub-flow name="Ping_Sub_Flow" doc:id="<uuid>">
    <set-variable value="#[200]" doc:name="httpStatus = 200" doc:id="<uuid>" variableName="httpStatus" />
    <ee:transform doc:name="Set Payload for ping" doc:id="<uuid>">
        <ee:message>
            <ee:set-payload><![CDATA[%dw 2.0
output application/json encoding="UTF-8"
---
{
  name: Mule::p('api.name'),
  version: Mule::p('api.version'),
  env: Mule::p('env'),
  success: "true"
}]]></ee:set-payload>
        </ee:message>
    </ee:transform>
</sub-flow>
```

---

## Step 7 — Update `p-health-check-response-transform.dwl`

The `filter ($.status != "connected OK")` condition handles both direct-connector failures (non-null status strings) **and** child API health-check "ERROR" entries — any status that is not exactly `"connected OK"` is treated as unhealthy. No DWL change is required to support the new child health-check pattern.

```dwl
%dw 2.0
output application/json
import * from dw::core::Arrays
var systemInfo = valuesOf(payload) map $.payload
var hasError = sizeOf(systemInfo filter ($.status != "connected OK")) > 0
---
{
  "healthy": !hasError,
  "name": Mule::p('api.name'),
  "version": Mule::p('api.version'),
  "env": Mule::p('env'),
  "correlationId": vars.correlationId default uuid(),
  "systemInfo": systemInfo,
  "description": if (hasError) "api is not healthy" else "api is healthy"
}
```

> **IDE scope warnings** for `payload`, `vars`, `Mule::p` in external `.dwl` files are expected — the IDE cannot resolve Mule runtime context without sample data

---

## Step 8 — Bump pom.xml patch version

Increment the `<version>` patch segment by 1:
- `1.0.6` → `1.0.7`
- `2.3.1` → `2.3.2`

---

## Key rules / gotchas

| Rule | Detail |
|---|---|
| `sizeOf` syntax | Always `sizeOf(collection filter condition) > 0` — NOT `(collection filter condition) sizeOf > 0` |
| Scatter-gather variable scope | Variables set inside routes don't propagate. Derive health from payload content, not `vars.healthCheckStatus` |
| `valuesOf(payload) map $.payload` | Correct way to extract scatter-gather route payloads. Do NOT use `payload..*payload` — unreliable with Mule 4 TypedValue maps |
| `try` scope is mandatory | Sub-flows have no error handler. Without `try`, `MULE:COMPOSITE_ROUTING` escapes to global handler, returning wrong body format |
| DB2 healthcheck query | `SELECT 1 FROM SYSIBM.SYSDUMMY1` (not `SELECT 1` — DB2 requires a table reference) |
| Salesforce healthcheck query | `SELECT Name FROM Account LIMIT 1` (Account is always accessible; avoid Organization) |
| Each route payload shape | Must be `{ "name"/"systemName": "<SYSTEM>", "status": "..." }` — the DWL `filter ($.status != "connected OK")` depends on this |
| HTTP child health-check: 200 vs 500 | **NEVER** return `"status": "connected OK"` for a non-200 child health-check response. 200 = "connected OK". Any non-200 (typically 500) = "ERROR" + pass through child's `systemInfo` and `description`. Always use `ee:transform` with `attributes.statusCode` check — NOT a plain `set-payload` — after an HTTP child health-check call. |
| HTTP child health-check: `values="200,500"` validator | Required on all child `/health-check` HTTP requests. Without it, the HTTP connector throws `HTTP:BAD_RESPONSE` on 500 and the `on-error-continue` receives a raw exception instead of the child's structured response body. |
| `systemName` vs `name` | Child API entries (Step 4b) use `systemName`. Direct connector entries (Step 4a — Salesforce, DB) use `name`. Be consistent with what already exists in the project. |
| Idempotent operations ONLY | Never INSERT/UPDATE/DELETE. Use SELECT, list, GET, or gibberish-data probe (see Step 3) |
| `/health-check` in RAML | Verify before implementing — if missing, notify the user to update the RAML spec first |
