---
name: generate-release-notes
description: Generate, write, create, or update release notes for a MuleSoft API,
  integration project, or OAS/RAML API specification. Use when the user asks for
  release notes, a changelog, version notes, hotfix documentation, "document this
  release", "write release notes for", "create release notes", "hotfix notes",
  "what changed between these specs", "diff these specs", "compare old and new spec",
  or provides two OAS/RAML/YAML spec files for comparison.
---

# MuleSoft API Release Notes Generator

Generate professional, complete release notes for a MuleSoft API project **or** an OAS/RAML specification comparison. Follow the mode that matches your input.

---

## Mode Detection — Choose Your Path

| If the user provides… | Use |
|----------------------|-----|
| A Mule project (pom.xml, XML flows, DWL) | **Mode A — Mule Project** |
| Two OAS/RAML spec files (old + new) | **Mode B — OAS Spec Diff** |
| Both a project and spec files | Run both modes and merge results |

---

## MODE A — Mule Project Release Notes

## Step 1 — Gather Required Information

Before writing anything, collect or infer the following fields. Read project files first; only ask the user for fields that cannot be determined automatically.

| Field | How to Obtain |
|-------|--------------|
| `apiName` | Read `pom.xml` → `<artifactId>`; or filename; or ask user |
| `version` | Read `pom.xml` → `<version>`; or latest git tag (`git describe --tags`); or ask user |
| `releaseDate` | Today's date unless user specifies otherwise |
| `environment` | Ask user (DEV / SIT / UAT / PROD) or infer from context |
| `releaseType` | Infer from semver bump: Major (X.0.0) / Minor (x.Y.0) / Patch (x.y.Z) / Hotfix |
| `summary` | 1–3 sentences — read the main flow XML and DWL to understand purpose |
| `newFeatures` | Read `src/main/mule/` XML flows, DataWeave `.dwl` files, FFDs; ask if unclear |
| `bugFixes` | Run `git log --oneline` or ask user for Jira IDs / fix descriptions |
| `breakingChanges` | Look for: renamed flows, removed endpoints, schema/FFD changes, removed fields |
| `configChanges` | Diff `src/main/resources/properties/` and `config.yaml` files |
| `dependencies` | Diff `pom.xml` `<dependencies>` section between versions |
| `deploymentNotes` | Ask user: new secrets, environment variables, Anypoint property changes |
| `testedBy` | Ask user: QA engineer name or "N/A" |
| `approvedBy` | Ask user: approving manager/architect name |

### File Reading Sequence
1. `pom.xml` → apiName, version, dependencies
2. `src/main/mule/` → new/modified flows, error handlers
3. `src/main/resources/dwl/` → new/modified DataWeave transforms
4. `src/main/resources/properties/config*.yaml` → config changes
5. `git log --oneline -20` → recent commits, Jira IDs, bug fixes

---

## Step 2 — Classify the Release Type

Use semantic versioning to determine release type:

| Version Change | Release Type | Typical Content |
|---------------|-------------|----------------|
| `X.0.0` | **Major** | Breaking changes, API redesign, new major capability |
| `x.Y.0` | **Minor** | New features, non-breaking additions |
| `x.y.Z` | **Patch** | Bug fixes, performance improvements, minor config changes |
| `x.y.Z-hotfix` | **Hotfix** | Emergency fix for critical production issue |

---

## Step 3 — Audience Check

Before writing, determine the audience. Ask the user if not stated:
- **External** (Partners, Integrators, Consumers, Public) → omit Deployment Notes, Approvals, Jira/Confluence links, internal environment details
- **Internal** (Developers, Architects, QA, DevOps) → include all sections

---

## Step 4 — Write the Release Notes

Use the template below. Omit any section that has no content. Do NOT leave placeholder text — every field must be filled or the section removed. Apply audience rules from Step 3.

```markdown
# Release Notes — {apiName}

**Audience:** {External Partners / Internal}
**Version:** {version}
**Release Date:** {releaseDate}
**Release Type:** {releaseType}
**Environment:** {environment — omit if audience is External}
**Prepared By:** Agentforce MuleSoft Developer Agent

---

## Summary

{summary — 1–3 sentences describing what this release does and why}

---

## New Features

{List each new feature as a bullet. Include flow name or endpoint if relevant.}

- **{Feature Name}** — {Description}. Flow: `{flow-name}`, Endpoint: `{method} {path}`.
- ...

*(Omit this section if no new features)*

---

## Bug Fixes

{List each bug fix with Jira ID if available.}

- **[{JIRA-ID}]** {Description of bug and fix}.
- ...

*(Omit this section if no bug fixes)*

---

## Breaking Changes

> ⚠️ **Action Required** — the following changes are not backward-compatible.

- **{Change}** — {Impact and migration steps}.
- ...

*(Omit this section if no breaking changes)*

---

## Configuration Changes

{List any new or changed property keys, environment variables, or Anypoint Platform settings.}

| Property Key | Old Value | New Value | Environment | Notes |
|-------------|----------|----------|-------------|-------|
| `{key}` | `{old}` | `{new}` | All / DEV / PROD | {note} |

*(Omit this section if no config changes)*

---

## Dependency Changes

{List added, updated, or removed Maven dependencies.}

| Dependency | Change | Old Version | New Version |
|-----------|--------|------------|------------|
| `{groupId}:{artifactId}` | Added / Updated / Removed | `{old}` | `{new}` |

*(Omit this section if no dependency changes)*

---

## Deployment Notes

*(Internal audience only — omit entirely for External audience)*

{Special instructions for deploying this release: new secrets to configure,
Anypoint Platform steps, database migrations, SFTP path changes, etc.}

- {Deployment instruction 1}
- {Deployment instruction 2}

*(Also omit if standard deployment applies with no special steps)*

---

## Testing

*(Internal audience only — omit entirely for External audience)*

**Tested By:** {name or team}
**Test Environments:** {DEV / SIT / UAT}
**Test Coverage:** {MUnit / Postman / Manual — brief summary}

---

## Approvals

*(Internal audience only — omit entirely for External audience)*

| Role | Name | Date |
|------|------|------|
| Developer | {name} | {date} |
| QA Engineer | {name} | {date} |
| Architect / Lead | {approvedBy} | {date} |

---

## Related Links

*(Internal audience only — omit entirely for External audience)*

- Jira Epic/Story: {URL or N/A}
- Confluence Design Doc: {URL or N/A}
- Anypoint Exchange: {URL or N/A — include for all audiences if public}
```

---

## Step 5 — Output Format

- **Default:** Write the release notes as a new Markdown file named `RELEASE_NOTES_{version}.md` in the project root.
- If the user specifies a different location or format (Word, Confluence, email), adjust accordingly.
- Keep language concise and professional — avoid filler phrases.
- All dates in `MM/DD/YYYY` format unless user specifies otherwise.

---

## Step 6 — Validation Checklist

Before presenting the release notes, verify:

- [ ] Audience determined and applied — External audience has no Deployment Notes, Approvals, Jira/Confluence links, or internal environment details
- [ ] Version matches `pom.xml`
- [ ] Release date is correct
- [ ] No placeholder text remains (no `{curly braces}` in output)
- [ ] Config changes section omitted if no property files changed
- [ ] Deployment Notes omitted for External audience OR if no special deployment steps
- [ ] Approvals omitted for External audience
- [ ] Related Links omitted for External audience

---

## MODE B — OAS / RAML Spec Comparison Release Notes

Use this mode when the user provides **two spec files** (old version + new version) in OAS 3.x, OAS 2.x (Swagger), or RAML format.

---

### B1 — Read Both Specs

Read both files in full:
- **Old spec** = the baseline (what consumers currently depend on)
- **New spec** = the proposed release (what will be deployed)

Extract from each spec:
- `info.title` and `info.version` → API name and version
- Spec format version (OAS 2, OAS 3, RAML) → detect if format itself changed
- All `paths` entries → endpoints, methods, parameters, request/response schemas
- All `components/schemas` (OAS 3) or `definitions` (OAS 2) → data models
- `securitySchemes` / `securityDefinitions` → auth methods
- `servers` (OAS 3) or `host`/`basePath` (OAS 2) → base URL

---

### B2 — Diff the Two Specs

Systematically compare old vs new across every dimension. Classify every identified change into one of these four categories:

| Category | Definition |
|----------|-----------|
| **Removed** | Something in the old spec is absent in the new spec |
| **Renamed** | A field/property exists in both specs but under a different name (not just a type change) |
| **Updated** | Something exists in both specs but its definition changed: type, format, constraints (min/max, minLength, maxLength, minItems, maxItems), required flag, enum values, header required/optional, base URL |
| **Added** | Something new in the new spec that did not exist in the old spec |

**Only record items that actually changed. Skip categories and dimensions with no changes.**

#### Endpoints (Paths)

| What changed | Category |
|-------------|----------|
| Path removed from new spec | Removed |
| HTTP method removed from path | Removed |
| Required parameter removed | Removed |
| Required request body field removed | Removed |
| Response field removed | Removed |
| HTTP status code removed | Removed |
| Field renamed (same semantics, different name) | Renamed |
| Response field renamed | Renamed |
| Field type changed (e.g. `string` → `integer`) | Updated |
| Field constraint changed (min, max, minLength, pattern) | Updated |
| Array constraint changed (minItems, maxItems) | Updated |
| Required flag changed (optional → required or required → optional) | Updated |
| Enum introduced or enum values changed | Updated |
| Header changed from optional to required | Updated |
| New path added | Added |
| New optional field added to request body | Added |
| New optional parameter added | Added |
| New field added to response | Added |
| New HTTP status code added | Added |

#### Response / Error Schema

| What changed | Category |
|-------------|----------|
| Error response field removed | Removed |
| Error response field renamed | Renamed |
| Error code type changed (e.g. integer → string) | Updated |
| Success response field renamed | Renamed |
| New field added to success response | Added |
| New field added to error response | Added |

#### Security

| What changed | Category |
|-------------|----------|
| Security scheme removed | Removed |
| OAuth2 scope removed | Removed |
| Security scheme type changed | Updated |
| New security scheme added | Added |
| New OAuth2 scope added | Added |

#### Base URL / Servers

| What changed | Category |
|-------------|----------|
| `servers[0].url` changed (OAS 3) | Updated |
| `host` or `basePath` changed (OAS 2) | Updated |

#### Data Models / Schemas

| What changed | Category |
|-------------|----------|
| Schema removed | Removed |
| Required field removed from schema | Removed |
| Field renamed in schema | Renamed |
| Field type changed | Updated |
| Constraint changed (min, max, enum, format) | Updated |
| Schema reference changed (e.g. `$ref` points to different schema) | Updated |
| Optional field added to schema | Added |
| New schema added | Added |

#### Spec Format

| What changed | Category |
|-------------|----------|
| Spec format upgraded (e.g. OAS 2.0 → OAS 3.0.3) | Updated (document in Spec Format section) |

---

### B3 — Classify the Release Type

Based on the diff:

| Diff Result | Release Type |
|-------------|-------------|
| Any Removed, Renamed, or Updated items present | **Major** |
| Only Added items | **Minor** |
| Only description, example, or metadata text changes | **Patch** |

Use the version numbers from the spec files if provided. If the user specifies versions explicitly, use those.

---

### B4 — Write the OAS Release Notes

**Rules for the output:**
- Neutral, factual language only. Do NOT write "breaking change", "action required", "must update", "will break", or any alarming wording.
- Describe what changed factually — not the consumer impact.
- **Only write sections that have actual changes.** If a category has no items, omit the entire section and its heading. Never include an empty table or a heading with no content.
- Use field-level mapping tables (Previous → Current) whenever fields are renamed or have type/constraint changes — this is clearer than prose.
- For per-endpoint schema changes, use a dedicated per-endpoint breakdown section (Section 8 pattern) when there are 3 or more endpoints with schema changes.
- **Audience-based section rules** — apply the table below strictly:

| Section | External Audience | Internal Audience |
|---------|------------------|------------------|
| Deployment Notes | **Omit entirely** | Include if needed |
| Approvals | **Omit entirely** | Include |
| Related Links (Jira, Confluence, internal URLs) | **Omit entirely** | Include |
| Anypoint Exchange link | Include (public) | Include |
| Scope of This Release | Include | Include |
| All technical change sections (1–10) | Include | Include |

If the audience is **External** or contains the word "Partner", "Consumer", or "Integrator" — remove Deployment Notes, Approvals, and Related Links from the output entirely.
If the audience is **Internal** — all sections may be included.

Use this template. Include only the sections that apply.

```markdown
# {info.title} — Release Notes

**Audience:** {External Partners / Internal / All consumers — ask user if unknown}
**Previous Version:** {old spec info.version} ({old spec format, e.g. Swagger 2.0})
**Current Version:** {new spec info.version} ({new spec format, e.g. OpenAPI 3.0.3})
**Release Date:** {today's date}
**Prepared By:** Agentforce MuleSoft Developer Agent

---

## Summary

{1–3 neutral sentences stating what this version introduces, what changed,
and what was removed — factual, no alarm language.}

---

## Scope of This Release

{Only include if the release covers a defined subset of endpoints
(e.g., not all endpoints are finalized or ready). List what IS covered.}

| Endpoint | Identifier | Description |
|----------|-----------|-------------|
| `{METHOD} {/path}` | {TTC code or operation ID} | {Brief description} |

*(Omit this section if all endpoints in the spec are in scope)*

---

## 1. Spec Format

{Only include if the spec format itself changed, e.g. Swagger 2.0 → OpenAPI 3.0.3.}

The API specification has been updated from **{old format}** to **{new format}**.

---

## 2. Success Response Changes

{Only include if success response schemas changed.}

### 2.1 New Fields

{List new fields added to success responses.}

| Field | Type | Description |
|-------|------|-------------|
| `{fieldName}` | `{type}` | {What it represents} |

### 2.2 Updated Fields

{List fields that changed type, constraints, or were renamed.}

| Previous Field | Current Field | Change |
|---------------|--------------|--------|
| `{oldName}` | `{newName}` | Renamed |
| `{fieldName}` | `{fieldName}` | Type changed from `{old}` to `{new}` |

### 2.3 Removed Fields

| Field | Notes |
|-------|-------|
| `{fieldName}` | {e.g. "No longer included in this version."} |

*(Include only the subsections — New Fields, Updated Fields, Removed Fields — that apply. Omit the rest.)*

---

## 3. Error Response Changes

{Only include if the error response schema changed.}

### Field Mapping

{Use a mapping table when fields are renamed or removed — clearest format for consumers.}

| Previous Field | Current Field | Change |
|---------------|--------------|--------|
| `{oldFieldName}` | `{newFieldName}` | Renamed |
| `{fieldName}` | *(removed)* | No longer present |
| *(new)* | `{newFieldName}` | Added — {description} |
| `{fieldName}` | `{fieldName}` | Type changed from `{old type}` to `{new type}` |

---

## 4. Header Changes

{Only include if request or response headers changed.}

| Header | Endpoint | Change |
|--------|----------|--------|
| `{headerName}` | `{METHOD} {/path}` | {e.g. "Changed from optional to required."} |

---

## 5. Documentation Enhancements

{Only include if descriptions, examples, or validation documentation were added
without structural changes.}

- {e.g. "All request schema fields now include `description` properties with validation rules."}
- {e.g. "Error response now documents DMV system-level error codes as strings."}
- {e.g. "Several endpoints include sample request and response payloads."}

*(Omit if no documentation-only changes)*

---

## 6. New Endpoints

{Only include if new paths were added.}

| Method | Path | Identifier | Description |
|--------|------|-----------|-------------|
| `{METHOD}` | `{/new/path}` | {TTC / operation ID} | {What it does} |

---

## 7. Removed Endpoints

{Only include if paths were removed.}

| Method | Path | Notes |
|--------|------|-------|
| `{METHOD}` | `{/old/path}` | {e.g. "Removed in this version."} |

---

## 8. Request Schema Changes by Endpoint

{Only include this section if individual endpoints have request schema changes.
Create one subsection per affected endpoint. Omit endpoints with no changes.}

### 8.1 `{METHOD} {/path}` ({identifier})

**New required fields:**

| Field | Notes |
|-------|-------|
| `{fieldName}` | {Description of the field} |

**Fields removed from required:**

| Field | Notes |
|-------|-------|
| `{fieldName}` | {e.g. "No longer required; still available as optional."} |

**Field constraint changes:**

| Field | Previous | Current |
|-------|---------|---------|
| `{fieldName}` | `{old type}`, {old constraint} | `{new type}`, {new constraint} |

**New fields added to schema:**

| Field | Type | Notes |
|-------|------|-------|
| `{fieldName}` | `{type}` | {Description} |

*(Repeat as 8.2, 8.3, etc. for each affected endpoint. Only include sub-tables that have content.)*

---

## 9. Data Model Changes

{Only include if shared schemas changed independently of endpoint schemas.}

### 9.1 `{SchemaName}`

| Field | Previous | Current |
|-------|---------|---------|
| `{fieldName}` | `{old definition}` | `{new definition}` |

---

## 10. Deprecation Notices

{Only include if items are marked deprecated but not yet removed.}

- `{METHOD} {/path}` — marked as deprecated in this version. Replaced by `{METHOD} {/new/path}`.

---

## Deployment Notes

*(Internal audience only — omit entirely for External audience)*

{Only include if specific steps are required beyond a standard spec publish.}

- {e.g. "Publish updated spec to Anypoint Exchange."}
- {e.g. "Update API Manager instance if base URL changed."}

---

## Approvals

*(Internal audience only — omit entirely for External audience)*

| Role | Name | Date |
|------|------|------|
| API Designer | {name} | {date} |
| Architect / Lead | {name} | {date} |

---

## Related Links

*(Internal audience only — omit entirely for External audience)*

- Previous Spec: {filename or URL}
- Current Spec: {filename or URL}
- Jira: {URL or N/A}
- Anypoint Exchange: {URL or N/A — may include for all audiences if publicly accessible}
```

---

### B5 — OAS Validation Checklist

Before presenting, verify:

- [ ] Audience field populated — External audience has no Deployment Notes, Approvals, or Jira/internal links
- [ ] Deployment Notes, Approvals, and Related Links omitted when audience is External / Partner / Consumer / Integrator
- [ ] No alarming language — "breaking change", "action required", "will break" must not appear
- [ ] Only sections with actual changes are present — no empty headings, no empty tables
- [ ] Spec Format section (Section 1) present if the format itself changed
- [ ] Scope of This Release table present if only a subset of endpoints is covered
- [ ] Success Response and Error Response sections use field mapping tables (Previous → Current)
- [ ] Section 8 (per-endpoint schema changes) present if 3+ endpoints have schema changes
- [ ] Field constraint changes (type, min/max, enum, minItems/maxItems) captured in Section 8 tables
- [ ] Renamed fields shown with Previous Field → Current Field mapping, not just listed as removed+added
- [ ] No placeholder `{curly braces}` remain in the output
- [ ] Version numbers match what is in the provided spec files
