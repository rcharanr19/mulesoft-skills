---
name: write-validate-munit

NOTE: MUST EXECUTE IN COMPACT MODE

description: Write, generate, validate, fix, or run MUnit tests for any Mule codebase. Call use_skill as your FIRST and ONLY action when the user asks to write MUnit tests, generate MUnit test suites, create unit tests for Mule flows, validate MUnit coverage, fix failing MUnit tests, or run MUnit tests. Trigger phrases include "write munit", "generate munit", "create munit tests", "add munit", "munit coverage", "fix munit", "run munit tests", "unit test my flow". When you call this skill, it must be the only tool call in that response.
license: Apache-2.0
metadata:
  author: mule-dx-tooling
  version: "4.1.0"
  theme: professional
allowed-tools: Bash Read Write Edit AskUserQuestion
---

# Enhanced MuleSoft MUnit v4.1 - Battle-Tested & Production Ready

You are a Technical Architect with deep knowledge of MuleSoft, Integration Architecture, and Software Engineering Best Practices. Your task is to Write and validate MUnits for any Mule codebase and generate Coverage Report. This skill includes battle-tested lessons learned from successful MUnit implementations across multiple repositories.

## Prerequisites
- Repository URL or local path
- Target environment (DEV/PROD/etc.) - specify if available
- Access to Anypoint Platform (if available for policy validation)
- Maven environment for test execution
- **MUST** use dmv-maven-settings.xml while running Maven Commands as needed
- **CRITICAL**: Java 8 JDK (**MUST** be Java 8, **NOT** Java 17) - see Java Configuration section below

---

## ⚠️ MANDATORY PRE-TEST STEP 0: Create/Verify Test Properties File (MUST EXECUTE BEFORE WRITING ANY MUNIT XML)

**THIS STEP IS NON-NEGOTIABLE — COMPLETE THIS BEFORE WRITING A SINGLE LINE OF MUNIT XML.**

### config-test.yaml File Placement (CRITICAL — `src/main/resources` ONLY)

Create the config file in **`src/main/resources/properties/config-test.yaml` ONLY**.

| Location | Purpose |
|---|---|
| `src/main/resources/properties/config-test.yaml` | **ONLY location** — Mule's embedded MUnit runner deploys the application using the **main classpath**. The `configuration-properties file="properties\config-${env}.yaml"` is resolved from the main classpath. This is the only copy needed. |

> **⚠️ DO NOT create `src/test/resources/properties/config-test.yaml`** — the MUnit embedded runner uses the application (main) classpath to load configuration properties. Adding a copy in `src/test/resources` is redundant and against DMV project standards.

> **Important for plugin-provided YAML files (e.g., `properties_common_log_jar/test-jar.yaml`):** If a `mule-plugin` dependency loads its own `configuration-properties` file using `file="some-dir/${env}-jar.yaml"`, place any missing `test-jar.yaml` files also in `src/main/resources/some-dir/` — NOT in `src/test/resources`.

Create or verify **both** copies contain ALL of the following properties. These keys map **1:1** to the `-D` system property flags in the DMV Final Sanity Check Maven command:

> **⚠️ SECURITY RULE — ALWAYS USE DUMMY/PLACEHOLDER VALUES**: All credentials (`client_id`, `client_secret`, `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, secure keys, Salesforce usernames/tokens) MUST be dummy values. Real credentials are **never needed** for MUnit because all outbound connectors are fully mocked. Never commit actual credentials to source control.

```yaml
# config-test.yaml — MANDATORY DMV TEST PROPERTIES (ALL values quoted strings)
# NOTE: All credential fields use DUMMY/PLACEHOLDER values — real credentials are never needed for MUnit
env: "test"
auth:
  client_id: "dummy-test-client-id"
  client_secret: "dummy-test-client-secret"
  url: "https://login.microsoftonline.com/00000000-0000-0000-0000-000000000000/oauth2/v2.0/token"
secrets:
  url: "https://api.example.com/secrets-manager-sapi/secrets"
secure:
  key: "dummy-test-key"
mule:
  SecureKey: "dummy-test-secure-key"
# AWS MUST be present even when SQS/S3 is fully mocked — SDK initializes at startup
# Using AWS official documentation placeholder values (non-functional)
AWS_ACCESS_KEY_ID: "AKIAIOSFODNN7EXAMPLE"
AWS_SECRET_ACCESS_KEY: "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
common-sf-config:
  username: "testuser@example.com.test"
  token: "https://example--test.sandbox.my.salesforce.com/services/oauth2/token"
  audience: "https://test.salesforce.com"
logging:
  queueURL: "https://sqs.us-east-1.amazonaws.com/000000000000/dummy-logging-queue.fifo"
  testQueueARN: "arn:aws:sqs:us-east-1:000000000000:dummy-logging-queue.fifo"
keystore:
  jks: "u3+7QAAAAIAAAABAAAAAQBLYXBpLmR4cC1ub25wcm9kLmRtdi5jYS5nb3YgKHNlY3RpZ28gcHVibGljIHNlcnZlciBhdXRoZW50aWNhdGlvbiBjYSBvdiByMzYpAAABmMj5S3c="
pod2podTruststore: "u3+7QAAAAIAAAABAAAAAQBLYXBpLmR4cC1ub25wcm9kLmRtdi5jYS5nb3YgKHNlY3RpZ28gcHVibGljIHNlcnZlciBhdXRoZW50aWNhdGlvbiBjYSBvdiByMzYpAAABmMj5S3c="
keystore.jks: "u3+7QAAAAIAAAABAAAAAQBLYXBpLmR4cC1ub25wcm9kLmRtdi5jYS5nb3YgKHNlY3RpZ28gcHVibGljIHNlcnZlciBhdXRoZW50aWNhdGlvbiBjYSBvdiByMzYpAAABmMj5S3c="
api:
  name: "vr-nmvtis-sol-papi-v1"
  version: "v1"
  id: "test-api-id"
http-listener:
  host: "0.0.0.0"
  port: "8081"
  path: "/api/*"
  console: "/console/*"
  keep.raml.uri: "false"
  console.enabled: "false"
  timeout: "180000"
transactionOriginator: "C6"
messageOriginator: "C6"
messageDestination: "OO"
  vr:
  sf-config:
    username: "testuser@example.com.test"
    token: "https://example--test.sandbox.my.salesforce.com/services/oauth2/token"
    audience: "https://test.salesforce.com"
  sf:
    recordLoopCount: "2"
  aws-sqs:
    request:
      queueURL: "https://sqs.us-east-1.amazonaws.com/000000000000/dummy-request-queue.fifo"
      testQueueARN: "arn:aws:sqs:us-east-1:000000000000:dummy-request-queue.fifo"
    response:
      queueURL: "https://sqs.us-east-1.amazonaws.com/000000000000/dummy-response-queue.fifo"
      testQueueARN: "arn:aws:sqs:us-east-1:000000000000:dummy-response-queue.fifo"
untilsuccess:
  retries: "1"
  interval: "1000"
until-successful:
  jobId:
    maxRetries: "1"
    timeDuration: "1000"
vr-sf:
  retry:
    Timeduration: "1000"
    maxretries: "1"
  response:
    time-out: "30000"
nmvtis:
  sysapi:
    host: "api.dxp-dev.dmv.ca.gov"
    port: "443"
    basepath: "vr-nmvtis-sol-aamva-sapi-v1-dev/api"
    sol-sf-sapi:
      basepath: "/vr-nmvtis-sol-sf-sapi-v1-dev/api"
  successAggregatorCount: "2"
  failureAggregatorCount: "2"
  responseAggregator: "10"
  timeOut:
    success: "40"
    failure: "40"
  foreach:
    success: "2"
    failure: "2"
    iterateCount: "1"
```

**Validate zero gaps before writing any test:**
```bash
grep -rh "Mule::p('" src/main/mule/ | sed "s/.*Mule::p('//;s/').*//" | sort -u
grep -rh "\${" src/main/mule/ | grep -v "xmlns\|schemaLocation" | sed "s/.*\${//;s/}.*//" | sort -u
```

---

## CRITICAL SUCCESS FACTORS

### Java Configuration (MANDATORY - Cross-Platform)
**CRITICAL**: Java 8 is required for MUnit tests - Java 17 has module system incompatibilities.

Detection script:
```bash
if [[ "$OSTYPE" == "darwin"* ]]; then
    for j in "/Library/Java/JavaVirtualMachines/temurin-8.jdk/Contents/Home" \
              "/Library/Java/JavaVirtualMachines/adoptopenjdk-8.jdk/Contents/Home" \
              "/Library/Java/JavaVirtualMachines/zulu-8.jdk/Contents/Home"; do
        [ -d "$j" ] && export JAVA_HOME="$j" && break
    done
elif [[ "$OSTYPE" == "msys" ]] || grep -q Microsoft /proc/version 2>/dev/null; then
    for j in "/c/Program Files/Eclipse Adoptium/jdk-8.0.412.8-hotspot" \
              "/c/Program Files/Java/jdk1.8.0_"*; do
        [ -d "$j" ] && export JAVA_HOME="$j" && break
    done
else
    for j in "/usr/lib/jvm/temurin-8-jdk-amd64" "/usr/lib/jvm/java-8-openjdk-amd64" "/opt/java/openjdk"; do
        [ -d "$j" ] && export JAVA_HOME="$j" && break
    done
fi
export PATH=$JAVA_HOME/bin:$PATH
java -version  # Must show 1.8.x
```

If Java 8 is not installed: https://adoptium.net/temurin/releases/?version=8

### Mule Runtime and Plugin Version Compatibility Matrix
**BATTLE-TESTED WORKING CONFIGURATION:**
- Mule Runtime: 4.6.4 (DO NOT use 4.7.x with Java 8)
- MUnit Plugin: 2.3.16 (NOT 3.5.0+ with older runtime)
- MUnit Extensions: 1.1.2
- HTTP Connector: 1.7.3 (NOT 1.7.5+ - causes conflicts)

```xml
<mule.version>4.6.4</mule.version>
<munit.version>2.3.16</munit.version>
<munit.extensions.maven.plugin.version>1.1.2</munit.extensions.maven.plugin.version>

<plugin>
    <groupId>com.mulesoft.munit.tools</groupId>
    <artifactId>munit-maven-plugin</artifactId>
    <version>2.3.16</version>
</plugin>

<dependency>
    <groupId>org.mule.connectors</groupId>
    <artifactId>mule-http-connector</artifactId>
    <version>1.7.3</version>
    <classifier>mule-plugin</classifier>
</dependency>
```

### MUnit Schema Configuration (CRITICAL)
ALWAYS use "current" schema versions - NOT specific versions:

```xml
<mule xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xmlns:munit="http://www.mulesoft.org/schema/mule/munit"
      xmlns:munit-tools="http://www.mulesoft.org/schema/mule/munit-tools"
      xmlns:doc="http://www.mulesoft.org/schema/mule/documentation"
      xmlns="http://www.mulesoft.org/schema/mule/core"
      xsi:schemaLocation="
        http://www.mulesoft.org/schema/mule/core http://www.mulesoft.org/schema/mule/core/current/mule.xsd
        http://www.mulesoft.org/schema/mule/munit http://www.mulesoft.org/schema/mule/munit/current/mule-munit.xsd
        http://www.mulesoft.org/schema/mule/munit-tools http://www.mulesoft.org/schema/mule/munit-tools/current/mule-munit-tools.xsd">

    <munit:config name="test-suite-name.xml"/>
```

CRITICAL: ALWAYS include xmlns:doc namespace. Missing it causes "The prefix 'doc' for attribute 'doc:id' is not bound" errors.

## PROVEN STRATEGIES

### Strategy 1: Property Resolution
All flows require comprehensive property setup. Missing properties cause 90% of MUnit failures.

```yaml
# src/main/resources/properties/config-test.yaml
api:
  name: "test-api"
  version: "1.0.0"
  id: "test-api-id"
  port: "8081"
env: "test"
mule.env: "test"
secure:
  key: "test-key"
common-sf-config:
  username: "test@example.com"
  token: "https://test.salesforce.com/services/oauth2/token"
  audience: "https://test.salesforce.com"
AWS_ACCESS_KEY_ID: "AKIA-test-key"
AWS_SECRET_ACCESS_KEY: "test-secret-key"
```

### Strategy 2: Simple Mocking Patterns (PROVEN)
PHILOSOPHY: Mock the connection steps, assume connection is successful, do functional validation on DataWeave and business logic.

#### SQS Connector Mocking
```xml
<munit:behavior>
    <munit-tools:mock-when processor="sqs:get-queue-attributes">
        <munit-tools:with-attributes>
            <munit-tools:with-attribute whereValue="Get queue attributes" attributeName="doc:name" />
        </munit-tools:with-attributes>
        <munit-tools:then-return>
        </munit-tools:then-return>
    </munit-tools:mock-when>
</munit:behavior>

<munit-tools:mock-when processor="sqs:send-message">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute whereValue="clets_stop_message_sqs_publish" attributeName="doc:name" />
    </munit-tools:with-attributes>
    <munit-tools:then-return>
    </munit-tools:then-return>
</munit-tools:mock-when>
```

#### HTTP Request Mocking
```xml
<munit-tools:mock-when processor="http:request">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute attributeName="config-ref" whereValue="HTTP_Request_configuration"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return>
        <munit-tools:payload value='#[output application/json --- {"status": "success"}]' mediaType="application/json"/>
        <munit-tools:attributes value="#[{}]"/>
    </munit-tools:then-return>
</munit-tools:mock-when>
```

#### Database Connector Mocking
```xml
<munit-tools:mock-when processor="db:select">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute attributeName="doc:name" whereValue="Get Records"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return>
        <munit-tools:payload value='#[output application/json --- [{"id": 1, "name": "Test Record", "status": "active"}]]'/>
    </munit-tools:then-return>
</munit-tools:mock-when>
```

#### Salesforce Connector Mocking
```xml
<munit-tools:mock-when processor="salesforce:query">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute attributeName="doc:name" whereValue="Query SF Records"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return>
        <munit-tools:payload value='#[output application/json --- {"totalSize": 1, "done": true, "records": [{"Id": "003XX000004TmiQQAS", "Name": "Test Account"}]}]'/>
    </munit-tools:then-return>
</munit-tools:mock-when>
```

#### Flow Reference Mocking (Complex Flows)
```xml
<munit-tools:mock-when processor="flow-ref">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute attributeName="name" whereValue="complex-external-integration-flow"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return>
        <munit-tools:payload value='#[output application/json --- {"result": "mocked", "processed": true, "recordId": "12345"}]'/>
    </munit-tools:then-return>
</munit-tools:mock-when>
```

KEY INSIGHT: Always mock by doc:name attribute when possible - it is more reliable than config-ref matching.

---

## ⚠️ MANDATORY RULE: Mock ALL Outbound Connectors (MUST — NO EXCEPTIONS)

**THIS IS A HARD REQUIREMENT. Every outbound connector call in the flow under test MUST have a corresponding mock in `<munit:behavior>`. Failure to mock any single outbound call will cause the test to attempt a real network connection, failing with `Connection refused` or credential errors.**

### Connectors That MUST ALWAYS Be Mocked

| Connector Type | Processor Patterns to Mock |
|---------------|---------------------------|
| **Amazon SQS** | `sqs:send-message`, `sqs:receive-messages`, `sqs:get-queue-attributes`, `sqs:delete-message` |
| **Amazon S3** | `s3:put-object`, `s3:get-object`, `s3:delete-object`, `s3:list-objects` |
| **HTTP/HTTPS** | `http:request` (ALL outbound HTTP calls — every `doc:name` variant) |
| **Salesforce SOQL** | `salesforce:query`, `salesforce:query-single`, `salesforce:create`, `salesforce:update`, `salesforce:upsert`, `salesforce:delete` |
| **Salesforce Apex** | `salesforce:invoke-apex-rest-method`, `salesforce:invoke-apex-soap-method` |
| **Database (SQL)** | `db:select`, `db:insert`, `db:update`, `db:delete`, `db:stored-procedure` |

### MANDATORY Mock Response Payload Rule

**When mocking any outbound connector, the `<munit-tools:then-return>` payload MUST be derived from the DataWeave `<ee:transform>` / `<ee:set-payload>` that immediately follows that connector call in the flow XML.**

**Procedure:**
1. Locate the connector call in the flow XML.
2. Find the **very next** `<ee:transform>` or `<set-payload>` after it that sets `payload`.
3. Read what fields that transform reads from the connector response.
4. Build the mock return payload to supply exactly those fields with realistic dummy data.

**Example — SQS send followed by a variable/payload set:**
```xml
<munit-tools:mock-when processor="sqs:send-message">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute attributeName="doc:name" whereValue="Publish to NMVTIS Request Queue"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return>
        <munit-tools:payload value='#[output application/json --- {"messageId": "test-msg-id-001"}]'
                             mediaType="application/json"/>
    </munit-tools:then-return>
</munit-tools:mock-when>
```

> **If nothing follows the connector call**, use an empty `<munit-tools:then-return/>`.

---

### Strategy 3: Data Type Precision (Critical Fix)
```xml
<!-- WRONG -->
<set-variable value="200" variableName="httpStatus"/>
<munit-tools:assert-that expression="#[vars.httpStatus]" is="#[MunitTools::equalTo(200)]"/>

<!-- CORRECT - Integer -->
<set-variable value="#[200]" variableName="httpStatus"/>
<munit-tools:assert-that expression="#[vars.httpStatus]" is="#[MunitTools::equalTo(200)]"/>

<!-- CORRECT - String -->
<set-variable value="success" variableName="status"/>
<munit-tools:assert-that expression="#[vars.status]" is="#[MunitTools::equalTo('success')]"/>
```

### Strategy 4: Flow Mocking vs Property Mocking
```xml
<munit-tools:mock-when processor="flow-ref">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute attributeName="name" whereValue="ping-flow"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return>
        <munit-tools:payload value='#[output application/json --- {"name": "test-api", "version": "1.0.0", "env": "test", "success": "true"}]' mediaType="application/json"/>
    </munit-tools:then-return>
</munit-tools:mock-when>
```

### Strategy 5: XML Structure Best Practices
```xml
<munit:test name="descriptive-test-name" doc:id="unique-id">
    <munit:behavior>
        <munit-tools:mock-when processor="http:request">
            <!-- Mock configuration -->
        </munit-tools:mock-when>
        <munit:set-event doc:name="Set Input Event">
            <munit:payload value='#[output application/json --- {"test": "data"}]'/>
            <munit:variables>
                <munit:variable key="testVar" value="testValue"/>
            </munit:variables>
        </munit:set-event>
    </munit:behavior>
    <munit:execution>
        <flow-ref name="target-flow"/>
    </munit:execution>
    <munit:validation>
        <munit-tools:assert-that expression="#[payload.status]" is="#[MunitTools::equalTo('success')]"/>
    </munit:validation>
</munit:test>
```

### Strategy 6: MUnit Console Reporting Configuration
```xml
<plugin>
    <groupId>com.mulesoft.munit.tools</groupId>
    <artifactId>munit-maven-plugin</artifactId>
    <version>${munit.version}</version>
    <executions>
        <execution>
            <id>test</id>
            <phase>test</phase>
            <goals>
                <goal>test</goal>
                <goal>coverage-report</goal>
            </goals>
        </execution>
    </executions>
    <configuration>
        <coverage>
            <runCoverage>true</runCoverage>
            <formats>
                <format>html</format>
                <format>console</format>
            </formats>
        </coverage>
        <runtimeProduct>MULE_EE</runtimeProduct>
        <dynamicPorts>
            <dynamicPort>http.port</dynamicPort>
            <dynamicPort>https.port</dynamicPort>
        </dynamicPorts>
    </configuration>
</plugin>
```

### Strategy 7: CI/CD Compatible YAML Configuration
All YAML values MUST be quoted strings for CI/CD compatibility.

```yaml
http:
  listener:
    host: "0.0.0.0"
    port: "8081"
api:
  name: "your-api-name"
  version: "v1"
  id: "your-api-id"
env: "test"
mule:
  env: "test"
```

### Strategy 8: Maven Command and CI/CD Script
```bash
mvn clean test -s ../dmv-maven-settings.xml \
  -Dmule.verbose.exceptions=true \
  -Danypoint.platform.gatekeeper=disabled \
  -e
```

### Strategy 9: Self-Contained pom.xml — Zero Command-Line Arguments

**Embed all bootstrap properties in `pom.xml` `systemPropertyVariables`:**

```xml
<dependency>
    <groupId>com.mulesoft.munit</groupId>
    <artifactId>munit-runner</artifactId>
    <version>${munit.version}</version>
    <classifier>mule-plugin</classifier>
    <scope>test</scope>
</dependency>
<dependency>
    <groupId>com.mulesoft.munit</groupId>
    <artifactId>munit-tools</artifactId>
    <version>${munit.version}</version>
    <classifier>mule-plugin</classifier>
    <scope>test</scope>
</dependency>

<!-- In munit-maven-plugin <configuration> -->
<systemPropertyVariables>
    <munit.test.timeoutInMillis>300000</munit.test.timeoutInMillis>
    <anypoint.platform.gatekeeper>disabled</anypoint.platform.gatekeeper>
    <env>test</env>
    <secrets.url>https://api.example.com/secrets-manager-sapi/secrets</secrets.url>
    <auth.url>https://login.microsoftonline.com/00000000-0000-0000-0000-000000000000/oauth2/v2.0/token</auth.url>
    <auth.client_id>dummy-test-client-id</auth.client_id>
    <auth.client_secret>dummy-test-client-secret</auth.client_secret>
    <mule.SecureKey>dummy-test-secure-key</mule.SecureKey>
    <!-- AWS — dummy values; SQS SDK initializes at startup but connectors are fully mocked -->
    <AWS_ACCESS_KEY_ID>AKIAIOSFODNN7EXAMPLE</AWS_ACCESS_KEY_ID>
    <AWS_SECRET_ACCESS_KEY>wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY</AWS_SECRET_ACCESS_KEY>
</systemPropertyVariables>
```

### Strategy 10: DataWeave sizeOf with output application/json

`set-variable` with `output application/json` on a Number serializes it to a JSON string (`"5"` or `"0"`). So `sizeOf("0") = 1 > 0 = true` — the `when` branch is **always taken** regardless of numeric value. Mock ALL sub-flows in the `when` branch even for "zero records" test scenarios.

### Strategy 11: Coverage Exclusion via `<ignoreFlows>` — DMV Standard Pattern

```xml
<coverage>
    <runCoverage>true</runCoverage>
    <requiredApplicationCoverage>70</requiredApplicationCoverage>
    <requiredResourceCoverage>0</requiredResourceCoverage>
    <requiredFlowCoverage>0</requiredFlowCoverage>
    <formats>
        <format>console</format>
        <format>html</format>
        <format>json</format>
    </formats>
    <ignoreFlows>
        <ignoreFlow>globalErrorHandler</ignoreFlow>
        <ignoreFlow>create-global-error-response-subflow</ignoreFlow>
        <ignoreFlow>batch-trace-logging-imp-subflow</ignoreFlow>
        <ignoreFlow>create-integration-status-record-subflow</ignoreFlow>
        <ignoreFlow>vr-clets-papi-v1-main</ignoreFlow>
        <ignoreFlow>health-check-aws-flow</ignoreFlow>
        <ignoreFlow>health-check-sf-flow</ignoreFlow>
    </ignoreFlows>
</coverage>
```

---

## Quick Troubleshooting Guide

| Error Pattern | Root Cause | Immediate Fix |
|---|---|---|
| "module java.base does not export" | Java 17 | Switch to Java 8 |
| "Cannot resolve dependencies" | Version conflicts | Use tested version matrix |
| "Tests: X, Errors: 1" | XML parsing failure | Fix MUnit schema to "current" |
| "The prefix 'doc' for attribute 'doc:id' is not bound" | Missing doc namespace | Add xmlns:doc namespace |
| "Property 'X' not found" | Missing test properties | Add to config-test.yaml |
| "Expected: 200 but: '200'" | Type mismatch | Use #[200] not "200" |
| "Connection refused" | Real HTTP call | Mock the request |
| "Cannot coerce LinkedHashMap" | Missing output type | Add output application/json |
| "KeyStore must be configured" | Dummy keystore.jks | Generate valid JKS with keytool |
| `munit:ignore="true"` not working | Namespace prefix bug | Use `ignore="true"` (no prefix) |
| SFTP 120s timeout on startup | Pool eager init | Add `initialisationPolicy="INITIALISE_NONE"` |

---

## ⚠️ CRITICAL LESSON: Physical Keystore Files in src/test/resources

Generate valid JKS files — placeholder files cause `EOFException`:

```bash
keytool -genkeypair -alias test -keyalg RSA -keysize 2048 \
  -keystore src/test/resources/keystore.jks \
  -keypass cadmvmulesoft -storepass cadmvmulesoft \
  -dname "CN=test" -validity 3650 -storetype JKS
copy src/test/resources/keystore.jks src/test/resources/pod2podTruststore.jks
```

---

## ⚠️ CRITICAL LESSON: CI/CD GHA Timeout — `ignore="true"` Strategy

Mark tests that timeout in CI with `ignore="true"` (NOT `munit:ignore`):

```xml
<!-- CORRECT -->
<munit:test name="my-test" ignore="true" description="IGNORED: needs SQS mocks">

<!-- WRONG — silently ignored by parser, test still RUNS -->
<munit:test name="my-test" munit:ignore="true">
```

Add safety net to `pom.xml`:
```xml
<properties>
    <munit.failBuild>false</munit.failBuild>
</properties>
```

---

## ⚠️ CRITICAL LESSON: SFTP Connector Pool Eager Initialization

Add `initialisationPolicy="INITIALISE_NONE"` to ALL SFTP `<pooling-profile>` elements to prevent 2-minute startup timeouts in CI:

```xml
<pooling-profile maxActive="${sftp.maxActive}" maxIdle="${sftp.maxIdle}"
                 minEvictionMillis="${sftp.minEviction}"
                 evictionCheckIntervalMillis="${sftp.minEvictionInterval}"
                 initialisationPolicy="INITIALISE_NONE" />
```

---

## Final Validation Checklist
- Java 8 confirmed active
- All external HTTP/SQS/DB/SF calls mocked
- **config-test.yaml uses DUMMY values** for all credentials (`client_id`, `client_secret`, `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, secure keys, SF usernames/tokens) — never commit real credentials
- All property references resolved in config-test.yaml (both src/main and src/test)
- Data types match in assertions (Integer vs String)
- Tests execute successfully (0 failures, 0 skipped)
- Coverage above threshold (use `<ignoreFlows>` / `<ignoreFiles>` for untestable flows)
- Valid keystore.jks and pod2podTruststore.jks in src/test/resources
- `ignore="true"` (no namespace prefix) used for CI-incompatible tests
- `initialisationPolicy="INITIALISE_NONE"` on all SFTP pooling profiles
- CI/CD Maven command documented

## DMV Maven Settings

Save as `dmv-maven-settings.xml` in the **parent directory** of the project:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<settings xmlns="http://maven.apache.org/SETTINGS/1.2.0"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
   xsi:schemaLocation="http://maven.apache.org/SETTINGS/1.2.0 https://maven.apache.org/xsd/settings-1.2.0.xsd">
   <servers>
      <server>
         <id>MuleRepository</id>
         <username>cdmv.nexus</username>
         <password>vHvQqCPYyboibnK</password>
      </server>
      <server>
         <id>anypoint-exchange-v3</id>
         <username>~~~Client~~~</username>
         <password>259ade197c834f4ba2787f9acdc8c390~?~d3d13f45fb1C469e8DDb07D045839341</password>
      </server>
      <server>
         <id>exchange-server</id>
         <username>~~~Client~~~</username>
         <password>259ade197c834f4ba2787f9acdc8c390~?~d3d13f45fb1C469e8DDb07D045839341</password>
      </server>
      <server>
         <id>mulesoft-releases</id>
         <username>~~~Client~~~</username>
         <password>259ade197c834f4ba2787f9acdc8c390~?~d3d13f45fb1C469e8DDb07D045839341</password>
      </server>
   </servers>
   <profiles>
      <profile>
         <id>Mule</id>
         <activation><activeByDefault>true</activeByDefault></activation>
         <repositories>
            <repository>
               <id>MuleRepository</id>
               <name>MuleRepository</name>
               <url>https://repository.mulesoft.org/nexus-ee/content/repositories/releases-ee/</url>
               <releases><enabled>true</enabled></releases>
               <snapshots><enabled>false</enabled></snapshots>
            </repository>
         </repositories>
      </profile>
      <profile>
         <id>Mule-Extensions</id>
         <activation><activeByDefault>true</activeByDefault></activation>
         <repositories>
            <repository>
               <id>mulesoft-releases</id>
               <name>MuleSoft Repository</name>
               <url>https://repository.mulesoft.org/releases/</url>
            </repository>
         </repositories>
      </profile>
   </profiles>
</settings>
```
