# vr-resource-report

## Role
You are a DMV VR Platform Engineer running a fresh API resource report for the California DMV Vehicle Registration Mule integration platform on Anypoint. You collect live sizing data from all active environments and generate two HTML reports: a per-environment gap analysis and an API-centric cross-environment comparison.

## Purpose
Re-run the VR API sizing reports after resource changes (memory/CPU fixes, new deployments, T-shirt re-sizing). Generates:
1. `vr-api-gap-analysis-{YYYYMMDD-HHMM}.html` — per-environment actual vs baseline gap analysis
2. `vr-api-cross-env-{YYYYMMDD-HHMM}.html` — API-centric view: one row per API, columns = environments

Both saved to `D:\Users\mwaxs65\VIBES\`.

---

## Prerequisites
- Python at `D:\Users\mwaxs65\.local\bin\python3.14.exe`
- `vr_reports.py` at `D:\Users\mwaxs65\Desktop\vr_reports.py`
- Baseline Excel: `D:\Users\mwaxs65\California Department of Motor Vehicles\DMV DxP VR - Project Go-Live Readiness\Cutover Activities\DxP VR Interface Master List_12-16-2025.xlsx`
- Anypoint Org: `68725aed-77bd-43f3-afe9-25852bee0664` (Reserved For Future Use - Vehicle Registration)

---

## Step 1 — Determine Which Environments to Include

Default environments to collect (skip SIT, UAT, QA per standing exclusion):

| Env | Include? | Notes |
|-----|----------|-------|
| DEV | ✅ | Development |
| SYNC | ✅ | Dev-sync (mirrors DEV sizing) |
| DMVSIT | ✅ | DMV SIT |
| SIT2 | ✅ | System integration test 2 |
| STG | ✅ | Staging |
| CONV | ✅ | Convergence |
| EUT | ✅ | End user testing |
| PREUAT | ✅ | Pre-UAT |
| PERF | ✅ | Performance |
| PROD | ✅ | Production |
| SIT | ❌ | Excluded |
| UAT | ❌ | Excluded |
| QA | ❌ | Excluded |

Ask the user if they want to change this list. If they say "same as before" or "all except SIT/UAT/QA", proceed with defaults. If context is limited, focus on: **SIT2, STG, CONV, PERF, PROD** as the minimum viable set.

---

## Step 2 — Collect Fresh Data from Anypoint

Use `list_applications` for each environment. **Pull ALL pages** until `current_page == total_pages`.

For each page response, extract from every app:
- `name` (full name including env suffix)
- `application_status` → map: `RUNNING`=`R`, anything else=`S`
- `resources.memory.limit` → strip `Mi` → integer (mem_mi)
- `resources.cpu.reserved` → strip `m` → integer (cpu_res_m)
- `resources.cpu.limit` → strip `m` → integer (cpu_lim_m)
- `configured_replica_count` → integer (replicas)

**Tool call pattern for each page:**
```
list_applications(
  environmentName = "<ENV>",
  organizationId  = "68725aed-77bd-43f3-afe9-25852bee0664",
  includeCpuMetrics = false,
  includeHeapMetrics = false,
  page = <N>
)
```

Continue calling with `page = page + 1` until `current_page == total_pages`.

---

## Step 3 — Build vr_data.json

After collecting all pages for all environments, write the data to:
`D:\Users\mwaxs65\Desktop\vr_data.json`

### JSON Format

```json
{
  "generated_at": "<ISO timestamp>",
  "environments": {
    "DEV": [
      {
        "name": "vr-bpa-eapi-v1-dev",
        "status": "R",
        "mem_mi": 4000,
        "cpu_res_m": 500,
        "cpu_lim_m": 1000,
        "replicas": 1
      }
    ],
    "SIT2": [ ... ],
    "STG":  [ ... ],
    "CONV": [ ... ],
    "PERF": [ ... ],
    "PROD": [ ... ]
  }
}
```

### PowerShell helper to write the JSON file

```powershell
# After you have all env data in $envData (hashtable), write:
$out = @{
  generated_at = (Get-Date -Format "o")
  environments = $envData
}
$out | ConvertTo-Json -Depth 10 | Set-Content -Path "D:\Users\mwaxs65\Desktop\vr_data.json" -Encoding UTF8
```

Or use Python/write_to_file tool with the JSON content directly.

---

## Step 4 — Run vr_reports.py

```bat
cmd /c "D:\Users\mwaxs65\.local\bin\python3.14.exe D:\Users\mwaxs65\Desktop\vr_reports.py"
```

Expected output:
```
Baseline loaded: 89 APIs
Data file: <timestamp>
  DEV: N apps
  SIT2: N apps
  ...
Gap report saved: D:\Users\mwaxs65\VIBES\vr-api-gap-analysis-YYYYMMDD-HHMM.html (... bytes)
Cross-env report saved: D:\Users\mwaxs65\VIBES\vr-api-cross-env-YYYYMMDD-HHMM.html (... bytes)
Done. Both reports in: D:\Users\mwaxs65\VIBES
```

If it fails with "ERROR: vr_data.json not found", retry Step 3.

---

## Step 5 — Summarize Results

After successful run, report to the user:

1. **Reports saved to:** `D:\Users\mwaxs65\VIBES\`
   - `vr-api-gap-analysis-{ts}.html` — per-env gaps
   - `vr-api-cross-env-{ts}.html` — API-centric comparison

2. **Gap summary** (from script output or compute from data):
   - Total APIs collected
   - Per environment: 🟡 Memory HIGH | 🔵 Memory LOW | ✅ OK
   - Note any environments with more HIGH/LOW than last run (sizes got worse) or fewer (sizes improved)

3. **Highlight key changes** if the user mentioned specific APIs they fixed:
   - Check if those APIs now show ✅ OK instead of 🟡/🔵

---

## Shortcuts

| User says | Do |
|-----------|-----|
| "run the report" | Execute Steps 1-5 with default environments |
| "just SIT2/STG/CONV/PERF" | Collect only those 4 envs (faster) |
| "use existing data" | Skip Steps 1-3, go straight to Step 4 |
| "compare to last run" | Run Step 4, then diff summary vs previous report |
| "which APIs still have gaps" | Parse the gap report and list HIGH/LOW entries |

---

## Files Reference

| File | Path | Purpose |
|------|------|---------|
| `vr_reports.py` | `D:\Users\mwaxs65\Desktop\` | Unified report generator (reads JSON, writes HTML) |
| `vr_data.json` | `D:\Users\mwaxs65\Desktop\` | Fresh Anypoint data (overwritten each run) |
| Baseline Excel | `...Cutover Activities\DxP VR Interface Master List_12-16-2025.xlsx` | Sizing baseline sheet: "API Names with Sizing" |
| Output HTML | `D:\Users\mwaxs65\VIBES\` | Report output directory |

---

## Baseline Rules
- **NonProd environments** (DEV, SYNC, DMVSIT, SIT2, STG, CONV, EUT, PREUAT, MERGE): compare vs `Memory Allocation Non Prod (GB)` column
- **Prod-class environments** (PERF, PROD): compare vs `Total Memory Allocation (Prod)` column
- **Tolerance**: Memory ±10% = OK · CPU ±15% = OK · Outside = HIGH or LOW gap
- **No Baseline**: API not in "API Names with Sizing" sheet — shown as grey, no gap computed