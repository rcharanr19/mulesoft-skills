---
name: generate-dmv-icd
description: Generate CA DMV DXP Interface Control Documents (ICD DOCX) and Data Mapping Sheets (XLSX) for any MuleSoft integration. Use when user asks to generate an ICD, create a mapping doc, write up ICD sections (Purpose, Scope, Approach, Process Overview, Data Elements, Validations, Processing Logic, Transmission, Error Handling, Security, Retry/Timeout), add test cases tab, or regenerate an existing ICD. Uses dmv_icd_generator.py + icd_data_template.py in D:\Users\mwaxs65\VIBES. Always run generator with: uv run --with python-docx --with openpyxl python dmv_icd_generator.py icd_<name>_data via Start-Process (Python App Execution Aliases disabled on this machine).
license: Apache-2.0
metadata:
  author: mule-dx-tooling
  version: "1.0.0"
  theme: professional
allowed-tools: Read Write Edit AskUserQuestion Bash
---

# Skill: generate-dmv-icd

## Purpose
Generate CA DMV DXP Interface Control Documents (ICD) in DOCX format and accompanying Data Mapping Sheets in XLSX format using the Python-based ICD generator framework located in `D:\Users\mwaxs65\VIBES`.

## Trigger
Use this skill whenever the user asks to:
- "generate an ICD" / "create an ICD doc" / "write an ICD for INT..."
- "generate a mapping sheet" / "create a mapping doc"
- "update the ICD for INT..." / "regenerate the ICD"
- "add a test cases tab to the mapping sheet"
- "write up [any ICD section]" — Purpose, Scope, Approach, Process Overview, Data Elements, Validations, Processing Logic, Transmission, Error Handling, Security, Retry/Timeout, etc.

---

## Core Files (VIBES workspace)

| File | Role | Edit? |
|------|------|-------|
| `dmv_icd_generator.py` | **Generator engine** — builds DOCX + XLSX from a data module. Never edit this file. | NO |
| `icd_data_template.py` | **Starter template** — copy and rename for each new interface. Contains all required variables with inline documentation. | Copy only |
| `icd_<interface>_data.py` | **Interface data module** — one per ICD. All content variables for a specific interface. | YES |
| `run_gen_<interface>.bat` | **Runner** — double-click or call from terminal to generate output files. | YES |

---

## Workflow for a New ICD

### Step 1 — Gather Source Material
Before writing any code, collect:
- Postman collection (JSON) for the API
- Mule XML source files (`src/main/mule/*.xml`, global.xml, impl files)
- Property files (`config-dev.yaml`, `common.yaml`)
- Architecture diagrams (PNG/JPG) showing system topology
- `pom.xml` for Mule runtime version and connector dependencies
- README.md files from the Mule project repos

If source zips are present in VIBES, extract them first:
```powershell
powershell -Command "Expand-Archive -Path 'D:\Users\mwaxs65\VIBES\<name>.zip' -DestinationPath 'D:\Users\mwaxs65\VIBES\<name>' -Force"
```

### Step 2 — Create the Data Module
Copy `icd_data_template.py` → `icd_<intNumber>_data.py` and fill in ALL variables.

Required variables (raises AttributeError if missing):
- `INT_NAME`, `INT_NUMBER`, `MULESOFT_API`, `API_LAYER`
- `TOC`, `PURPOSE_TEXT`, `SCOPE_BULLETS`, `APPROACH_STEPS`
- `PROCESS_OVERVIEW_TEXT`, `SEQUENCE_DIAGRAMS`, `DATA_ELEMENT_TABLES`
- `ENVS`, `OPS`, `GITHUB_REPOS`, `POSTMAN_TEXT`, `SAMPLES`
- `VALIDATIONS_TEXT`, `PROCESSING_LOGIC`, `TRANSMISSION_TABLE`
- `VOLUME_TEXT`, `ERROR_HANDLING_INTRO`, `ERR_HTTP`, `SECURITY_BULLETS`
- `POST_PROCESSING_BULLETS`, `CACHING_TEXT`, `SLA`, `LOGGING_INTRO`, `LOG_PTS`
- `EXCHANGE_LINKS`, `SYSTEM_DETAILS`, `RETRY_TIMEOUT_TEXT`
- `MAPPING_SHEET_TEXT`, `ENDPOINT_SUMMARY`, `ACRONYMS`, `XLSX_TABS`

### Step 3 — Sequence Diagrams (Mermaid)
Keep diagrams compact. Use `SEQUENCE_DIAGRAMS` list of `(title, mermaid_code)` tuples.
Mermaid code is stored as a raw string and rendered as a code block in the DOCX.
Paste into https://mermaid.live to preview.

**Standard compact format:**
```python
SEQUENCE_DIAGRAMS = [
    (
        "Happy Path -- POST /endpoint",
        "sequenceDiagram\n"
        "  participant SF as Salesforce CCIM\n"
        "  participant EA as vr-sfdc-ccim-eapi-v1\n"
        "  participant PA as vr-<name>-papi-v1\n"
        "  participant MQ as EASE MQ (IBM MQ)\n"
        "  SF->>EA: POST /endpoint [...]\n"
        "  EA->>PA: forward + inject credentials\n"
        "  PA->>MQ: publish message\n"
        "  PA-->>EA: 200 OK {status,correlationId}\n"
        "  EA-->>SF: 200 OK",
    ),
]
```

### Step 4 — XLSX Tabs
`XLSX_TABS` is a list of dicts. Always include these standard tabs:
1. `workdate-auths Mapping` (or equivalent request field mapping)
2. `station-mappings Mapping` (or equivalent)
3. `Request Headers`
4. `Response Envelope`
5. `Error Codes`
6. `Test Cases` — QA test cases with TC #, Endpoint, Scenario, Input, Expected Code, Expected Behaviour

**Test Cases tab template:**
```python
{
    "name": "Test Cases",
    "headers": ["TC #", "Endpoint", "Test Scenario", "Input / Condition", "Expected HTTP Code", "Expected Response / Behaviour"],
    "rows": [
        ["TC-001", "POST /endpoint", "Happy path", "valid payload", "200", "status:SUCCESS, correlationId"],
        ["TC-002", "POST /endpoint", "Empty array", "[]", "400", 'message:"Request array must not be empty."'],
        # ... add all validation, security, routing, and error cases
    ],
    "widths": [8, 22, 38, 50, 20, 50],
}
```

### Step 5 — Create Runner BAT
```bat
@echo off
echo Generating INT<N> <Name> ICD + Mapping Sheet...
cd /d "D:\Users\mwaxs65\VIBES"
uv run --with python-docx --with openpyxl python dmv_icd_generator.py icd_int<N>_data
if errorlevel 1 (
    echo.
    echo --- uv failed, trying python directly ---
    python dmv_icd_generator.py icd_int<N>_data
)
echo.
echo Done. Check for:
echo   INT<N> - <Name> - V1.0 - ICD.docx
echo   INT<N> - <Name> - V1.0 - Mapping Sheet.xlsx
pause
```

### Step 6 — Generate
**ALWAYS use uv run** (Python App Execution Aliases are disabled on this machine):
```powershell
powershell -Command "Start-Process -FilePath 'uv' -ArgumentList 'run --with python-docx --with openpyxl python dmv_icd_generator.py icd_int<N>_data' -WorkingDirectory 'D:\Users\mwaxs65\VIBES' -NoNewWindow -Wait -RedirectStandardOutput 'D:\Users\mwaxs65\VIBES\gen_out.txt' -RedirectStandardError 'D:\Users\mwaxs65\VIBES\gen_err.txt'"
```
Then read `gen_out.txt` to confirm success.

Output files are saved to `D:\Users\mwaxs65\VIBES\`:
```
INT<N> - <Name> - V<version> - ICD.docx
INT<N> - <Name> - V<version> - Mapping Sheet.xlsx
```

---

## Key Architecture Patterns (CA DMV DXP)

### Standard CCIM Integration Chain
```
Salesforce CCIM → vr-sfdc-ccim-eapi-v1 (EAPI) → vr-<name>-papi-v1 (PAPI) → EASE MQ (IBM MQ) → EASE → DB2
```
- EAPI: thin pass-through; sets correlationId, injects credentials from Thycotic
- PAPI: validates + DataWeave transforms + publishes to IBM MQ
- EASE: async consumer; updates DB2 tables

### Standard DMV API-led Layers
- **EAPI** (Experience API): consumer-facing, Salesforce-side entry point
- **PAPI** (Process API): orchestration, validation, transformation
- **SAPI** (System API): backend-system connectivity

### Standard Headers (all CCIM integrations)
| Header | Required | Notes |
|--------|----------|-------|
| `dmv_source` | Yes | e.g. `dmv_dxp_vr` |
| `dmv_appid` | Yes | e.g. `sfdc_ccim` |
| `x-correlation-id` | Yes | UUID; stored as `vars.correlationId` |
| `client_id` | Yes | From Thycotic; injected by EAPI |
| `client_secret` | Yes | From Thycotic; injected by EAPI |

### Standard Response Envelope
```json
{
  "status":        "SUCCESS",
  "message":       "N record(s) processed successfully.",
  "correlationId": "<x-correlation-id>",
  "timestamp":     "<ISO 8601 UTC>"
}
```

### Standard Error Envelope
```json
{
  "status":        <HTTP code>,
  "error":         "<HTTP status text>",
  "message":       "<error.description>",
  "correlationId": "<vars.correlationId>"
}
```

---

## Writing ICD Sections in Chat (for copy-paste)

When the user asks to "print" or "write up" a section, output it directly in Markdown so they can copy from chat. Use tables for Data Elements, Processing Logic, and Transmission. Use bullet lists for Scope and Post-Processing. Use numbered tables for Approach Steps.

**Section → Variable mapping:**
| ICD Section | Data Module Variable |
|-------------|---------------------|
| 1.1 Document Purpose | `PURPOSE_TEXT` |
| 1.2 Scope and Assumptions | `SCOPE_BULLETS` |
| 1.3 Approach | `APPROACH_STEPS` |
| 2.1 Process Overview | `PROCESS_OVERVIEW_TEXT` |
| 2.1 Sequence Diagrams | `SEQUENCE_DIAGRAMS` |
| 2.2 Data Elements | `DATA_ELEMENT_TABLES` |
| 2.3 Mule Endpoints | `ENVS` + `OPS` |
| 2.5 Postman Collections | `POSTMAN_TEXT` + `SAMPLES` |
| 2.7 Validations | `VALIDATIONS_TEXT` |
| 2.8 Processing Logic | `PROCESSING_LOGIC` |
| 2.9 Transmission | `TRANSMISSION_TABLE` |
| 2.11 Error Handling | `ERROR_HANDLING_INTRO` + `ERR_HTTP` + `D_ERR` |
| 2.12 Security | `SECURITY_BULLETS` + `SEC_PROPS` |
| 2.13 Post Processing | `POST_PROCESSING_BULLETS` |
| 2.14 Caching | `CACHING_TEXT` |
| 2.19 Retry/Timeout | `RETRY_TIMEOUT_TEXT` |

After printing sections in chat, **always update the data module** so the DOCX stays in sync, then regenerate.
