# implement-and-refine-batch-framework

## Role
You are an expert MuleSoft developer for California DMV VR integrations. Your task is to implement or refine the **VR Batch Framework** in a given Mule project. The Batch Framework is an **NFR (Non-Functional Requirement)** — you MUST NOT touch or alter any functional business logic. You only add/fix batch observability instrumentation.

---

## Purpose
The VR Batch Framework writes structured tracking records to Salesforce for every meaningful step of a batch integration:
- **Batch Header** (`CADMV_IntegrationCalloutStatus__c`) — one per job run, tracks overall job status
- **Batch Line Items** (`CADMV_Batch_Job_Line_Items__c`) — one per milestone step, tracks granular step-level progress

Both are written via **SQS logging queue** and **SF APEX REST** using two shared sub-flows from the `vr-common-logging-framework`:
1. `batch-trace-logging-imp-subflow` — creates a **Batch Line Item** (one per step)
2. `create-integration-status-record-subflow` — creates/updates the **Batch Header** (one per job)

---

## Step 1 — Analyse the Project

Before writing any code, read ALL of the following:

1. `src/main/mule/common/global-config.xml` — confirm `vr-common-logging-framework.xml` is imported; confirm `Salesforce_Config`, `Object_store`, `ObjectStore_Config` exist
2. `src/main/mule/*.xml` — find the batch entry point(s): scheduler, platform event listener, SQS listener, or HTTP GET endpoint
3. `src/main/mule/implementation/*.xml` — ALL implementation sub-flows — identify every milestone step
4. `pom.xml` — confirm `vr-common-logging-framework` dependency with classifier `mule-plugin` is present
5. `src/test/munit/*.xml` — check existing MUnit tests; identify which ones test batch flows

**Identify:**
- The unique `runId` variable name (may be `thisJobRunId`, `batchRunId`, etc.)
- Source system (Salesforce, SFTP, DB, MQ, etc.) and target system (SQS, MQ, SFTP, DB, etc.)
- Interface name (e.g., `NMVTIS`, `BAR`, `INQUIRY`) and interface operation name (e.g., `PSEUDO`, `RE8`)
- Whether the trigger is event-driven (platform event / SQS) or ad-hoc (HTTP GET / scheduler)
- ALL milestone steps in the flow chain (see Step 3)

---

## Step 2 — Check for Missing Prerequisites

### 2a. `pom.xml`
Add the following dependency if missing:

    <dependency>
        <groupId>${org.groupId}</groupId>
        <artifactId>vr-common-logging-framework</artifactId>
        <version>${vr-common-logging-framework.version}</version>
        <classifier>mule-plugin</classifier>
    </dependency>

### 2b. `global-config.xml`
Confirm ALL of the following exist. Add any that are missing:

- `<import file="vr-common-logging-framework.xml" />` — provides both batch framework sub-flows
- `<os:config name="ObjectStore_Config">` with a `<reconnect />` connection strategy
- `<os:object-store name="Object_store" entryTtl="1" entryTtlUnit="DAYS" config-ref="ObjectStore_Config" />` — persists `batchJobId` across async flows

---

## Step 3 — Identify ALL Milestone Steps

**A "milestone step" is any significant processing activity that the business needs to track.** A batch line item MUST be placed at EVERY milestone. Never skip a step.

### Standard Milestone Steps (adapt names to the project):

| Step | What happens | stepName example |
|------|-------------|-----------------|
| INIT | Set runId, set batchexecuteparams, create Batch Header | header only — no line item |
| 1 | Query/fetch source record COUNT | "Started Retrieving SOURCE records count" |
| 2 | Retrieve/read actual records from source | "SOURCE Records Retrieved" |
| 3 | Transform and publish/enqueue to target (per loop iteration) | "Processing Retrieved SOURCE Records" |
| 4 | Update source system record status (e.g., SF Bulk Update) | "Updating SOURCE record status" |
| 5 | Final completion / error summary | "Batch job completed" or "Batch job failed" |

**Additional steps include:** file download (SFTP/S3), file parse/validate, aggregation complete, downstream API callout, MQ publish, delete processed messages from queue.

**RULE: Every functional step needs a batch line item BEFORE it (status=In Progress) and AFTER it (status=Success or status=Failed inside the error handler).**

---

## Step 4 — Required Variables Reference

### vars.interfaceType (CRITICAL — must be "Batch")

MUST be set to the string `"Batch"` at the very top of every batch flow and sub-flow before any batch framework call. Without this, `create-integration-status-record-subflow` will not write the header correctly.

    variableName="interfaceType" value="Batch"

### vars.batchexecuteparams — set ONCE at job init

Fields:
- `runId` — unique job-run identifier (generate from timestamp or use SF `CADMV_JobRunId__c`)
- `source` — source system name (e.g., "Salesforce", "SFTP")
- `target` — target system name (e.g., "SQS", "MQ")
- `startTime` — `(now() >> "PST") as DateTime as String {format:"yyyy-MM-dd HH:mm:ss"}`
- `batchType` — "Inbound" or "Outbound"
- `interfaceName` — e.g., "NMVTIS", "BAR"
- `interfaceOpName` — e.g., "PSEUDO", "RE8"
- `interfaceType` — always "Batch"
- `status` — "In Progress"

### vars.batchflowindparams — set BEFORE every batch-trace-logging-imp-subflow call

Fields:
- `stepName` — human-readable description of this step
- `status` — "In Progress", "Success", or "Failed"
- `startTime` — step start timestamp
- `endTime` — `(now() >> "PST") as Time {format:"HH:mm:ss.SSS"}`
- `loopId` — `vars.counter as String` inside foreach, otherwise `null`
- `bulkJobId` — SF Bulk Job ID when a bulk job was created, otherwise `null`
- `recordsRead` — count of records read (or null)
- `recordsProcessed` — count processed (or null)
- `recordsRejected` — count rejected (or null)
- `recordsSuccessful` — count successful (or null)
- `stepId` — `vars.stepId` (unique per line item)
- `totalRecords` — total expected records (or null)
- `errorPayload` — `error.description` — ONLY inside error handlers

### vars.stepId — unique per line item

Always generate a new stepId BEFORE setting batchflowindparams:

    variableName="stepId"
    value: vars.batchexecuteparams.runId ++ uuid()

Inside a foreach loop:

    vars.batchexecuteparams.runId ++ "_StepN_loop" ++ (vars.counter as String)

### vars.batchJobId — SF Integration Status Record ID

Set after `create-integration-status-record-subflow` returns (target="headertracelogres"):

    value: read(vars.headertracelogres.createIntegrationLogBulkOutput, "application/json").IntegrationStatusRecordList[0]

This ID links all line items to the header record.

---

## Step 5 — Exact Implementation Patterns

### Pattern A: INIT Block (entry sub-flow, before any functional logic)

    1. Set thisJobRunId = "IFNAME_BATCH_" ++ (now() >> "PST") as String {format:"MMddYYYYHHmmss"}
    2. Set interfaceType = "Batch"
    3. Set batchexecuteparams (see Step 4)
    4. ASYNC: flow-ref to create-integration-status-record-subflow, target="headertracelogres"
    5. Set batchJobId = read(vars.headertracelogres...).IntegrationStatusRecordList[0]

**Platform event EXCEPTION**: If triggered by a Salesforce platform event that provides `CADMV_JobRunId__c`:
- Use `payload.data.payload.CADMV_JobRunId__c` as the `runId`
- Only call `create-integration-status-record-subflow` for ad-hoc GET triggers (the header already exists for event-driven triggers)

### Pattern B: Line Item — "In Progress" (BEFORE the connector call)

    1. set-variable stepId = vars.batchexecuteparams.runId ++ uuid()
    2. set-variable batchflowindparams { stepName, status:"In Progress", startTime, endTime, loopId:null, bulkJobId:null, all counts:null, stepId:vars.stepId }
    3. async { flow-ref name="batch-trace-logging-imp-subflow" target="tracelogres" }

### Pattern C: Line Item — "Success" (AFTER the connector call succeeds)

    1. set-variable stepId = vars.batchexecuteparams.runId ++ uuid()  (RESET to new unique value)
    2. set-variable batchflowindparams { stepName, status:"Success", endTime, loopId:null, bulkJobId:null, recordsRead/Processed/Rejected/Successful with actual counts, stepId:vars.stepId, totalRecords }
    3. async { flow-ref name="batch-trace-logging-imp-subflow" target="tracelogres" }

### Pattern D: Line Item — "Failed" (INSIDE on-error-propagate or on-error-continue)

    1. set-variable batchflowindparams { stepName, status:"Failed", endTime, loopId:null, bulkJobId:null, all counts:null, stepId:vars.stepId, errorPayload:error.description }
    2. async { flow-ref name="batch-trace-logging-imp-subflow" target="tracelogres" }

No stepId reset is needed in error handlers — the stepId from the failed operation is reused.

### Pattern E: Line Item — inside a foreach loop (per-iteration)

Use ee:transform to set both stepId and batchflowindparams in one transform. Set loopId to vars.counter as String:

    ee:transform:
      stepId   = vars.batchexecuteparams.runId ++ "_StepN_loop" ++ (vars.counter as String)
      batchflowindparams = {
        stepName: "Processing ITEM for loop " ++ (vars.counter as String),
        status: "In Progress",
        startTime: (now() >> "PST") as Time {format:"HH:mm:ss.SSS"},
        loopId: vars.counter as String,
        bulkJobId: null,
        recordsRead/Processed/Rejected/Successful: null,
        stepId: vars.batchexecuteparams.runId ++ "_StepN_loop" ++ (vars.counter as String)
      }
    flow-ref name="batch-trace-logging-imp-subflow" target="tracelogres"

Inside a foreach, wrapping in async is optional but safe. Do NOT reset stepId between loop iterations — the loop counter makes each stepId unique.

### Pattern F: Final Batch Header Update (end of job)

At the very end of the batch job (or in the final error handler), update the header to "Success" or "Failed":

    1. Merge batchexecuteparams with updated status: vars.batchexecuteparams ++ {"status": "Success"}
    2. Set batchflowindparams { stepName:"Batch job completed", status:"Success" or "Failed",
       endTime, totalRecords, recordsProcessed, recordsSuccessful, recordsRejected, stepId }
    3. ASYNC: flow-ref to create-integration-status-record-subflow, target="headertracelogres"

---

## Step 6 — Audit Rules: What COUNTS as Missing or Broken

When reviewing an existing project, check ALL of these:

| Rule | Check |
|------|-------|
| R1 | `vars.interfaceType = "Batch"` set at the top of EVERY batch flow/sub-flow |
| R2 | `vars.batchexecuteparams` set ONCE before first batch-trace call |
| R3 | `create-integration-status-record-subflow` called at job init |
| R4 | EVERY connector call preceded by: set stepId + set batchflowindparams(InProgress) + async batch-trace |
| R5 | EVERY successful call followed by: reset stepId + set batchflowindparams(Success) + async batch-trace |
| R6 | EVERY error handler has: set batchflowindparams(Failed, errorPayload) + async batch-trace |
| R7 | foreach loops use ee:transform to set stepId + batchflowindparams with loopId |
| R8 | Final header update at job end with status="Success" or "Failed" |
| R9 | All batch-trace calls are inside async blocks (fire-and-forget) |
| R10 | batchJobId is set from headertracelogres after header creation |

**CRITICAL violations (must fix before deployment):**
- Missing `interfaceType = "Batch"` → header will not be created
- Missing `stepId` reset between steps → duplicate line items in SF
- Batch-trace calls NOT in async → blocks main thread, degrades performance
- `create-integration-status-record-subflow` called inside a loop → creates duplicate headers

---

## Step 7 — Annotated XML Skeleton

Below is the skeleton for a typical batch entry sub-flow with all batch framework instrumentation. Adapt field values to the project.

    SUB-FLOW: main-batch-entry-imp-Sub_Flow
    ========================================
    [NFR] set-variable: thisJobRunId = "IFNAME_BATCH_" ++ timestamp
    [NFR] set-variable: interfaceType = "Batch"
    [NFR] set-variable: batchexecuteparams { runId, source, target, startTime, batchType, interfaceName, interfaceOpName, interfaceType, status }
    [NFR] async:
            flow-ref: create-integration-status-record-subflow (target=headertracelogres)
    [NFR] set-variable: batchJobId from vars.headertracelogres
    [FUNCTIONAL] set inputPayload / other init variables
    flow-ref: retrieve-record-count-sub_flow

    SUB-FLOW: retrieve-record-count-sub_flow
    =========================================
    [NFR] set-variable: stepId = runId ++ uuid()
    [NFR] set-variable: batchflowindparams { stepName:"Started Retrieving records count", status:"In Progress", stepId }
    [NFR] async: flow-ref: batch-trace-logging-imp-subflow (target=tracelogres)
    [FUNCTIONAL] set-variable: recordCountFetchQuery
    [FUNCTIONAL] try:
        [FUNCTIONAL] salesforce:query-xml-stream (target=sfRecordCount)
        on-error-propagate:
            [FUNCTIONAL] set-variable: errorPayload
            [FUNCTIONAL] logger
            [NFR] async:
                [NFR] set-variable: batchflowindparams { stepName:"Failed to retrieve count", status:"Failed", errorPayload, stepId }
                [NFR] flow-ref: batch-trace-logging-imp-subflow
    [NFR] set-variable: stepId = runId ++ uuid()  (RESET)
    [NFR] set-variable: batchflowindparams { stepName:"Retrieved record count", status:"Success", recordsRead, stepId }
    [NFR] async: flow-ref: batch-trace-logging-imp-subflow
    [FUNCTIONAL] choice: if count > 0 → flow-ref: retrieve-records-sub_flow

    SUB-FLOW: retrieve-records-sub_flow
    =====================================
    [FUNCTIONAL] set-variable: retrieveRecordsSFquery
    [NFR] set-variable: stepId = runId ++ uuid()
    [NFR] set-variable: batchflowindparams { stepName:"Retrieving SOURCE records", status:"In Progress", stepId }
    [NFR] async: flow-ref: batch-trace-logging-imp-subflow
    [FUNCTIONAL] try:
        [FUNCTIONAL] salesforce:query (retrieve records)
        on-error-propagate:
            [FUNCTIONAL] set-variable: errorPayload
            [NFR] set-variable: batchflowindparams { status:"Failed", errorPayload, stepId }
            [NFR] flow-ref: batch-trace-logging-imp-subflow
    [FUNCTIONAL] foreach (batchSize from property):
        [NFR] ee:transform: stepId = runId ++ "_StepN_loop" ++ counter
                            batchflowindparams { stepName, status:"In Progress", loopId:counter }
        [NFR] flow-ref: batch-trace-logging-imp-subflow
        [FUNCTIONAL] transform payload for TARGET
        [FUNCTIONAL] try:
            [FUNCTIONAL] sqs:send-message / mq:publish / etc.
            [FUNCTIONAL] set-variable: successIdList += currentId
            on-error-continue:
                [FUNCTIONAL] logger
                [FUNCTIONAL] set-variable: failureIdList += currentId
    [FUNCTIONAL] bulk-update source system
    [NFR] set-variable: stepId = runId ++ uuid()  (RESET after loop)
    [NFR] set-variable: batchflowindparams { stepName:"Records processed", status:"Success",
                         recordsProcessed, recordsSuccessful, recordsRejected, stepId }
    [NFR] async: flow-ref: batch-trace-logging-imp-subflow
    [NFR] async: flow-ref: create-integration-status-record-subflow (final header update)

---

## Step 8 — MUnit Mocking Rules

**ONLY apply if `src/test/munit/` has existing test files that test batch flows. Do NOT create MUnit tests from scratch unless the user explicitly asks.**

For every MUnit test that exercises a flow containing batch framework calls, you MUST mock:

### Required mocks (in munit:behavior section):

**1. Mock batch-trace-logging-imp-subflow (empty return — fire-and-forget)**

    munit-tools:mock-when processor="flow-ref"
      with-attribute: name = "batch-trace-logging-imp-subflow"
      then-return: (empty — no payload, no variables needed)

**2. Mock create-integration-status-record-subflow (return mock batchJobId)**

    munit-tools:mock-when processor="flow-ref"
      with-attribute: name = "create-integration-status-record-subflow"
      then-return:
        variables:
          headertracelogres = {
            "createIntegrationLogBulkOutput":
              "{\"message\":\"Success\",\"IntegrationStatusRecordList\":[\"a003x000001TESTID001\"]}"
          }

### Why these mocks are mandatory:
- `batch-trace-logging-imp-subflow` calls SQS — without mocking, tests fail with connectivity errors
- `create-integration-status-record-subflow` calls SF APEX REST — without mocking, tests fail and batchJobId is null

### Assertions to add for batch framework:
After the flow-ref under test, assert:

    assert batchexecuteparams != null
    assert batchexecuteparams.source == "ExpectedSource"
    assert batchflowindparams.status == "Success" (or "Failed" for negative tests)
    assert stepId != null

### Negative test assertions:
For flows that test error paths (e.g., SF connector CONNECTIVITY error):

    assert batchflowindparams.status == "Failed"
    assert batchflowindparams.errorPayload != null

---

## Step 9 — Key Rules and Gotchas

| Rule | Detail |
|------|--------|
| NFR ONLY | Never add, remove, or change functional logic. Only add batch framework variables and flow-ref calls |
| async is mandatory | All batch-trace calls MUST be async (fire-and-forget). Blocking the main thread defeats the purpose |
| No async for create-integration-status-record-subflow in ad-hoc GET | The GET trigger needs batchJobId from the header before proceeding — must be synchronous for the initial header creation, then async for updates |
| stepId uniqueness | ALWAYS reset stepId to runId ++ uuid() before each "Success" line item. Never reuse the same stepId for both In Progress and Success |
| Error handler: no stepId reset | In error handlers, reuse the existing stepId (it identifies the step that failed) |
| Foreach loopId | Must be vars.counter as String — not null — inside a foreach |
| interfaceType scope | If a downstream sub-flow is called from the batch flow, it inherits vars.interfaceType. But if it can also be called from non-batch flows, set interfaceType = "Batch" at its entry too |
| batchJobId null guard | If batchJobId is null (event-driven trigger without header creation), the line items still write but won't link to a header. This is acceptable |
| Platform events | For event-driven triggers, the Salesforce platform event already carries CADMV_JobRunId__c — use that as runId. Do not generate a new one |
| Aggregator flows | Flows triggered by aggregators (size-based or time-based) also need batch framework instrumentation. Set batchexecuteparams by reading batchJobId from Object Store first |


